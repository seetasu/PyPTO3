#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void exp_gate_up_act(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c49216_i64
  const int64_t v12 = 49216;
  // pto: %c57408_i64
  const int64_t v13 = 57408;
  // pto: %c65600_i64
  const int64_t v14 = 65600;
  // pto: %c16448_i64
  const int64_t v15 = 16448;
  // pto: %c24640_i64
  const int64_t v16 = 24640;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c8192_i64
  const int64_t v18 = 8192;
  // pto: %c16384_i64
  const int64_t v19 = 16384;
  // pto: %c32832_i64
  const int64_t v20 = 32832;
  // pto: %c41024_i64
  const int64_t v21 = 41024;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c2048_index
  const int64_t v23 = 2048;
  // pto: %c1_index
  const int64_t v24 = 1;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c512_index
  const int64_t v26 = 512;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c4_index
  const int64_t v28 = 4;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %cst_19
  const float v31 = 10.0f;
  // pto: %cst_20
  const float v32 = -10.0f;
  // pto: %cst_21
  const float v33 = 1.0f;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  int64_t v37 = v22 * v23;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  int64_t v38 = v36 * v37;
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v22, v23);
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v38, v38, v37, v23, v24);
  // pto: %h_tile_fp32_inline464__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v39, v40);
  // pto: %gate_tile_i32_inline446__rv_v2_view
  const int64_t v42 = 1;
  // pto: %gate_tile_i32_inline446__rv_v2_view
  const int64_t v43 = 1;
  // pto: %gate_tile_i32_inline446__rv_v2_view
  const int64_t v44 = 1;
  // pto: %gate_tile_i32_inline446__rv_v2_view
  int64_t v45 = v22 * v23;
  // pto: %gate_tile_i32_inline446__rv_v2_view
  int64_t v46 = v44 * v45;
  // pto: %gate_tile_i32_inline446__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v22, v23);
  // pto: %gate_tile_i32_inline446__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v46, v46, v45, v23, v24);
  // pto: %gate_tile_i32_inline446__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v47, v48);
  // pto: %up_tile_i32_inline447__rv_v2_view
  const int64_t v50 = 1;
  // pto: %up_tile_i32_inline447__rv_v2_view
  const int64_t v51 = 1;
  // pto: %up_tile_i32_inline447__rv_v2_view
  const int64_t v52 = 1;
  // pto: %up_tile_i32_inline447__rv_v2_view
  int64_t v53 = v22 * v23;
  // pto: %up_tile_i32_inline447__rv_v2_view
  int64_t v54 = v52 * v53;
  // pto: %up_tile_i32_inline447__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v22, v23);
  // pto: %up_tile_i32_inline447__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v54, v54, v53, v23, v24);
  // pto: %up_tile_i32_inline447__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v55, v56);
  // pto: %recv_scale_out_inline9__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %recv_scale_out_inline9__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %recv_scale_out_inline9__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %recv_scale_out_inline9__ssa_v0_view
  int64_t v61 = v25 * v22;
  // pto: %recv_scale_out_inline9__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %recv_scale_out_inline9__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v25, v22);
  // pto: %recv_scale_out_inline9__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v22, v24);
  // pto: %recv_scale_out_inline9__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v63, v64);
  // pto: %routed_w1_scale__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %routed_w1_scale__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %routed_w1_scale__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %routed_w1_scale__ssa_v0_view
  int64_t v69 = v25 * v23;
  // pto: %routed_w1_scale__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %routed_w1_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v25, v23);
  // pto: %routed_w1_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v23, v24);
  // pto: %routed_w1_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v71, v72);
  // pto: %routed_w3_scale__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %routed_w3_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %routed_w3_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %routed_w3_scale__ssa_v0_view
  int64_t v77 = v25 * v23;
  // pto: %routed_w3_scale__ssa_v0_view
  int64_t v78 = v76 * v77;
  // pto: %routed_w3_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v25, v23);
  // pto: %routed_w3_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v78, v78, v77, v23, v24);
  // pto: %routed_w3_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v79, v80);
  // pto: %ab_idx_inline465__ssa_v0, %31
  int64_t v82 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v26);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v83 = v27; v83 < v28; v83 += v29) {
    // pto: %32
    ;
    int64_t v84 = (int64_t) ((uint64_t) v83 * (uint64_t) v30);
    // pto: %33
    ;
    int64_t v85 = (int64_t) ((uint64_t) v82 + (uint64_t) v84);
    // pto: %35
    ;
    int64_t v86 = (int64_t) ((uint64_t) v84 + (uint64_t) v30);
    // pto: %36
    ;
    int64_t v87 = (int64_t) ((uint64_t) v82 + (uint64_t) v86);
    // pto: %gate_2d_i32_inline469__tile
    ;
    Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %gate_2d_i32_inline469__tile
    ;
    uint64_t v89 = (uint64_t) v12;
    TASSIGN(v88, v89);
    // pto: %37
    ;
    int64_t v90 = v85 < v27 ? v27 : v85;
    // pto: %gate_tile_i32_inline446__rv_v2_pview
    ;
    __gm__ int32_t* v91 = PTOAS__GLOBAL_TENSOR_DATA(v49);
    // pto: %gate_tile_i32_inline446__rv_v2_pview
    ;
    const int64_t v92 = 0;
    // pto: %gate_tile_i32_inline446__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v93 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %gate_tile_i32_inline446__rv_v2_pview
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v94 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %gate_tile_i32_inline446__rv_v2_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v95 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v91 + (v92 + v90), v93, v94);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v88, v95);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %up_2d_i32_inline470__tile
    ;
    Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %up_2d_i32_inline470__tile
    ;
    uint64_t v97 = (uint64_t) v13;
    TASSIGN(v96, v97);
    // pto: %up_tile_i32_inline447__rv_v2_pview
    ;
    __gm__ int32_t* v98 = PTOAS__GLOBAL_TENSOR_DATA(v57);
    // pto: %up_tile_i32_inline447__rv_v2_pview
    ;
    const int64_t v99 = 0;
    // pto: %up_tile_i32_inline447__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v100 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %up_tile_i32_inline447__rv_v2_pview
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v101 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %up_tile_i32_inline447__rv_v2_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v102 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v98 + (v99 + v90), v100, v101);
    TLOAD(v96, v102);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %recv_x_scale_row_inline471__tile
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
    // pto: %recv_x_scale_row_inline471__tile
    ;
    uint64_t v104 = (uint64_t) v14;
    TASSIGN(v103, v104);
    // pto: %39
    ;
    int64_t v105 = v7 < v27 ? v27 : v7;
    // pto: %40
    ;
    int64_t v106 = v8 < v27 ? v27 : v8;
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    __gm__ float* v107 = PTOAS__GLOBAL_TENSOR_DATA(v65);
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    const int64_t v108 = 0;
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    const int64_t v109 = 16;
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 16> v110 = pto::Shape<1, 1, 1, 1, 16>();
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    pto::Stride<16, 16, 16, 16, 1> v111 = pto::Stride<16, 16, 16, 16, 1>();
    // pto: %recv_scale_out_inline9__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 16>, pto::Stride<16, 16, 16, 16, 1>, pto::Layout::ND> v112 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 16>, pto::Stride<16, 16, 16, 16, 1>, pto::Layout::ND>(v107 + (v108 + v105 * v109 + v106), v110, v111);
    TLOAD(v103, v112);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %w1_scale_chunk_inline473__tile
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v30);
    // pto: %w1_scale_chunk_inline473__tile
    ;
    uint64_t v114 = (uint64_t) v15;
    TASSIGN(v113, v114);
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    __gm__ float* v115 = PTOAS__GLOBAL_TENSOR_DATA(v73);
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    const int64_t v116 = 0;
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    const int64_t v117 = 2048;
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 128> v118 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 2048, 1> v119 = pto::Stride<2048, 2048, 2048, 2048, 1>();
    // pto: %routed_w1_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND>(v115 + (v116 + v105 * v117 + v90), v118, v119);
    TLOAD(v113, v120);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %w3_scale_chunk_inline474__tile
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v30);
    // pto: %w3_scale_chunk_inline474__tile
    ;
    uint64_t v122 = (uint64_t) v16;
    TASSIGN(v121, v122);
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    __gm__ float* v123 = PTOAS__GLOBAL_TENSOR_DATA(v81);
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    const int64_t v124 = 0;
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    const int64_t v125 = 2048;
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 128> v126 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 2048, 1> v127 = pto::Stride<2048, 2048, 2048, 2048, 1>();
    // pto: %routed_w3_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND> v128 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND>(v123 + (v124 + v105 * v125 + v90), v126, v127);
    TLOAD(v121, v128);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %0
    ;
    Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %0
    ;
    uint64_t v130 = (uint64_t) v17;
    TASSIGN(v129, v130);
    // pto: %45
    ;
    int64_t v131 = v87 < v27 ? v27 : v87;
    // pto: %46
    ;
    __gm__ int32_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v49);
    // pto: %46
    ;
    const int64_t v133 = 0;
    // pto: %46
    ;
    pto::Shape<1, 1, 1, 16, 128> v134 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %46
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v135 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %46
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v136 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v132 + (v133 + v131), v134, v135);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v129, v136);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %1
    ;
    Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %1
    ;
    uint64_t v138 = (uint64_t) v18;
    TASSIGN(v137, v138);
    // pto: %48
    ;
    __gm__ int32_t* v139 = PTOAS__GLOBAL_TENSOR_DATA(v57);
    // pto: %48
    ;
    const int64_t v140 = 0;
    // pto: %48
    ;
    pto::Shape<1, 1, 1, 16, 128> v141 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %48
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v142 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %48
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v143 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v139 + (v140 + v131), v141, v142);
    TLOAD(v137, v143);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
    // pto: %2
    ;
    uint64_t v145 = (uint64_t) v19;
    TASSIGN(v144, v145);
    TLOAD(v144, v112);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v30);
    // pto: %3
    ;
    uint64_t v147 = (uint64_t) v20;
    TASSIGN(v146, v147);
    // pto: %54
    ;
    __gm__ float* v148 = PTOAS__GLOBAL_TENSOR_DATA(v73);
    // pto: %54
    ;
    const int64_t v149 = 0;
    // pto: %54
    ;
    const int64_t v150 = 2048;
    // pto: %54
    ;
    pto::Shape<1, 1, 1, 1, 128> v151 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %54
    ;
    pto::Stride<2048, 2048, 2048, 2048, 1> v152 = pto::Stride<2048, 2048, 2048, 2048, 1>();
    // pto: %54
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND> v153 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND>(v148 + (v149 + v105 * v150 + v131), v151, v152);
    TLOAD(v146, v153);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v30);
    // pto: %4
    ;
    uint64_t v155 = (uint64_t) v21;
    TASSIGN(v154, v155);
    // pto: %57
    ;
    __gm__ float* v156 = PTOAS__GLOBAL_TENSOR_DATA(v81);
    // pto: %57
    ;
    const int64_t v157 = 0;
    // pto: %57
    ;
    const int64_t v158 = 2048;
    // pto: %57
    ;
    pto::Shape<1, 1, 1, 1, 128> v159 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %57
    ;
    pto::Stride<2048, 2048, 2048, 2048, 1> v160 = pto::Stride<2048, 2048, 2048, 2048, 1>();
    // pto: %57
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND> v161 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<2048, 2048, 2048, 2048, 1>, pto::Layout::ND>(v156 + (v157 + v105 * v158 + v131), v159, v160);
    TLOAD(v154, v161);
    // pto: %recv_x_scale_tile_inline472__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %recv_x_scale_tile_inline472__tile
    ;
    uint64_t v163 = (uint64_t) v14;
    TASSIGN(v162, v163);
    // pto: %gate_2d_inline475__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %gate_2d_inline475__tile
    ;
    uint64_t v165 = (uint64_t) v12;
    TASSIGN(v164, v165);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v166 = RoundMode::CAST_NONE;
    SaturationMode v167 = SaturationMode::OFF;
    TCVT(v164, v88, v166, v167);
    // pto: %up_2d_inline476__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %up_2d_inline476__tile
    ;
    uint64_t v169 = (uint64_t) v13;
    TASSIGN(v168, v169);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v170 = RoundMode::CAST_NONE;
    SaturationMode v171 = SaturationMode::OFF;
    TCVT(v168, v96, v170, v171);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %t__tile
    ;
    uint64_t v173 = (uint64_t) v12;
    TASSIGN(v172, v173);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TROWEXPANDMUL(v172, v164, v162);
    // pto: %gate_2d_v1_inline477__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %gate_2d_v1_inline477__tile
    ;
    uint64_t v175 = (uint64_t) v12;
    TASSIGN(v174, v175);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPANDMUL(v174, v172, v113);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %5
    ;
    uint64_t v177 = (uint64_t) v13;
    TASSIGN(v176, v177);
    TROWEXPANDMUL(v176, v168, v162);
    // pto: %up_2d_v1_inline478__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %up_2d_v1_inline478__tile
    ;
    uint64_t v179 = (uint64_t) v13;
    TASSIGN(v178, v179);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v178, v176, v121);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %6
    ;
    uint64_t v181 = (uint64_t) v12;
    TASSIGN(v180, v181);
    TMINS(v180, v174, v31);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %7
    ;
    uint64_t v183 = (uint64_t) v13;
    TASSIGN(v182, v183);
    pipe_barrier(PIPE_V);
    TMINS(v182, v178, v31);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %8
    ;
    uint64_t v185 = (uint64_t) v13;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TMAXS(v184, v182, v32);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %9
    ;
    uint64_t v187 = (uint64_t) v15;
    TASSIGN(v186, v187);
    TNEG(v186, v180);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %10
    ;
    uint64_t v189 = (uint64_t) v15;
    TASSIGN(v188, v189);
    pipe_barrier(PIPE_V);
    TEXP(v188, v186);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %11
    ;
    uint64_t v191 = (uint64_t) v15;
    TASSIGN(v190, v191);
    pipe_barrier(PIPE_V);
    TADDS(v190, v188, v33);
    // pto: %sigmoid_inline479__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %sigmoid_inline479__tile
    ;
    uint64_t v193 = (uint64_t) v16;
    TASSIGN(v192, v193);
    pipe_barrier(PIPE_V);
    TRECIP(v192, v190);
    // pto: %silu_inline480__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %silu_inline480__tile
    ;
    uint64_t v195 = (uint64_t) v12;
    TASSIGN(v194, v195);
    pipe_barrier(PIPE_V);
    TMUL(v194, v180, v192);
    // pto: %gated_inline481__tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %gated_inline481__tile
    ;
    uint64_t v197 = (uint64_t) v12;
    TASSIGN(v196, v197);
    pipe_barrier(PIPE_V);
    TMUL(v196, v194, v184);
    v196.SetValidShape(v9, v30);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v198 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v22, v30);
    // pto: %12
    ;
    uint64_t v199 = (uint64_t) v12;
    TASSIGN(v198, v199);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v198, v196);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %h_tile_fp32_inline464__iter_v1_pview
    ;
    __gm__ float* v200 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %h_tile_fp32_inline464__iter_v1_pview
    ;
    const int64_t v201 = 0;
    // pto: %h_tile_fp32_inline464__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v202 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %h_tile_fp32_inline464__iter_v1_pview
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v203 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %h_tile_fp32_inline464__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v204 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v200 + (v201 + v90), v202, v203);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v204, v198);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %13
    ;
    uint64_t v206 = (uint64_t) v19;
    TASSIGN(v205, v206);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %14
    ;
    uint64_t v208 = (uint64_t) v17;
    TASSIGN(v207, v208);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    RoundMode v209 = RoundMode::CAST_NONE;
    SaturationMode v210 = SaturationMode::OFF;
    TCVT(v207, v129, v209, v210);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %15
    ;
    uint64_t v212 = (uint64_t) v18;
    TASSIGN(v211, v212);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    RoundMode v213 = RoundMode::CAST_NONE;
    SaturationMode v214 = SaturationMode::OFF;
    TCVT(v211, v137, v213, v214);
    // pto: %16
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %16
    ;
    uint64_t v216 = (uint64_t) v17;
    TASSIGN(v215, v216);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TROWEXPANDMUL(v215, v207, v205);
    // pto: %17
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %17
    ;
    uint64_t v218 = (uint64_t) v17;
    TASSIGN(v217, v218);
    pipe_barrier(PIPE_V);
    pipe_barrier(PIPE_ALL);
    TCOLEXPANDMUL(v217, v215, v146);
    // pto: %18
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %18
    ;
    uint64_t v220 = (uint64_t) v18;
    TASSIGN(v219, v220);
    TROWEXPANDMUL(v219, v211, v205);
    // pto: %19
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %19
    ;
    uint64_t v222 = (uint64_t) v18;
    TASSIGN(v221, v222);
    pipe_barrier(PIPE_V);
    pipe_barrier(PIPE_ALL);
    TCOLEXPANDMUL(v221, v219, v154);
    // pto: %20
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %20
    ;
    uint64_t v224 = (uint64_t) v17;
    TASSIGN(v223, v224);
    TMINS(v223, v217, v31);
    // pto: %21
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %21
    ;
    uint64_t v226 = (uint64_t) v18;
    TASSIGN(v225, v226);
    pipe_barrier(PIPE_V);
    TMINS(v225, v221, v31);
    // pto: %22
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %22
    ;
    uint64_t v228 = (uint64_t) v18;
    TASSIGN(v227, v228);
    pipe_barrier(PIPE_V);
    TMAXS(v227, v225, v32);
    // pto: %23
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %23
    ;
    uint64_t v230 = (uint64_t) v20;
    TASSIGN(v229, v230);
    TNEG(v229, v223);
    // pto: %24
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %24
    ;
    uint64_t v232 = (uint64_t) v20;
    TASSIGN(v231, v232);
    pipe_barrier(PIPE_V);
    TEXP(v231, v229);
    // pto: %25
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %25
    ;
    uint64_t v234 = (uint64_t) v20;
    TASSIGN(v233, v234);
    pipe_barrier(PIPE_V);
    TADDS(v233, v231, v33);
    // pto: %26
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %26
    ;
    uint64_t v236 = (uint64_t) v21;
    TASSIGN(v235, v236);
    pipe_barrier(PIPE_V);
    TRECIP(v235, v233);
    // pto: %27
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %27
    ;
    uint64_t v238 = (uint64_t) v17;
    TASSIGN(v237, v238);
    pipe_barrier(PIPE_V);
    TMUL(v237, v223, v235);
    // pto: %28
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
    // pto: %28
    ;
    uint64_t v240 = (uint64_t) v17;
    TASSIGN(v239, v240);
    pipe_barrier(PIPE_V);
    TMUL(v239, v237, v227);
    v239.SetValidShape(v9, v30);
    // pto: %30
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v241 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v22, v30);
    // pto: %30
    ;
    uint64_t v242 = (uint64_t) v17;
    TASSIGN(v241, v242);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v241, v239);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %h_tile_fp32_inline464__tile_pview
    ;
    __gm__ float* v243 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %h_tile_fp32_inline464__tile_pview
    ;
    const int64_t v244 = 0;
    // pto: %h_tile_fp32_inline464__tile_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v245 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %h_tile_fp32_inline464__tile_pview
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v246 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %h_tile_fp32_inline464__tile_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v247 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v243 + (v244 + v131), v245, v246);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v247, v241);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}