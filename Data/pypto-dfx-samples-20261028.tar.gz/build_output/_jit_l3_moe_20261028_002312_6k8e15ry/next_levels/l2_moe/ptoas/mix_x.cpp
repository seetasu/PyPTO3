#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mix_x(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c33024_i64
  const int64_t v8 = 33024;
  // pto: %c41216_i64
  const int64_t v9 = 41216;
  // pto: %c32768_i64
  const int64_t v10 = 32768;
  // pto: %c32800_i64
  const int64_t v11 = 32800;
  // pto: %c32832_i64
  const int64_t v12 = 32832;
  // pto: %c32864_i64
  const int64_t v13 = 32864;
  // pto: %c49408_i64
  const int64_t v14 = 49408;
  // pto: %c57600_i64
  const int64_t v15 = 57600;
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c8192_i64
  const int64_t v17 = 8192;
  // pto: %c16384_i64
  const int64_t v18 = 16384;
  // pto: %c24576_i64
  const int64_t v19 = 24576;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c4096_index
  const int64_t v22 = 4096;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c4_index
  const int64_t v24 = 4;
  // pto: %c1024_index
  const int64_t v25 = 1024;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c256_index
  const int64_t v28 = 256;
  // pto: %c8192_index
  const int64_t v29 = 8192;
  // pto: %c12288_index
  const int64_t v30 = 12288;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  int64_t v34 = (int64_t) v4;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  int64_t v35 = v34 * v20;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  int64_t v36 = v33 * v35;
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v34, v20);
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v36, v36, v35, v20, v21);
  // pto: %pre_val_store_v1_inline23__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v37, v38);
  // pto: %x_mixed_inline0__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %x_mixed_inline0__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %x_mixed_inline0__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %x_mixed_inline0__ssa_v0_view
  int64_t v43 = v20 * v22;
  // pto: %x_mixed_inline0__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %x_mixed_inline0__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v20, v22);
  // pto: %x_mixed_inline0__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v22, v21);
  // pto: %x_mixed_inline0__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v45, v46);
  // pto: %x_flat_inline19__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %x_flat_inline19__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline19__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline19__ssa_v0_view
  int64_t v51 = (int64_t) v5;
  // pto: %x_flat_inline19__ssa_v0_view
  int64_t v52 = v51 * v23;
  // pto: %x_flat_inline19__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %x_flat_inline19__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v23);
  // pto: %x_flat_inline19__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v23, v21);
  // pto: %x_flat_inline19__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v54, v55);
  // pto: %blk_inline24__ssa_v0
  int64_t v57 = (int64_t) v6;
  // pto: %18, %19
  int64_t v58 = (int64_t) ((uint64_t) (v57 / v24) * (uint64_t) v20);
  // pto: %20, %21
  int64_t v59 = (int64_t) ((uint64_t) (v57 % v24) * (uint64_t) v25);
  // pto: %t__tile
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v20);
  // pto: %t__tile
  uint64_t v61 = (uint64_t) v8;
  TASSIGN(v60, v61);
  // pto: %22
  int64_t v62 = v58 < v26 ? v26 : v58;
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  __gm__ float* v63 = PTOAS__GLOBAL_TENSOR_DATA(v39);
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  const int64_t v64 = 0;
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  const int64_t v65 = 8;
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  pto::Shape<1, 1, 1, 8, 8> v66 = pto::Shape<1, 1, 1, 8, 8>();
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  pto::Stride<64, 64, 64, 8, 1> v67 = pto::Stride<64, 64, 64, 8, 1>();
  // pto: %pre_val_store_v1_inline23__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND>(v63 + (v64 + v62 * v65), v66, v67);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v60, v68);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %transpose_tmp
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v20);
  // pto: %transpose_tmp
  uint64_t v70 = (uint64_t) v9;
  TASSIGN(v69, v70);
  // pto: %pre_tile_t_inline27__tile
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v20);
  // pto: %pre_tile_t_inline27__tile
  uint64_t v72 = (uint64_t) v10;
  TASSIGN(v71, v72);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TTRANS(v71, v60, v69);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %0
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v20);
  // pto: %0
  uint64_t v74 = (uint64_t) v10;
  TASSIGN(v73, v74);
  // pto: %pre0_inline28__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
  // pto: %pre0_inline28__tile
  uint64_t v76 = (uint64_t) v10;
  TASSIGN(v75, v76);
  // pto: %1
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v20);
  // pto: %1
  uint64_t v78 = (uint64_t) v11;
  TASSIGN(v77, v78);
  // pto: %pre1_inline29__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
  // pto: %pre1_inline29__tile
  uint64_t v80 = (uint64_t) v11;
  TASSIGN(v79, v80);
  // pto: %2
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v20);
  // pto: %2
  uint64_t v82 = (uint64_t) v12;
  TASSIGN(v81, v82);
  // pto: %pre2_inline30__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
  // pto: %pre2_inline30__tile
  uint64_t v84 = (uint64_t) v12;
  TASSIGN(v83, v84);
  // pto: %3
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v20);
  // pto: %3
  uint64_t v86 = (uint64_t) v13;
  TASSIGN(v85, v86);
  // pto: %pre3_inline31__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
  // pto: %pre3_inline31__tile
  uint64_t v88 = (uint64_t) v13;
  TASSIGN(v87, v88);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v89 = v26; v89 < v24; v89 += v27) {
    // pto: %26
    ;
    int64_t v90 = (int64_t) ((uint64_t) v89 * (uint64_t) v28);
    // pto: %27
    ;
    int64_t v91 = (int64_t) ((uint64_t) v59 + (uint64_t) v90);
    // pto: %29
    ;
    int64_t v92 = (int64_t) ((uint64_t) v90 + (uint64_t) v28);
    // pto: %30
    ;
    int64_t v93 = (int64_t) ((uint64_t) v59 + (uint64_t) v92);
    // pto: %x0_inline34__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %x0_inline34__tile
    ;
    uint64_t v95 = (uint64_t) v8;
    TASSIGN(v94, v95);
    // pto: %32
    ;
    int64_t v96 = v91 < v26 ? v26 : v91;
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    const int64_t v98 = 0;
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    const int64_t v99 = 16384;
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 8, 256> v100 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v101 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %x_flat_inline19__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v97 + (v98 + v62 * v99 + v96), v100, v101);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v94, v102);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %x1_inline35__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %x1_inline35__tile
    ;
    uint64_t v104 = (uint64_t) v9;
    TASSIGN(v103, v104);
    // pto: %34
    ;
    int64_t v105 = (int64_t) ((uint64_t) v91 + (uint64_t) v22);
    // pto: %35
    ;
    int64_t v106 = v105 < v26 ? v26 : v105;
    // pto: %36
    ;
    __gm__ float* v107 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %36
    ;
    const int64_t v108 = 0;
    // pto: %36
    ;
    const int64_t v109 = 16384;
    // pto: %36
    ;
    pto::Shape<1, 1, 1, 8, 256> v110 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %36
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v111 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %36
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v112 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v107 + (v108 + v62 * v109 + v106), v110, v111);
    TLOAD(v103, v112);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %x2_inline36__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %x2_inline36__tile
    ;
    uint64_t v114 = (uint64_t) v14;
    TASSIGN(v113, v114);
    // pto: %38
    ;
    int64_t v115 = (int64_t) ((uint64_t) v91 + (uint64_t) v29);
    // pto: %39
    ;
    int64_t v116 = v115 < v26 ? v26 : v115;
    // pto: %40
    ;
    __gm__ float* v117 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %40
    ;
    const int64_t v118 = 0;
    // pto: %40
    ;
    const int64_t v119 = 16384;
    // pto: %40
    ;
    pto::Shape<1, 1, 1, 8, 256> v120 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %40
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v121 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %40
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v122 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v117 + (v118 + v62 * v119 + v116), v120, v121);
    TLOAD(v113, v122);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %x3_inline37__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %x3_inline37__tile
    ;
    uint64_t v124 = (uint64_t) v15;
    TASSIGN(v123, v124);
    // pto: %42
    ;
    int64_t v125 = (int64_t) ((uint64_t) v91 + (uint64_t) v30);
    // pto: %43
    ;
    int64_t v126 = v125 < v26 ? v26 : v125;
    // pto: %44
    ;
    __gm__ float* v127 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %44
    ;
    const int64_t v128 = 0;
    // pto: %44
    ;
    const int64_t v129 = 16384;
    // pto: %44
    ;
    pto::Shape<1, 1, 1, 8, 256> v130 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %44
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v131 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %44
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v127 + (v128 + v62 * v129 + v126), v130, v131);
    TLOAD(v123, v132);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %4
    ;
    uint64_t v134 = (uint64_t) v16;
    TASSIGN(v133, v134);
    // pto: %46
    ;
    int64_t v135 = v93 < v26 ? v26 : v93;
    // pto: %47
    ;
    __gm__ float* v136 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %47
    ;
    const int64_t v137 = 0;
    // pto: %47
    ;
    const int64_t v138 = 16384;
    // pto: %47
    ;
    pto::Shape<1, 1, 1, 8, 256> v139 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %47
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v140 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %47
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v141 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v136 + (v137 + v62 * v138 + v135), v139, v140);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v133, v141);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %5
    ;
    uint64_t v143 = (uint64_t) v17;
    TASSIGN(v142, v143);
    // pto: %49
    ;
    int64_t v144 = (int64_t) ((uint64_t) v93 + (uint64_t) v22);
    // pto: %50
    ;
    int64_t v145 = v144 < v26 ? v26 : v144;
    // pto: %51
    ;
    __gm__ float* v146 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %51
    ;
    const int64_t v147 = 0;
    // pto: %51
    ;
    const int64_t v148 = 16384;
    // pto: %51
    ;
    pto::Shape<1, 1, 1, 8, 256> v149 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %51
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v150 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %51
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v146 + (v147 + v62 * v148 + v145), v149, v150);
    TLOAD(v142, v151);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %6
    ;
    uint64_t v153 = (uint64_t) v18;
    TASSIGN(v152, v153);
    // pto: %53
    ;
    int64_t v154 = (int64_t) ((uint64_t) v93 + (uint64_t) v29);
    // pto: %54
    ;
    int64_t v155 = v154 < v26 ? v26 : v154;
    // pto: %55
    ;
    __gm__ float* v156 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %55
    ;
    const int64_t v157 = 0;
    // pto: %55
    ;
    const int64_t v158 = 16384;
    // pto: %55
    ;
    pto::Shape<1, 1, 1, 8, 256> v159 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %55
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v160 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %55
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v161 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v156 + (v157 + v62 * v158 + v155), v159, v160);
    TLOAD(v152, v161);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %7
    ;
    uint64_t v163 = (uint64_t) v19;
    TASSIGN(v162, v163);
    // pto: %57
    ;
    int64_t v164 = (int64_t) ((uint64_t) v93 + (uint64_t) v30);
    // pto: %58
    ;
    int64_t v165 = v164 < v26 ? v26 : v164;
    // pto: %59
    ;
    __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %59
    ;
    const int64_t v167 = 0;
    // pto: %59
    ;
    const int64_t v168 = 16384;
    // pto: %59
    ;
    pto::Shape<1, 1, 1, 8, 256> v169 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %59
    ;
    pto::Stride<131072, 131072, 131072, 16384, 1> v170 = pto::Stride<131072, 131072, 131072, 16384, 1>();
    // pto: %59
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v166 + (v167 + v62 * v168 + v165), v169, v170);
    TLOAD(v162, v171);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %y0_inline38__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y0_inline38__tile
    ;
    uint64_t v173 = (uint64_t) v8;
    TASSIGN(v172, v173);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v172, v94, v75);
    // pto: %y1_inline39__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y1_inline39__tile
    ;
    uint64_t v175 = (uint64_t) v9;
    TASSIGN(v174, v175);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TROWEXPANDMUL(v174, v103, v79);
    // pto: %y2_inline40__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y2_inline40__tile
    ;
    uint64_t v177 = (uint64_t) v14;
    TASSIGN(v176, v177);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TROWEXPANDMUL(v176, v113, v83);
    // pto: %y3_inline41__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y3_inline41__tile
    ;
    uint64_t v179 = (uint64_t) v15;
    TASSIGN(v178, v179);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TROWEXPANDMUL(v178, v123, v87);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %8
    ;
    uint64_t v181 = (uint64_t) v8;
    TASSIGN(v180, v181);
    pipe_barrier(PIPE_V);
    TADD(v180, v172, v174);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %9
    ;
    uint64_t v183 = (uint64_t) v9;
    TASSIGN(v182, v183);
    pipe_barrier(PIPE_V);
    TADD(v182, v176, v178);
    // pto: %y_tile_inline42__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y_tile_inline42__tile
    ;
    uint64_t v185 = (uint64_t) v8;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TADD(v184, v180, v182);
    // pto: %y_bf16_inline43__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %y_bf16_inline43__tile
    ;
    uint64_t v187 = (uint64_t) v8;
    TASSIGN(v186, v187);
    pipe_barrier(PIPE_V);
    RoundMode v188 = RoundMode::CAST_RINT;
    SaturationMode v189 = SaturationMode::OFF;
    TCVT(v186, v184, v188, v189);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    __gm__ bfloat16_t* v190 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    const int64_t v191 = 0;
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    const int64_t v192 = 4096;
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 256> v193 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    pto::Stride<32768, 32768, 32768, 4096, 1> v194 = pto::Stride<32768, 32768, 32768, 4096, 1>();
    // pto: %x_mixed_inline0__iter_v1_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND> v195 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND>(v190 + (v191 + v62 * v192 + v96), v193, v194);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v195, v186);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %10
    ;
    uint64_t v197 = (uint64_t) v16;
    TASSIGN(v196, v197);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v196, v133, v75);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %11
    ;
    uint64_t v199 = (uint64_t) v17;
    TASSIGN(v198, v199);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v198, v142, v79);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %12
    ;
    uint64_t v201 = (uint64_t) v18;
    TASSIGN(v200, v201);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TROWEXPANDMUL(v200, v152, v83);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %13
    ;
    uint64_t v203 = (uint64_t) v19;
    TASSIGN(v202, v203);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDMUL(v202, v162, v87);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %14
    ;
    uint64_t v205 = (uint64_t) v16;
    TASSIGN(v204, v205);
    pipe_barrier(PIPE_V);
    TADD(v204, v196, v198);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %15
    ;
    uint64_t v207 = (uint64_t) v17;
    TASSIGN(v206, v207);
    pipe_barrier(PIPE_V);
    TADD(v206, v200, v202);
    // pto: %16
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %16
    ;
    uint64_t v209 = (uint64_t) v16;
    TASSIGN(v208, v209);
    pipe_barrier(PIPE_V);
    TADD(v208, v204, v206);
    // pto: %17
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v28);
    // pto: %17
    ;
    uint64_t v211 = (uint64_t) v16;
    TASSIGN(v210, v211);
    pipe_barrier(PIPE_V);
    RoundMode v212 = RoundMode::CAST_RINT;
    SaturationMode v213 = SaturationMode::OFF;
    TCVT(v210, v208, v212, v213);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %x_mixed_inline0__tile_pview
    ;
    __gm__ bfloat16_t* v214 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %x_mixed_inline0__tile_pview
    ;
    const int64_t v215 = 0;
    // pto: %x_mixed_inline0__tile_pview
    ;
    const int64_t v216 = 4096;
    // pto: %x_mixed_inline0__tile_pview
    ;
    pto::Shape<1, 1, 1, 8, 256> v217 = pto::Shape<1, 1, 1, 8, 256>();
    // pto: %x_mixed_inline0__tile_pview
    ;
    pto::Stride<32768, 32768, 32768, 4096, 1> v218 = pto::Stride<32768, 32768, 32768, 4096, 1>();
    // pto: %x_mixed_inline0__tile_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND> v219 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND>(v214 + (v215 + v62 * v216 + v135), v217, v218);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v219, v210);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}