#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void split_pre_post(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, int64_t v6, int64_t v7, float v8, float v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c256_i64
  const int64_t v13 = 256;
  // pto: %c288_i64
  const int64_t v14 = 288;
  // pto: %c320_i64
  const int64_t v15 = 320;
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c8_index
  const int64_t v17 = 8;
  // pto: %c4_index
  const int64_t v18 = 4;
  // pto: %c1_index
  const int64_t v19 = 1;
  // pto: %c24_index
  const int64_t v20 = 24;
  // pto: %c32_index
  const int64_t v21 = 32;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %cst_10
  const float v23 = 1.0f;
  // pto: %cst_11
  const float v24 = 9.99999997E-7f;
  // pto: %cst_12
  const float v25 = 2.0f;
  // pto: %post_ffn_inline1__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %post_ffn_inline1__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %post_ffn_inline1__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %post_ffn_inline1__ssa_v0_view
  int64_t v29 = v17 * v18;
  // pto: %post_ffn_inline1__ssa_v0_view
  int64_t v30 = v28 * v29;
  // pto: %post_ffn_inline1__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v17, v18);
  // pto: %post_ffn_inline1__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v30, v30, v29, v18, v19);
  // pto: %post_ffn_inline1__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %pre_val_store_inline20__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %pre_val_store_inline20__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %pre_val_store_inline20__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %pre_val_store_inline20__ssa_v0_view
  int64_t v37 = (int64_t) v10;
  // pto: %pre_val_store_inline20__ssa_v0_view
  int64_t v38 = v37 * v17;
  // pto: %pre_val_store_inline20__ssa_v0_view
  int64_t v39 = v36 * v38;
  // pto: %pre_val_store_inline20__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v40 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v37, v17);
  // pto: %pre_val_store_inline20__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v41 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v39, v39, v38, v17, v19);
  // pto: %pre_val_store_inline20__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v42 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v40, v41);
  // pto: %hc_inv_rms_inline22__rv_v2_view
  const int64_t v43 = 1;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  const int64_t v44 = 1;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  const int64_t v45 = 1;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  int64_t v46 = (int64_t) v10;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  int64_t v47 = v46 * v19;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  int64_t v48 = v45 * v47;
  // pto: %hc_inv_rms_inline22__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v43, v44, v45, v46, v19);
  // pto: %hc_inv_rms_inline22__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v44 * v48, v48, v47, v19, (int64_t) v10);
  // pto: %hc_inv_rms_inline22__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v49, v50);
  // pto: %hc_ffn_base__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %hc_ffn_base__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %hc_ffn_base__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %hc_ffn_base__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %hc_ffn_base__ssa_v0_view
  int64_t v56 = v20 * v19;
  // pto: %hc_ffn_base__ssa_v0_view
  int64_t v57 = v55 * v56;
  // pto: %hc_ffn_base__ssa_v0_view
  int64_t v58 = v54 * v57;
  // pto: %hc_ffn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v59 = pto::Shape<1, 1, 1, 1, -1>(v52, v53, v54, v55, v20);
  // pto: %hc_ffn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v58, v58, v57, v56, v19);
  // pto: %hc_ffn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v59, v60);
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  const int64_t v62 = 1;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  const int64_t v63 = 1;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  const int64_t v64 = 1;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  int64_t v65 = (int64_t) v10;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  int64_t v66 = v65 * v21;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  int64_t v67 = v64 * v66;
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v21);
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v21, v19);
  // pto: %hc_mixes_raw_inline21__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v68, v69);
  // pto: %split_worker_inline85__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v71 = (int64_t) v11; v71 < v6; v71 += v7) {
    // pto: %12
    ;
    int64_t v72 = (int64_t) ((uint64_t) v71 * (uint64_t) v17);
    // pto: %inv_col_inline87__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
    // pto: %inv_col_inline87__tile
    ;
    uint64_t v74 = (uint64_t) v13;
    TASSIGN(v73, v74);
    // pto: %13
    ;
    int64_t v75 = v72 < v22 ? v22 : v72;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    int64_t v76 = (int64_t) v10;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    const int64_t v77 = 0;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    __gm__ float* v78 = PTOAS__GLOBAL_TENSOR_DATA(v51);
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    const int64_t v79 = 1;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    const int64_t v80 = 1;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    const int64_t v81 = 1;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    int64_t v82 = v17 * v19;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    int64_t v83 = v81 * v82;
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v84 = pto::Shape<1, 1, 1, 8, 1>(v79, v80, v81, v17, v19);
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v83, v83, v82, v19, v76);
    // pto: %hc_inv_rms_inline22__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v78 + (v77 + v75 * v19 + v22 * v76), v84, v85);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v73, v86);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
    // pto: %t__tile
    ;
    uint64_t v88 = (uint64_t) v14;
    TASSIGN(v87, v88);
    // pto: %hc_ffn_base__ssa_v0_pview
    ;
    __gm__ float* v89 = PTOAS__GLOBAL_TENSOR_DATA(v61);
    // pto: %hc_ffn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v90 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_ffn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v91 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_ffn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v89, v90, v91);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v87, v92);
    // pto: %pre_base_inline88__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
    // pto: %pre_base_inline88__tile
    ;
    uint64_t v94 = (uint64_t) v14;
    TASSIGN(v93, v94);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %0
    ;
    uint64_t v96 = (uint64_t) v15;
    TASSIGN(v95, v96);
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    const int64_t v98 = 0;
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    const int64_t v99 = 32;
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 8> v100 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    pto::Stride<256, 256, 256, 32, 1> v101 = pto::Stride<256, 256, 256, 32, 1>();
    // pto: %hc_mixes_raw_inline21__ssa_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND>(v97 + (v98 + v75 * v99), v100, v101);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v95, v102);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %pre_norm_inline89__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %pre_norm_inline89__tile
    ;
    uint64_t v104 = (uint64_t) v15;
    TASSIGN(v103, v104);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDMUL(v103, v95, v73);
    // pto: %pre_scaled_inline90__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %pre_scaled_inline90__tile
    ;
    uint64_t v106 = (uint64_t) v15;
    TASSIGN(v105, v106);
    pipe_barrier(PIPE_V);
    TMULS(v105, v103, v8);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %1
    ;
    uint64_t v108 = (uint64_t) v16;
    TASSIGN(v107, v108);
    TCOLEXPAND(v107, v93);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    // pto: %pre_logits_inline91__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %pre_logits_inline91__tile
    ;
    uint64_t v110 = (uint64_t) v15;
    TASSIGN(v109, v110);
    pipe_barrier(PIPE_V);
    TADD(v109, v105, v107);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %2
    ;
    uint64_t v112 = (uint64_t) v15;
    TASSIGN(v111, v112);
    pipe_barrier(PIPE_V);
    TNEG(v111, v109);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %3
    ;
    uint64_t v114 = (uint64_t) v15;
    TASSIGN(v113, v114);
    pipe_barrier(PIPE_V);
    TEXP(v113, v111);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %4
    ;
    uint64_t v116 = (uint64_t) v15;
    TASSIGN(v115, v116);
    pipe_barrier(PIPE_V);
    TADDS(v115, v113, v23);
    // pto: %pre_sig_inline92__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %pre_sig_inline92__tile
    ;
    uint64_t v118 = (uint64_t) v16;
    TASSIGN(v117, v118);
    pipe_barrier(PIPE_V);
    TRECIP(v117, v115);
    // pto: %pre_val_inline93__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %pre_val_inline93__tile
    ;
    uint64_t v120 = (uint64_t) v15;
    TASSIGN(v119, v120);
    pipe_barrier(PIPE_V);
    TADDS(v119, v117, v24);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    __gm__ float* v121 = PTOAS__GLOBAL_TENSOR_DATA(v42);
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    const int64_t v122 = 0;
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    const int64_t v123 = 8;
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 8> v124 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 8, 1> v125 = pto::Stride<64, 64, 64, 8, 1>();
    // pto: %pre_val_store_inline20__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND> v126 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND>(v121 + (v122 + v75 * v123), v124, v125);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v126, v119);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
    // pto: %5
    ;
    uint64_t v128 = (uint64_t) v14;
    TASSIGN(v127, v128);
    // pto: %16
    ;
    __gm__ float* v129 = PTOAS__GLOBAL_TENSOR_DATA(v61);
    // pto: %16
    ;
    unsigned v130 = 4;
    // pto: %16
    ;
    pto::Shape<1, 1, 1, 1, 8> v131 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %16
    ;
    pto::Stride<8, 8, 8, 8, 1> v132 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %16
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v133 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v129 + v130, v131, v132);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v127, v133);
    // pto: %post_base_inline94__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
    // pto: %post_base_inline94__tile
    ;
    uint64_t v135 = (uint64_t) v14;
    TASSIGN(v134, v135);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %6
    ;
    uint64_t v137 = (uint64_t) v15;
    TASSIGN(v136, v137);
    // pto: %18
    ;
    __gm__ float* v138 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %18
    ;
    const int64_t v139 = 4;
    // pto: %18
    ;
    const int64_t v140 = 32;
    // pto: %18
    ;
    pto::Shape<1, 1, 1, 8, 8> v141 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %18
    ;
    pto::Stride<256, 256, 256, 32, 1> v142 = pto::Stride<256, 256, 256, 32, 1>();
    // pto: %18
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND>(v138 + (v139 + v75 * v140), v141, v142);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v136, v143);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %post_norm_inline95__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %post_norm_inline95__tile
    ;
    uint64_t v145 = (uint64_t) v15;
    TASSIGN(v144, v145);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v144, v136, v73);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %post_scaled_inline96__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %post_scaled_inline96__tile
    ;
    uint64_t v147 = (uint64_t) v15;
    TASSIGN(v146, v147);
    pipe_barrier(PIPE_V);
    TMULS(v146, v144, v9);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %7
    ;
    uint64_t v149 = (uint64_t) v16;
    TASSIGN(v148, v149);
    TCOLEXPAND(v148, v134);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %post_logits_inline97__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %post_logits_inline97__tile
    ;
    uint64_t v151 = (uint64_t) v15;
    TASSIGN(v150, v151);
    pipe_barrier(PIPE_V);
    TADD(v150, v146, v148);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %8
    ;
    uint64_t v153 = (uint64_t) v15;
    TASSIGN(v152, v153);
    pipe_barrier(PIPE_V);
    TNEG(v152, v150);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %9
    ;
    uint64_t v155 = (uint64_t) v15;
    TASSIGN(v154, v155);
    pipe_barrier(PIPE_V);
    TEXP(v154, v152);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %10
    ;
    uint64_t v157 = (uint64_t) v15;
    TASSIGN(v156, v157);
    pipe_barrier(PIPE_V);
    TADDS(v156, v154, v23);
    // pto: %post_sig_inline98__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %post_sig_inline98__tile
    ;
    uint64_t v159 = (uint64_t) v16;
    TASSIGN(v158, v159);
    pipe_barrier(PIPE_V);
    TRECIP(v158, v156);
    // pto: %post_pad_inline99__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v17);
    // pto: %post_pad_inline99__tile
    ;
    uint64_t v161 = (uint64_t) v15;
    TASSIGN(v160, v161);
    pipe_barrier(PIPE_V);
    TMULS(v160, v158, v25);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %11
    ;
    uint64_t v163 = (uint64_t) v15;
    TASSIGN(v162, v163);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164;
    // pto: %slice_view
    ;
    uint64_t v165 = (uint64_t) v15;
    TASSIGN(v164, v165);
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    const int64_t v167 = 0;
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    const int64_t v168 = 4;
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 4> v169 = pto::Shape<1, 1, 1, 8, 4>();
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    pto::Stride<32, 32, 32, 4, 1> v170 = pto::Stride<32, 32, 32, 4, 1>();
    // pto: %post_ffn_inline1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v166 + (v167 + v75 * v168), v169, v170);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v171, v164);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}