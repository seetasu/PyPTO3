#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void exp_up_mm(__gm__ int32_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c8192_i64
  const int64_t v10 = 8192;
  // pto: %c139264_i64
  const int64_t v11 = 139264;
  // pto: %c147456_i64
  const int64_t v12 = 147456;
  // pto: %c6144_i64
  const int64_t v13 = 6144;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c2048_i64
  const int64_t v15 = 2048;
  // pto: %c4096_i64
  const int64_t v16 = 4096;
  // pto: %c16_index
  const int64_t v17 = 16;
  // pto: %c2048_index
  const int64_t v18 = 2048;
  // pto: %c1_index
  const int64_t v19 = 1;
  // pto: %c512_index
  const int64_t v20 = 512;
  // pto: %c4096_index
  const int64_t v21 = 4096;
  // pto: %c32_index
  const int64_t v22 = 32;
  // pto: %c128_index
  const int64_t v23 = 128;
  // pto: %c8388608_index
  const int64_t v24 = 8388608;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  // pto: %c1024_index
  const int64_t v26 = 1024;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c4_index
  const int64_t v28 = 4;
  // pto: %c256_index
  const int64_t v29 = 256;
  // pto: %cn128_index
  const int64_t v30 = -128;
  // pto: %cn512_index
  const int64_t v31 = -512;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  int64_t v35 = v17 * v18;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %up_tile_i32_inline447__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v17, v18);
  // pto: %up_tile_i32_inline447__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v18, v19);
  // pto: %up_tile_i32_inline447__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v37, v38);
  // pto: %recv_x_flat_inline442__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %recv_x_flat_inline442__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %recv_x_flat_inline442__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %recv_x_flat_inline442__ssa_v0_view
  int64_t v43 = v20 * v21;
  // pto: %recv_x_flat_inline442__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %recv_x_flat_inline442__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v20, v21);
  // pto: %recv_x_flat_inline442__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v21, v19);
  // pto: %recv_x_flat_inline442__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v45, v46);
  // pto: %routed_w3__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v48 = pto::Shape<-1, -1, -1, -1, -1>(v22, v23, v23, v17, v22);
  // pto: %routed_w3__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v20, v22, v19);
  // pto: %routed_w3__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v50 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v48, v49);
  // pto: %ub_idx_inline456__ssa_v0, %12
  int64_t v51 = (int64_t) ((uint64_t) ((int64_t) v7) * (uint64_t) v26);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v52 = v27; v52 < v28; v52 += v19) {
    // pto: %13
    ;
    int64_t v53 = (int64_t) ((uint64_t) v52 * (uint64_t) v29);
    // pto: %14
    ;
    int64_t v54 = (int64_t) ((uint64_t) v51 + (uint64_t) v53);
    // pto: %up_acc_inline460__tile
    ;
    Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v29);
    // pto: %up_acc_inline460__tile
    ;
    uint64_t v56 = (uint64_t) v9;
    TASSIGN(v55, v56);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v57 = v27; v57 < v21; v57 += v26) {
      // pto: %x_u_inline462__tile
      ;
      Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v20);
      // pto: %x_u_inline462__tile
      ;
      uint64_t v59 = (uint64_t) v9;
      TASSIGN(v58, v59);
      // pto: %15
      ;
      int64_t v60 = v4 < v27 ? v27 : v4;
      // pto: %16
      ;
      int64_t v61 = v57 < v27 ? v27 : v57;
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      __gm__ int8_t* v62 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      const int64_t v63 = 0;
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      const int64_t v64 = 4096;
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v65 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v66 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %recv_x_flat_inline442__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v67 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v62 + (v63 + v60 * v64 + v61), v65, v66);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v58, v67);
      // pto: %w3_k_inline463__tile
      ;
      Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v29, v20);
      // pto: %w3_k_inline463__tile
      ;
      uint64_t v69 = (uint64_t) v10;
      TASSIGN(v68, v69);
      // pto: %17
      ;
      int64_t v70 = v5 < v27 ? v27 : v5;
      // pto: %18
      ;
      int64_t v71 = v57 / v22;
      // pto: %19
      ;
      int64_t v72 = v71 < v27 ? v27 : v71;
      // pto: %20
      ;
      int64_t v73 = v54 / v17;
      // pto: %21
      ;
      int64_t v74 = v73 < v27 ? v27 : v73;
      // pto: %routed_w3__ssa_v0_pview
      ;
      __gm__ int8_t* v75 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %routed_w3__ssa_v0_pview
      ;
      const int64_t v76 = 0;
      // pto: %routed_w3__ssa_v0_pview
      ;
      const int64_t v77 = 8388608;
      // pto: %routed_w3__ssa_v0_pview
      ;
      const int64_t v78 = 65536;
      // pto: %routed_w3__ssa_v0_pview
      ;
      const int64_t v79 = 512;
      // pto: %routed_w3__ssa_v0_pview
      ;
      pto::Shape<1, 16, 16, 16, 32> v80 = pto::Shape<1, 16, 16, 16, 32>();
      // pto: %routed_w3__ssa_v0_pview
      ;
      pto::Stride<8388608, 65536, 512, 32, 1> v81 = pto::Stride<8388608, 65536, 512, 32, 1>();
      // pto: %routed_w3__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ> v82 = GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ>(v75 + ((v76 + v70 * v77) + v72 * v78 + v74 * v79), v80, v81);
      __gm__ int8_t* v83 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      __gm__ uint8_t* v84 = reinterpret_cast<__gm__ uint8_t*>(v83);
      __gm__ int8_t* v85 = (__gm__ int8_t*) (v84 + v6);
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ> v86(nullptr);
      v86 = v82;
      TASSIGN(v86, v85);
      TLOAD(v68, v86);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v20);
      // pto: %0
      ;
      uint64_t v88 = (uint64_t) v11;
      TASSIGN(v87, v88);
      // pto: %23
      ;
      int64_t v89 = (int64_t) ((uint64_t) v57 + (uint64_t) v20);
      // pto: %24
      ;
      int64_t v90 = v89 < v27 ? v27 : v89;
      // pto: %25
      ;
      __gm__ int8_t* v91 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %25
      ;
      const int64_t v92 = 0;
      // pto: %25
      ;
      const int64_t v93 = 4096;
      // pto: %25
      ;
      pto::Shape<1, 1, 1, 16, 512> v94 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %25
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v95 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %25
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v96 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v91 + (v92 + v60 * v93 + v90), v94, v95);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v87, v96);
      // pto: %1
      ;
      Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v29, v20);
      // pto: %1
      ;
      uint64_t v98 = (uint64_t) v12;
      TASSIGN(v97, v98);
      // pto: %28
      ;
      int64_t v99 = (int64_t) ((uint64_t) v71 + (uint64_t) v17);
      // pto: %29
      ;
      int64_t v100 = v99 < v27 ? v27 : v99;
      // pto: %32
      ;
      __gm__ int8_t* v101 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %32
      ;
      const int64_t v102 = 0;
      // pto: %32
      ;
      const int64_t v103 = 8388608;
      // pto: %32
      ;
      const int64_t v104 = 65536;
      // pto: %32
      ;
      const int64_t v105 = 512;
      // pto: %32
      ;
      pto::Shape<1, 16, 16, 16, 32> v106 = pto::Shape<1, 16, 16, 16, 32>();
      // pto: %32
      ;
      pto::Stride<8388608, 65536, 512, 32, 1> v107 = pto::Stride<8388608, 65536, 512, 32, 1>();
      // pto: %32
      ;
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ> v108 = GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ>(v101 + ((v102 + v70 * v103) + v100 * v104 + v74 * v105), v106, v107);
      __gm__ int8_t* v109 = PTOAS__GLOBAL_TENSOR_DATA(v108);
      __gm__ uint8_t* v110 = reinterpret_cast<__gm__ uint8_t*>(v109);
      __gm__ int8_t* v111 = (__gm__ int8_t*) (v110 + v6);
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 65536, 512, 32, 1>, pto::Layout::NZ> v112(nullptr);
      v112 = v108;
      TASSIGN(v112, v111);
      TLOAD(v97, v112);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %w3_k_inline463__tile_t
      ;
      Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v29);
      // pto: %w3_k_inline463__tile_t
      ;
      uint64_t v114 = (uint64_t) v10;
      TASSIGN(v113, v114);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v115 = v27; v115 < v20; v115 += v29) {
        // pto: %up_acc_inline460__iter_v1_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v23);
        // pto: %up_acc_inline460__iter_v1_l0_a
        ;
        uint64_t v117 = (uint64_t) v13;
        TASSIGN(v116, v117);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_MTE1);
        uint16_t v118 = static_cast<uint16_t>(v27);
        uint16_t v119 = static_cast<uint16_t>(v115);
        TEXTRACT(v116, v58, v118, v119);
        // pto: %up_acc_inline460__iter_v1_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v29);
        // pto: %up_acc_inline460__iter_v1_l0_b
        ;
        uint64_t v121 = (uint64_t) v14;
        TASSIGN(v120, v121);
        uint16_t v122 = static_cast<uint16_t>(v115);
        uint16_t v123 = static_cast<uint16_t>(v27);
        TEXTRACT(v120, v113, v122, v123);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %2
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v23);
        // pto: %2
        ;
        uint64_t v125 = (uint64_t) v9;
        TASSIGN(v124, v125);
        // pto: %33
        ;
        int64_t v126 = (int64_t) ((uint64_t) v115 + (uint64_t) v23);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v127 = static_cast<uint16_t>(v27);
        uint16_t v128 = static_cast<uint16_t>(v126);
        TEXTRACT(v124, v58, v127, v128);
        // pto: %3
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v29);
        // pto: %3
        ;
        uint64_t v130 = (uint64_t) v9;
        TASSIGN(v129, v130);
        uint16_t v131 = static_cast<uint16_t>(v126);
        uint16_t v132 = static_cast<uint16_t>(v27);
        TEXTRACT(v129, v113, v131, v132);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %35
        ;
        bool v133 = v57 == v27;
        // pto: %36, %37
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v133 & v115 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v116, v120);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v116, v120);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %39, %40
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v133 & v115 == v30) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v124, v129);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v124, v129);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %5
      ;
      Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v29);
      // pto: %5
      ;
      uint64_t v135 = (uint64_t) v12;
      TASSIGN(v134, v135);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      for (int64_t v136 = v27; v136 < v20; v136 += v29) {
        // pto: %6
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v23);
        // pto: %6
        ;
        uint64_t v138 = (uint64_t) v15;
        TASSIGN(v137, v138);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v139 = static_cast<uint16_t>(v27);
        uint16_t v140 = static_cast<uint16_t>(v136);
        TEXTRACT(v137, v87, v139, v140);
        // pto: %7
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v29);
        // pto: %7
        ;
        uint64_t v142 = (uint64_t) v14;
        TASSIGN(v141, v142);
        pipe_barrier(PIPE_MTE1);
        uint16_t v143 = static_cast<uint16_t>(v136);
        uint16_t v144 = static_cast<uint16_t>(v27);
        TEXTRACT(v141, v134, v143, v144);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %8
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v23);
        // pto: %8
        ;
        uint64_t v146 = (uint64_t) v16;
        TASSIGN(v145, v146);
        // pto: %42
        ;
        int64_t v147 = (int64_t) ((uint64_t) v136 + (uint64_t) v23);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v148 = static_cast<uint16_t>(v27);
        uint16_t v149 = static_cast<uint16_t>(v147);
        TEXTRACT(v145, v87, v148, v149);
        // pto: %9
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v29);
        // pto: %9
        ;
        uint64_t v151 = (uint64_t) v9;
        TASSIGN(v150, v151);
        uint16_t v152 = static_cast<uint16_t>(v147);
        uint16_t v153 = static_cast<uint16_t>(v27);
        TEXTRACT(v150, v134, v152, v153);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %44
        ;
        bool v154 = v57 == v31;
        // pto: %45, %46
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v154 & v136 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v137, v141);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v137, v141);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %48, %49
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        if (v154 & v136 == v30) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v145, v150);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v145, v150);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %t__tile
    ;
    Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v29);
    // pto: %t__tile
    ;
    uint64_t v156 = (uint64_t) v9;
    TASSIGN(v155, v156);
    // pto: %50
    ;
    int64_t v157 = v54 < v27 ? v27 : v54;
    // pto: %up_tile_i32_inline447__iter_v1_pview
    ;
    __gm__ int32_t* v158 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %up_tile_i32_inline447__iter_v1_pview
    ;
    const int64_t v159 = 0;
    // pto: %up_tile_i32_inline447__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 256> v160 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %up_tile_i32_inline447__iter_v1_pview
    ;
    pto::Stride<32768, 32768, 32768, 2048, 1> v161 = pto::Stride<32768, 32768, 32768, 2048, 1>();
    // pto: %up_tile_i32_inline447__iter_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v162 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v158 + (v159 + v157), v160, v161);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v162, v155);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}