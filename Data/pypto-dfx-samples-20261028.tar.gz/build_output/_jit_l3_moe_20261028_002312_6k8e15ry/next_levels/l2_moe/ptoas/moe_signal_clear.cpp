#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void moe_signal_clear(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int64_t* v5, __gm__ int64_t* v6, __gm__ int64_t* v7, int64_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c1_index
  const int64_t v9 = 1;
  // pto: %c2_index
  const int64_t v10 = 2;
  // pto: %c0_index
  const int64_t v11 = 0;
  // pto: %c0_i32
  const int32_t v12 = 0;
  // pto: %arrived__ssa_v0_view
  const int64_t v13 = 1;
  // pto: %arrived__ssa_v0_view
  const int64_t v14 = 1;
  // pto: %arrived__ssa_v0_view
  const int64_t v15 = 1;
  // pto: %arrived__ssa_v0_view
  int64_t v16 = v10 * v9;
  // pto: %arrived__ssa_v0_view
  int64_t v17 = v15 * v16;
  // pto: %arrived__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v18 = pto::Shape<1, 1, 1, -1, -1>(v13, v14, v15, v10, v9);
  // pto: %arrived__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v19 = pto::Stride<-1, -1, -1, -1, -1>(v14 * v17, v17, v16, v9, v10);
  // pto: %arrived__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v20 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v18, v19);
  // pto: %data_arrived__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %data_arrived__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %data_arrived__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %data_arrived__ssa_v0_view
  int64_t v24 = v10 * v9;
  // pto: %data_arrived__ssa_v0_view
  int64_t v25 = v23 * v24;
  // pto: %data_arrived__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v26 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v10, v9);
  // pto: %data_arrived__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v27 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v25, v25, v24, v9, v10);
  // pto: %data_arrived__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v28 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v26, v27);
  // pto: %combine_arrived__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %combine_arrived__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %combine_arrived__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %combine_arrived__ssa_v0_view
  int64_t v32 = v10 * v9;
  // pto: %combine_arrived__ssa_v0_view
  int64_t v33 = v31 * v32;
  // pto: %combine_arrived__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v34 = pto::Shape<1, 1, 1, -1, -1>(v29, v30, v31, v10, v9);
  // pto: %combine_arrived__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v30 * v33, v33, v32, v9, v10);
  // pto: %combine_arrived__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v36 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v4, v34, v35);
  for (int64_t v37 = v11; v37 < v10; v37 += v9) {
    (v2)[v37] = v12;
    // pto: %arrived__ssa_v0_pview
    ;
    __gm__ int32_t* v38 = PTOAS__GLOBAL_TENSOR_DATA(v20);
    // pto: %arrived__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 2, 1> v39 = pto::Shape<1, 1, 1, 2, 1>();
    // pto: %arrived__ssa_v0_pview
    ;
    pto::Stride<2, 2, 2, 1, 2> v40 = pto::Stride<2, 2, 2, 1, 2>();
    // pto: %arrived__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN> v41 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN>(v38, v39, v40);
    __gm__ int32_t* v42 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    PTOAS__DCCI_SINGLE_CACHE_LINE(v42);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    (v3)[v37] = v12;
    // pto: %data_arrived__ssa_v0_pview
    ;
    __gm__ int32_t* v43 = PTOAS__GLOBAL_TENSOR_DATA(v28);
    // pto: %data_arrived__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 2, 1> v44 = pto::Shape<1, 1, 1, 2, 1>();
    // pto: %data_arrived__ssa_v0_pview
    ;
    pto::Stride<2, 2, 2, 1, 2> v45 = pto::Stride<2, 2, 2, 1, 2>();
    // pto: %data_arrived__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN> v46 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN>(v43, v44, v45);
    __gm__ int32_t* v47 = PTOAS__GLOBAL_TENSOR_DATA(v46);
    PTOAS__DCCI_SINGLE_CACHE_LINE(v47);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    (v4)[v37] = v12;
    // pto: %combine_arrived__ssa_v0_pview
    ;
    __gm__ int32_t* v48 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %combine_arrived__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 2, 1> v49 = pto::Shape<1, 1, 1, 2, 1>();
    // pto: %combine_arrived__ssa_v0_pview
    ;
    pto::Stride<2, 2, 2, 1, 2> v50 = pto::Stride<2, 2, 2, 1, 2>();
    // pto: %combine_arrived__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN> v51 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 2>, pto::Layout::DN>(v48, v49, v50);
    __gm__ int32_t* v52 = PTOAS__GLOBAL_TENSOR_DATA(v51);
    PTOAS__DCCI_SINGLE_CACHE_LINE(v52);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}