#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_linear(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c16384_i64
  const int64_t v14 = 16384;
  // pto: %c49152_i64
  const int64_t v15 = 49152;
  // pto: %c65536_i64
  const int64_t v16 = 65536;
  // pto: %c32768_i64
  const int64_t v17 = 32768;
  // pto: %c32_index
  const int64_t v18 = 32;
  // pto: %c1_index
  const int64_t v19 = 1;
  // pto: %c16384_index
  const int64_t v20 = 16384;
  // pto: %c24_index
  const int64_t v21 = 24;
  // pto: %c4_index
  const int64_t v22 = 4;
  // pto: %c16_index
  const int64_t v23 = 16;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c2_index
  const int64_t v26 = 2;
  // pto: %c256_index
  const int64_t v27 = 256;
  // pto: %cn1_index
  const int64_t v28 = -1;
  // pto: %31
  int64_t v29 = (int64_t) ((uint64_t) v8 * (uint64_t) v22);
  // pto: %mixes_partials_inline64__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %mixes_partials_inline64__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %mixes_partials_inline64__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %mixes_partials_inline64__ssa_v0_view
  int64_t v33 = v29 * v18;
  // pto: %mixes_partials_inline64__ssa_v0_view
  int64_t v34 = v32 * v33;
  // pto: %mixes_partials_inline64__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v35 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v29, v18);
  // pto: %mixes_partials_inline64__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v36 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v34, v34, v33, v18, v19);
  // pto: %mixes_partials_inline64__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v37 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v35, v36);
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v41 = (int64_t) v9;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v42 = v41 * v20;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v43 = v40 * v42;
  // pto: %x_flat_inline46__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v41, v20);
  // pto: %x_flat_inline46__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v43, v43, v42, v20, v19);
  // pto: %x_flat_inline46__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v44, v45);
  // pto: %hc_ffn_fn__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %hc_ffn_fn__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %hc_ffn_fn__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %hc_ffn_fn__ssa_v0_view
  int64_t v50 = v21 * v20;
  // pto: %hc_ffn_fn__ssa_v0_view
  int64_t v51 = v49 * v50;
  // pto: %hc_ffn_fn__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v21, v20);
  // pto: %hc_ffn_fn__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v51, v51, v50, v20, v19);
  // pto: %hc_ffn_fn__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v52, v53);
  // pto: %linear_worker_inline67__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t v55 = (int64_t) v11; v55 < v4; v55 += v5) {
    // pto: %7, %8
    ;
    int64_t v56 = (int64_t) ((uint64_t) (v55 / v22) * (uint64_t) v23);
    // pto: %9
    ;
    int64_t v57 = v55 % v22;
    // pto: %10
    ;
    int64_t v58 = (int64_t) ((uint64_t) v57 * (uint64_t) v24);
    // pto: %11
    ;
    int64_t v59 = (int64_t) ((uint64_t) v9 - (uint64_t) v56);
    // pto: %12
    ;
    int64_t v60 = v59 < v23 ? v59 : v23;
    // pto: %acc_inline72__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v23, v18);
    // pto: %acc_inline72__tile
    ;
    uint64_t v62 = (uint64_t) v13;
    TASSIGN(v61, v62);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v63 = v25; v63 < v23; v63 += v26) {
      // pto: %13
      ;
      int64_t v64 = (int64_t) ((uint64_t) v63 * (uint64_t) v27);
      // pto: %14
      ;
      int64_t v65 = (int64_t) ((uint64_t) v58 + (uint64_t) v64);
      // pto: %16
      ;
      int64_t v66 = (int64_t) ((uint64_t) v64 + (uint64_t) v27);
      // pto: %17
      ;
      int64_t v67 = (int64_t) ((uint64_t) v58 + (uint64_t) v66);
      // pto: %x_linear_chunk_inline74__tile
      ;
      Tile<TileType::Mat, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Mat, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v27);
      // pto: %x_linear_chunk_inline74__tile
      ;
      uint64_t v69 = (uint64_t) v13;
      TASSIGN(v68, v69);
      // pto: %18
      ;
      int64_t v70 = v56 < v25 ? v25 : v56;
      // pto: %19
      ;
      int64_t v71 = v65 < v25 ? v25 : v65;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v72 = 0;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      __gm__ float* v73 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v74 = 1;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v75 = 1;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v76 = 1;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      int64_t v77 = v60 * v20;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      int64_t v78 = v76 * v77;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v79 = pto::Shape<1, 1, 1, -1, 256>(v74, v75, v76, v60, v27);
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v78, v78, v77, v20, v19);
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v73 + (v72 + v70 * v20 + v71 * v19), v79, v80);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v68, v81);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %w_chunk_inline75__tile
      ;
      Tile<TileType::Mat, float, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, float, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %w_chunk_inline75__tile
      ;
      uint64_t v83 = (uint64_t) v14;
      TASSIGN(v82, v83);
      // pto: %hc_ffn_fn__ssa_v0_pview
      ;
      __gm__ float* v84 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %hc_ffn_fn__ssa_v0_pview
      ;
      const int64_t v85 = 0;
      // pto: %hc_ffn_fn__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 24, 256> v86 = pto::Shape<1, 1, 1, 24, 256>();
      // pto: %hc_ffn_fn__ssa_v0_pview
      ;
      pto::Stride<393216, 393216, 393216, 16384, 1> v87 = pto::Stride<393216, 393216, 393216, 16384, 1>();
      // pto: %hc_ffn_fn__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v88 = GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND>(v84 + (v85 + v71), v86, v87);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      __gm__ float* v89 = PTOAS__GLOBAL_TENSOR_DATA(v88);
      __gm__ uint8_t* v90 = reinterpret_cast<__gm__ uint8_t*>(v89);
      __gm__ float* v91 = (__gm__ float*) (v90 + v10);
      GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v92(nullptr);
      v92 = v88;
      TASSIGN(v92, v91);
      TLOAD(v82, v92);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %0
      ;
      Tile<TileType::Mat, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Mat, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v27);
      // pto: %0
      ;
      uint64_t v94 = (uint64_t) v15;
      TASSIGN(v93, v94);
      // pto: %22
      ;
      int64_t v95 = v67 < v25 ? v25 : v67;
      // pto: %23
      ;
      const int64_t v96 = 0;
      // pto: %23
      ;
      __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %23
      ;
      const int64_t v98 = 1;
      // pto: %23
      ;
      const int64_t v99 = 1;
      // pto: %23
      ;
      const int64_t v100 = 1;
      // pto: %23
      ;
      int64_t v101 = v60 * v20;
      // pto: %23
      ;
      int64_t v102 = v100 * v101;
      // pto: %23
      ;
      pto::Shape<1, 1, 1, -1, 256> v103 = pto::Shape<1, 1, 1, -1, 256>(v98, v99, v100, v60, v27);
      // pto: %23
      ;
      pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v20, v19);
      // pto: %23
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v97 + (v96 + v70 * v20 + v95 * v19), v103, v104);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v93, v105);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, float, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, float, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %1
      ;
      uint64_t v107 = (uint64_t) v16;
      TASSIGN(v106, v107);
      // pto: %25
      ;
      __gm__ float* v108 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %25
      ;
      const int64_t v109 = 0;
      // pto: %25
      ;
      pto::Shape<1, 1, 1, 24, 256> v110 = pto::Shape<1, 1, 1, 24, 256>();
      // pto: %25
      ;
      pto::Stride<393216, 393216, 393216, 16384, 1> v111 = pto::Stride<393216, 393216, 393216, 16384, 1>();
      // pto: %25
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v112 = GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND>(v108 + (v109 + v95), v110, v111);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      __gm__ float* v113 = PTOAS__GLOBAL_TENSOR_DATA(v112);
      __gm__ uint8_t* v114 = reinterpret_cast<__gm__ uint8_t*>(v113);
      __gm__ float* v115 = (__gm__ float*) (v114 + v10);
      GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v116(nullptr);
      v116 = v112;
      TASSIGN(v116, v115);
      TLOAD(v106, v116);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %w_chunk_inline75__tile_t
      ;
      Tile<TileType::Mat, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v27, v21);
      // pto: %w_chunk_inline75__tile_t
      ;
      uint64_t v118 = (uint64_t) v14;
      TASSIGN(v117, v118);
      // pto: %x_linear_chunk_inline74__tile_Left
      ;
      Tile<TileType::Left, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Left, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v27);
      // pto: %x_linear_chunk_inline74__tile_Left
      ;
      uint64_t v120 = (uint64_t) v14;
      TASSIGN(v119, v120);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v119, v68);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %w_chunk_inline75__tile_t_Right
      ;
      Tile<TileType::Right, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Right, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v27, v21);
      // pto: %w_chunk_inline75__tile_t_Right
      ;
      uint64_t v122 = (uint64_t) v17;
      TASSIGN(v121, v122);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v121, v117);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %26
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v63 == v25) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v119, v121);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v119, v121);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Mat, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v27, v21);
      // pto: %3
      ;
      uint64_t v124 = (uint64_t) v16;
      TASSIGN(v123, v124);
      // pto: %4
      ;
      Tile<TileType::Left, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Left, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v27);
      // pto: %4
      ;
      uint64_t v126 = (uint64_t) v13;
      TASSIGN(v125, v126);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v125, v93);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Right, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v27, v21);
      // pto: %5
      ;
      uint64_t v128 = (uint64_t) v13;
      TASSIGN(v127, v128);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v127, v123);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %27
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v63 == v28) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v125, v127);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v125, v127);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %28
    ;
    int64_t v129 = (int64_t) ((uint64_t) v57 * (uint64_t) v8);
    // pto: %29
    ;
    int64_t v130 = (int64_t) ((uint64_t) v129 + (uint64_t) v56);
    // pto: %30
    ;
    int64_t v131 = v130 < v25 ? v25 : v130;
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    __gm__ float* v132 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    const int64_t v133 = 0;
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    const int64_t v134 = 32;
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v135 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v136 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %mixes_partials_inline64__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v137 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v132 + (v133 + v131 * v134), v135, v136);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v137, v61);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}