#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_rms(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c32832_i64
  const int64_t v9 = 32832;
  // pto: %c49280_i64
  const int64_t v10 = 49280;
  // pto: %c65664_i64
  const int64_t v11 = 65664;
  // pto: %c82048_i64
  const int64_t v12 = 82048;
  // pto: %c98432_i64
  const int64_t v13 = 98432;
  // pto: %c114816_i64
  const int64_t v14 = 114816;
  // pto: %c131200_i64
  const int64_t v15 = 131200;
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c16384_i64
  const int64_t v17 = 16384;
  // pto: %c16416_i64
  const int64_t v18 = 16416;
  // pto: %c32800_i64
  const int64_t v19 = 32800;
  // pto: %c32864_i64
  const int64_t v20 = 32864;
  // pto: %c49248_i64
  const int64_t v21 = 49248;
  // pto: %c1_index
  const int64_t v22 = 1;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c8_index
  const int64_t v24 = 8;
  // pto: %cst_16
  const float v25 = 0.0f;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c32_index
  const int64_t v27 = 32;
  // pto: %c4_index
  const int64_t v28 = 4;
  // pto: %c512_index
  const int64_t v29 = 512;
  // pto: %c1024_index
  const int64_t v30 = 1024;
  // pto: %c1536_index
  const int64_t v31 = 1536;
  // pto: %cst_23
  const float v32 = 6.10351563E-5f;
  // pto: %cst_24
  const float v33 = 9.99999997E-7f;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  int64_t v37 = (int64_t) v5;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  int64_t v38 = v37 * v22;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  int64_t v39 = v36 * v38;
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v40 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v37, v22);
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v41 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v39, v39, v38, v22, (int64_t) v5);
  // pto: %hc_inv_rms_inline22__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v42 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v1, v40, v41);
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v46 = (int64_t) v6;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v47 = v46 * v23;
  // pto: %x_flat_inline46__ssa_v0_view
  int64_t v48 = v45 * v47;
  // pto: %x_flat_inline46__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v43, v44, v45, v46, v23);
  // pto: %x_flat_inline46__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v44 * v48, v48, v47, v23, v22);
  // pto: %x_flat_inline46__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v49, v50);
  // pto: %rms_worker_inline53__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v52 = (int64_t) v7; v52 < v3; v52 += v4) {
    // pto: %21
    ;
    int64_t v53 = (int64_t) ((uint64_t) v52 * (uint64_t) v24);
    // pto: %sq_sum_inline56__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %sq_sum_inline56__tile
    ;
    uint64_t v55 = (uint64_t) v9;
    TASSIGN(v54, v55);
    TEXPANDS(v54, v25);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    for (int64_t v56 = v26; v56 < v27; v56 += v28) {
      // pto: %22
      ;
      int64_t v57 = (int64_t) ((uint64_t) v56 * (uint64_t) v29);
      // pto: %24
      ;
      int64_t v58 = (int64_t) ((uint64_t) v57 + (uint64_t) v29);
      // pto: %26
      ;
      int64_t v59 = (int64_t) ((uint64_t) v57 + (uint64_t) v30);
      // pto: %28
      ;
      int64_t v60 = (int64_t) ((uint64_t) v57 + (uint64_t) v31);
      // pto: %x_chunk_inline59__tile
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %x_chunk_inline59__tile
      ;
      uint64_t v62 = (uint64_t) v10;
      TASSIGN(v61, v62);
      // pto: %29
      ;
      int64_t v63 = v53 < v26 ? v26 : v53;
      // pto: %30
      ;
      int64_t v64 = v57 < v26 ? v26 : v57;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      __gm__ float* v65 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v66 = 0;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      const int64_t v67 = 16384;
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 512> v68 = pto::Shape<1, 1, 1, 8, 512>();
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 16384, 1> v69 = pto::Stride<131072, 131072, 131072, 16384, 1>();
      // pto: %x_flat_inline46__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v70 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v65 + (v66 + v63 * v67 + v64), v68, v69);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v61, v70);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %0
      ;
      uint64_t v72 = (uint64_t) v11;
      TASSIGN(v71, v72);
      // pto: %32
      ;
      int64_t v73 = v58 < v26 ? v26 : v58;
      // pto: %33
      ;
      __gm__ float* v74 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %33
      ;
      const int64_t v75 = 0;
      // pto: %33
      ;
      const int64_t v76 = 16384;
      // pto: %33
      ;
      pto::Shape<1, 1, 1, 8, 512> v77 = pto::Shape<1, 1, 1, 8, 512>();
      // pto: %33
      ;
      pto::Stride<131072, 131072, 131072, 16384, 1> v78 = pto::Stride<131072, 131072, 131072, 16384, 1>();
      // pto: %33
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v79 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v74 + (v75 + v63 * v76 + v73), v77, v78);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v71, v79);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %1
      ;
      uint64_t v81 = (uint64_t) v12;
      TASSIGN(v80, v81);
      // pto: %35
      ;
      int64_t v82 = v59 < v26 ? v26 : v59;
      // pto: %36
      ;
      __gm__ float* v83 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %36
      ;
      const int64_t v84 = 0;
      // pto: %36
      ;
      const int64_t v85 = 16384;
      // pto: %36
      ;
      pto::Shape<1, 1, 1, 8, 512> v86 = pto::Shape<1, 1, 1, 8, 512>();
      // pto: %36
      ;
      pto::Stride<131072, 131072, 131072, 16384, 1> v87 = pto::Stride<131072, 131072, 131072, 16384, 1>();
      // pto: %36
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v88 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v83 + (v84 + v63 * v85 + v82), v86, v87);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      TLOAD(v80, v88);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %2
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %2
      ;
      uint64_t v90 = (uint64_t) v13;
      TASSIGN(v89, v90);
      // pto: %38
      ;
      int64_t v91 = v60 < v26 ? v26 : v60;
      // pto: %39
      ;
      __gm__ float* v92 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %39
      ;
      const int64_t v93 = 0;
      // pto: %39
      ;
      const int64_t v94 = 16384;
      // pto: %39
      ;
      pto::Shape<1, 1, 1, 8, 512> v95 = pto::Shape<1, 1, 1, 8, 512>();
      // pto: %39
      ;
      pto::Stride<131072, 131072, 131072, 16384, 1> v96 = pto::Stride<131072, 131072, 131072, 16384, 1>();
      // pto: %39
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<131072, 131072, 131072, 16384, 1>, pto::Layout::ND>(v92 + (v93 + v63 * v94 + v91), v95, v96);
      TLOAD(v89, v97);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %x_sq_inline60__tile
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %x_sq_inline60__tile
      ;
      uint64_t v99 = (uint64_t) v10;
      TASSIGN(v98, v99);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TMUL(v98, v61, v61);
      // pto: %tmp_tile
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %tmp_tile
      ;
      uint64_t v101 = (uint64_t) v14;
      TASSIGN(v100, v101);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
      // pto: %t__tile
      ;
      uint64_t v103 = (uint64_t) v15;
      TASSIGN(v102, v103);
      pipe_barrier(PIPE_V);
      TROWSUM(v102, v98, v100);
      // pto: %x_sq_row_inline61__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %x_sq_row_inline61__tile
      ;
      uint64_t v105 = (uint64_t) v15;
      TASSIGN(v104, v105);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %3
      ;
      uint64_t v107 = (uint64_t) v10;
      TASSIGN(v106, v107);
      pipe_barrier(PIPE_V);
      TADD(v106, v54, v104);
      // pto: %4
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %4
      ;
      uint64_t v109 = (uint64_t) v11;
      TASSIGN(v108, v109);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TMUL(v108, v71, v71);
      // pto: %5
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %5
      ;
      uint64_t v111 = (uint64_t) v16;
      TASSIGN(v110, v111);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
      // pto: %6
      ;
      uint64_t v113 = (uint64_t) v17;
      TASSIGN(v112, v113);
      pipe_barrier(PIPE_V);
      TROWSUM(v112, v108, v110);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %7
      ;
      uint64_t v115 = (uint64_t) v17;
      TASSIGN(v114, v115);
      // pto: %8
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %8
      ;
      uint64_t v117 = (uint64_t) v11;
      TASSIGN(v116, v117);
      pipe_barrier(PIPE_V);
      TADD(v116, v106, v114);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %9
      ;
      uint64_t v119 = (uint64_t) v12;
      TASSIGN(v118, v119);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TMUL(v118, v80, v80);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %10
      ;
      uint64_t v121 = (uint64_t) v18;
      TASSIGN(v120, v121);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
      // pto: %11
      ;
      uint64_t v123 = (uint64_t) v19;
      TASSIGN(v122, v123);
      pipe_barrier(PIPE_V);
      TROWSUM(v122, v118, v120);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %12
      ;
      uint64_t v125 = (uint64_t) v19;
      TASSIGN(v124, v125);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %13
      ;
      uint64_t v127 = (uint64_t) v12;
      TASSIGN(v126, v127);
      pipe_barrier(PIPE_V);
      TADD(v126, v116, v124);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %14
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %14
      ;
      uint64_t v129 = (uint64_t) v13;
      TASSIGN(v128, v129);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TMUL(v128, v89, v89);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v29);
      // pto: %15
      ;
      uint64_t v131 = (uint64_t) v20;
      TASSIGN(v130, v131);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
      // pto: %16
      ;
      uint64_t v133 = (uint64_t) v21;
      TASSIGN(v132, v133);
      pipe_barrier(PIPE_V);
      TROWSUM(v132, v128, v130);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %17
      ;
      uint64_t v135 = (uint64_t) v21;
      TASSIGN(v134, v135);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
      // pto: %18
      ;
      uint64_t v137 = (uint64_t) v9;
      TASSIGN(v136, v137);
      pipe_barrier(PIPE_V);
      TADD(v136, v126, v134);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    };
    // pto: %19
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %19
    ;
    uint64_t v139 = (uint64_t) v10;
    TASSIGN(v138, v139);
    pipe_barrier(PIPE_V);
    TMULS(v138, v54, v32);
    // pto: %sq_mean_inline62__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %sq_mean_inline62__tile
    ;
    uint64_t v141 = (uint64_t) v10;
    TASSIGN(v140, v141);
    pipe_barrier(PIPE_V);
    TADDS(v140, v138, v33);
    // pto: %rsqrt_tmp
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %rsqrt_tmp
    ;
    uint64_t v143 = (uint64_t) v11;
    TASSIGN(v142, v143);
    // pto: %20
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v24);
    // pto: %20
    ;
    uint64_t v145 = (uint64_t) v12;
    TASSIGN(v144, v145);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TRSQRT(v144, v140, v142);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %inv_inline63__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
    // pto: %inv_inline63__tile
    ;
    uint64_t v147 = (uint64_t) v12;
    TASSIGN(v146, v147);
    // pto: %40
    ;
    int64_t v148 = v53 < v26 ? v26 : v53;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    int64_t v149 = (int64_t) v5;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    const int64_t v150 = 0;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    __gm__ float* v151 = PTOAS__GLOBAL_TENSOR_DATA(v42);
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    const int64_t v152 = 1;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    const int64_t v153 = 1;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    const int64_t v154 = 1;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    int64_t v155 = v24 * v22;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    int64_t v156 = v154 * v155;
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v157 = pto::Shape<1, 1, 1, 8, 1>(v152, v153, v154, v24, v22);
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v158 = pto::Stride<-1, -1, -1, -1, -1>(v153 * v156, v156, v155, v22, v149);
    // pto: %hc_inv_rms_inline22__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v159 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v151 + (v150 + v148 * v22 + v26 * v149), v157, v158);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v159, v146);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}