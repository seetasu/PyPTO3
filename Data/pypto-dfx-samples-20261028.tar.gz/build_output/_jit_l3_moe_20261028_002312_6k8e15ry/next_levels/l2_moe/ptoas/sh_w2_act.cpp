#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void sh_w2_act(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ int32_t* v3, __gm__ float* v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c36928_i64
  const int64_t v9 = 36928;
  // pto: %c2112_i64
  const int64_t v10 = 2112;
  // pto: %c2048_i64
  const int64_t v11 = 2048;
  // pto: %c34880_i64
  const int64_t v12 = 34880;
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c16_index
  const int64_t v14 = 16;
  // pto: %c8_index
  const int64_t v15 = 8;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c4096_index
  const int64_t v17 = 4096;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %c128_index
  const int64_t v19 = 128;
  // pto: %c2_index
  const int64_t v20 = 2;
  // pto: %c512_index
  const int64_t v21 = 512;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  const int64_t v22 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  const int64_t v23 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  const int64_t v24 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  int64_t v25 = v14 * v15;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  int64_t v26 = v24 * v25;
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v14, v15);
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v26, v26, v25, v15, v16);
  // pto: %h_tile_scale_dq_inline292__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %sh_inline7__iter_v1_view
  const int64_t v30 = 1;
  // pto: %sh_inline7__iter_v1_view
  const int64_t v31 = 1;
  // pto: %sh_inline7__iter_v1_view
  const int64_t v32 = 1;
  // pto: %sh_inline7__iter_v1_view
  int64_t v33 = v15 * v17;
  // pto: %sh_inline7__iter_v1_view
  int64_t v34 = v32 * v33;
  // pto: %sh_inline7__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v35 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v15, v17);
  // pto: %sh_inline7__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v36 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v34, v34, v33, v17, v16);
  // pto: %sh_inline7__iter_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v37 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v35, v36);
  // pto: %y_i32_inline318__ssa_v1_view
  const int64_t v38 = 1;
  // pto: %y_i32_inline318__ssa_v1_view
  const int64_t v39 = 1;
  // pto: %y_i32_inline318__ssa_v1_view
  const int64_t v40 = 1;
  // pto: %y_i32_inline318__ssa_v1_view
  int64_t v41 = v14 * v17;
  // pto: %y_i32_inline318__ssa_v1_view
  int64_t v42 = v40 * v41;
  // pto: %y_i32_inline318__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v14, v17);
  // pto: %y_i32_inline318__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v17, v16);
  // pto: %y_i32_inline318__ssa_v1_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %shared_w2_scale__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %shared_w2_scale__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %shared_w2_scale__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %shared_w2_scale__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %shared_w2_scale__ssa_v0_view
  int64_t v50 = v17 * v16;
  // pto: %shared_w2_scale__ssa_v0_view
  int64_t v51 = v49 * v50;
  // pto: %shared_w2_scale__ssa_v0_view
  int64_t v52 = v48 * v51;
  // pto: %shared_w2_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v53 = pto::Shape<1, 1, 1, 1, -1>(v46, v47, v48, v49, v17);
  // pto: %shared_w2_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v52, v52, v51, v50, v16);
  // pto: %shared_w2_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %db_idx_inline325__ssa_v0, %10
  int64_t v56 = (int64_t) ((uint64_t) ((int64_t) v7) * (uint64_t) v17);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 16, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v15);
  // pto: %t__tile
  uint64_t v58 = (uint64_t) v9;
  TASSIGN(v57, v58);
  // pto: %h_tile_scale_dq_inline292__ssa_v1_pview
  __gm__ float* v59 = PTOAS__GLOBAL_TENSOR_DATA(v29);
  // pto: %h_tile_scale_dq_inline292__ssa_v1_pview
  pto::Shape<1, 1, 1, 16, 8> v60 = pto::Shape<1, 1, 1, 16, 8>();
  // pto: %h_tile_scale_dq_inline292__ssa_v1_pview
  pto::Stride<128, 128, 128, 8, 1> v61 = pto::Stride<128, 128, 128, 8, 1>();
  // pto: %h_tile_scale_dq_inline292__ssa_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 8>, pto::Stride<128, 128, 128, 8, 1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 8>, pto::Stride<128, 128, 128, 8, 1>, pto::Layout::ND>(v59, v60, v61);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v57, v62);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v19);
  // pto: %tmp_tile
  uint64_t v64 = (uint64_t) v10;
  TASSIGN(v63, v64);
  // pto: %h_scale_inline327__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v16);
  // pto: %h_scale_inline327__tile
  uint64_t v66 = (uint64_t) v11;
  TASSIGN(v65, v66);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TROWMAX(v65, v57, v63);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v67 = v18; v67 < v15; v67 += v20) {
    // pto: %11
    ;
    int64_t v68 = (int64_t) ((uint64_t) v67 * (uint64_t) v21);
    // pto: %12
    ;
    int64_t v69 = (int64_t) ((uint64_t) v56 + (uint64_t) v68);
    // pto: %14
    ;
    int64_t v70 = (int64_t) ((uint64_t) v68 + (uint64_t) v21);
    // pto: %15
    ;
    int64_t v71 = (int64_t) ((uint64_t) v56 + (uint64_t) v70);
    // pto: %y_2d_i32_inline329__tile
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %y_2d_i32_inline329__tile
    ;
    uint64_t v73 = (uint64_t) v10;
    TASSIGN(v72, v73);
    // pto: %16
    ;
    int64_t v74 = v69 < v18 ? v18 : v69;
    // pto: %y_i32_inline318__ssa_v1_pview
    ;
    __gm__ int32_t* v75 = PTOAS__GLOBAL_TENSOR_DATA(v45);
    // pto: %y_i32_inline318__ssa_v1_pview
    ;
    const int64_t v76 = 0;
    // pto: %y_i32_inline318__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 512> v77 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %y_i32_inline318__ssa_v1_pview
    ;
    pto::Stride<65536, 65536, 65536, 4096, 1> v78 = pto::Stride<65536, 65536, 65536, 4096, 1>();
    // pto: %y_i32_inline318__ssa_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v79 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v75 + (v76 + v74), v77, v78);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v72, v79);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v21);
    // pto: %0
    ;
    uint64_t v81 = (uint64_t) v12;
    TASSIGN(v80, v81);
    // pto: %shared_w2_scale__ssa_v0_pview
    ;
    __gm__ float* v82 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %shared_w2_scale__ssa_v0_pview
    ;
    const int64_t v83 = 0;
    // pto: %shared_w2_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v84 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %shared_w2_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v85 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %shared_w2_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v82 + (v83 + v74), v84, v85);
    TLOAD(v80, v86);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %1
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %1
    ;
    uint64_t v88 = (uint64_t) v9;
    TASSIGN(v87, v88);
    // pto: %18
    ;
    int64_t v89 = v71 < v18 ? v18 : v71;
    // pto: %19
    ;
    __gm__ int32_t* v90 = PTOAS__GLOBAL_TENSOR_DATA(v45);
    // pto: %19
    ;
    const int64_t v91 = 0;
    // pto: %19
    ;
    pto::Shape<1, 1, 1, 16, 512> v92 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %19
    ;
    pto::Stride<65536, 65536, 65536, 4096, 1> v93 = pto::Stride<65536, 65536, 65536, 4096, 1>();
    // pto: %19
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v94 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v90 + (v91 + v89), v92, v93);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v87, v94);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v21);
    // pto: %2
    ;
    uint64_t v96 = (uint64_t) v13;
    TASSIGN(v95, v96);
    // pto: %21
    ;
    __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %21
    ;
    const int64_t v98 = 0;
    // pto: %21
    ;
    pto::Shape<1, 1, 1, 1, 512> v99 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %21
    ;
    pto::Stride<512, 512, 512, 512, 1> v100 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %21
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v97 + (v98 + v89), v99, v100);
    TLOAD(v95, v101);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %w2_scale_chunk_inline330__tile
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v21);
    // pto: %w2_scale_chunk_inline330__tile
    ;
    uint64_t v103 = (uint64_t) v12;
    TASSIGN(v102, v103);
    // pto: %y_2d_inline331__tile
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %y_2d_inline331__tile
    ;
    uint64_t v105 = (uint64_t) v10;
    TASSIGN(v104, v105);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v106 = RoundMode::CAST_NONE;
    SaturationMode v107 = SaturationMode::OFF;
    TCVT(v104, v72, v106, v107);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %3
    ;
    uint64_t v109 = (uint64_t) v10;
    TASSIGN(v108, v109);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v108, v104, v65);
    // pto: %y_2d_v1_inline332__tile
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %y_2d_v1_inline332__tile
    ;
    uint64_t v111 = (uint64_t) v10;
    TASSIGN(v110, v111);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPANDMUL(v110, v108, v102);
    // pto: %y_bf16_inline333__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %y_bf16_inline333__tile
    ;
    uint64_t v113 = (uint64_t) v10;
    TASSIGN(v112, v113);
    pipe_barrier(PIPE_V);
    RoundMode v114 = RoundMode::CAST_RINT;
    SaturationMode v115 = SaturationMode::OFF;
    TCVT(v112, v110, v114, v115);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    v112.SetValidShape(v5, v21);
    // pto: %22
    ;
    int64_t v116 = v6 < v18 ? v18 : v6;
    // pto: %sh_inline7__iter_v3_pview
    ;
    const int64_t v117 = 0;
    // pto: %sh_inline7__iter_v3_pview
    ;
    __gm__ bfloat16_t* v118 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %sh_inline7__iter_v3_pview
    ;
    const int64_t v119 = 1;
    // pto: %sh_inline7__iter_v3_pview
    ;
    const int64_t v120 = 1;
    // pto: %sh_inline7__iter_v3_pview
    ;
    const int64_t v121 = 1;
    // pto: %sh_inline7__iter_v3_pview
    ;
    int64_t v122 = (int64_t) v5;
    // pto: %sh_inline7__iter_v3_pview
    ;
    int64_t v123 = v122 * v17;
    // pto: %sh_inline7__iter_v3_pview
    ;
    int64_t v124 = v121 * v123;
    // pto: %sh_inline7__iter_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v125 = pto::Shape<1, 1, 1, -1, 512>(v119, v120, v121, v122, v21);
    // pto: %sh_inline7__iter_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v17, v16);
    // pto: %sh_inline7__iter_v3_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v118 + (v117 + v116 * v17 + v74 * v16), v125, v126);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v127, v112);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v21);
    // pto: %4
    ;
    uint64_t v129 = (uint64_t) v13;
    TASSIGN(v128, v129);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %5
    ;
    uint64_t v131 = (uint64_t) v9;
    TASSIGN(v130, v131);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    RoundMode v132 = RoundMode::CAST_NONE;
    SaturationMode v133 = SaturationMode::OFF;
    TCVT(v130, v87, v132, v133);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %6
    ;
    uint64_t v135 = (uint64_t) v9;
    TASSIGN(v134, v135);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v134, v130, v65);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %7
    ;
    uint64_t v137 = (uint64_t) v9;
    TASSIGN(v136, v137);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v136, v134, v128);
    // pto: %8
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v21);
    // pto: %8
    ;
    uint64_t v139 = (uint64_t) v9;
    TASSIGN(v138, v139);
    pipe_barrier(PIPE_V);
    RoundMode v140 = RoundMode::CAST_RINT;
    SaturationMode v141 = SaturationMode::OFF;
    TCVT(v138, v136, v140, v141);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    v138.SetValidShape(v5, v21);
    // pto: %sh_inline7__tile_pview
    ;
    const int64_t v142 = 0;
    // pto: %sh_inline7__tile_pview
    ;
    __gm__ bfloat16_t* v143 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %sh_inline7__tile_pview
    ;
    const int64_t v144 = 1;
    // pto: %sh_inline7__tile_pview
    ;
    const int64_t v145 = 1;
    // pto: %sh_inline7__tile_pview
    ;
    const int64_t v146 = 1;
    // pto: %sh_inline7__tile_pview
    ;
    int64_t v147 = (int64_t) v5;
    // pto: %sh_inline7__tile_pview
    ;
    int64_t v148 = v147 * v17;
    // pto: %sh_inline7__tile_pview
    ;
    int64_t v149 = v146 * v148;
    // pto: %sh_inline7__tile_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v150 = pto::Shape<1, 1, 1, -1, 512>(v144, v145, v146, v147, v21);
    // pto: %sh_inline7__tile_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v151 = pto::Stride<-1, -1, -1, -1, -1>(v145 * v149, v149, v148, v17, v16);
    // pto: %sh_inline7__tile_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v143 + (v142 + v116 * v17 + v89 * v16), v150, v151);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v152, v138);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}