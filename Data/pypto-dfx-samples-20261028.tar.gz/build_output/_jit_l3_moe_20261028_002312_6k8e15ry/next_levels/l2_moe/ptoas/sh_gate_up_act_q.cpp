#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void sh_gate_up_act_q(__gm__ float* v1, __gm__ float* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int8_t* v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c163840_i64
  const int64_t v12 = 163840;
  // pto: %c163872_i64
  const int64_t v13 = 163872;
  // pto: %c98304_i64
  const int64_t v14 = 98304;
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c32768_i64
  const int64_t v16 = 32768;
  // pto: %c65536_i64
  const int64_t v17 = 65536;
  // pto: %c8_index
  const int64_t v18 = 8;
  // pto: %c1_index
  const int64_t v19 = 1;
  // pto: %c16_index
  const int64_t v20 = 16;
  // pto: %c2048_index
  const int64_t v21 = 2048;
  // pto: %c2_index
  const int64_t v22 = 2;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %cst_12
  const float v24 = 9.99999974E-5f;
  // pto: %c1024_index
  const int64_t v25 = 1024;
  // pto: %cst_14
  const float v26 = 10.0f;
  // pto: %cst_15
  const float v27 = -10.0f;
  // pto: %cst_16
  const float v28 = 1.0f;
  // pto: %cst_17
  const float v29 = 127.0f;
  // pto: %cst_18
  const float v30 = 0.0f;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  int64_t v34 = v18 * v19;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %x_norm_scale_inline4__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v18, v19);
  // pto: %x_norm_scale_inline4__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v35, v35, v34, v19, v18);
  // pto: %x_norm_scale_inline4__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v1, v36, v37);
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  int64_t v42 = v20 * v21;
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  int64_t v43 = v41 * v42;
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v20, v21);
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v21, v19);
  // pto: %h_tile_fp32_inline290__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v44, v45);
  // pto: %gate_i32_inline278__ssa_v1_view
  const int64_t v47 = 1;
  // pto: %gate_i32_inline278__ssa_v1_view
  const int64_t v48 = 1;
  // pto: %gate_i32_inline278__ssa_v1_view
  const int64_t v49 = 1;
  // pto: %gate_i32_inline278__ssa_v1_view
  int64_t v50 = v20 * v21;
  // pto: %gate_i32_inline278__ssa_v1_view
  int64_t v51 = v49 * v50;
  // pto: %gate_i32_inline278__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v20, v21);
  // pto: %gate_i32_inline278__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v51, v51, v50, v21, v19);
  // pto: %gate_i32_inline278__ssa_v1_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v52, v53);
  // pto: %up_i32_inline279__ssa_v1_view
  const int64_t v55 = 1;
  // pto: %up_i32_inline279__ssa_v1_view
  const int64_t v56 = 1;
  // pto: %up_i32_inline279__ssa_v1_view
  const int64_t v57 = 1;
  // pto: %up_i32_inline279__ssa_v1_view
  int64_t v58 = v20 * v21;
  // pto: %up_i32_inline279__ssa_v1_view
  int64_t v59 = v57 * v58;
  // pto: %up_i32_inline279__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v20, v21);
  // pto: %up_i32_inline279__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v21, v19);
  // pto: %up_i32_inline279__ssa_v1_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v60, v61);
  // pto: %shared_w1_scale__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %shared_w1_scale__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %shared_w1_scale__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %shared_w1_scale__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %shared_w1_scale__ssa_v0_view
  int64_t v67 = v21 * v19;
  // pto: %shared_w1_scale__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %shared_w1_scale__ssa_v0_view
  int64_t v69 = v65 * v68;
  // pto: %shared_w1_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v70 = pto::Shape<1, 1, 1, 1, -1>(v63, v64, v65, v66, v21);
  // pto: %shared_w1_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v69, v69, v68, v67, v19);
  // pto: %shared_w1_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v72 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v70, v71);
  // pto: %shared_w3_scale__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %shared_w3_scale__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %shared_w3_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %shared_w3_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %shared_w3_scale__ssa_v0_view
  int64_t v77 = v21 * v19;
  // pto: %shared_w3_scale__ssa_v0_view
  int64_t v78 = v76 * v77;
  // pto: %shared_w3_scale__ssa_v0_view
  int64_t v79 = v75 * v78;
  // pto: %shared_w3_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v80 = pto::Shape<1, 1, 1, 1, -1>(v73, v74, v75, v76, v21);
  // pto: %shared_w3_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v74 * v79, v79, v78, v77, v19);
  // pto: %shared_w3_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v80, v81);
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  int64_t v86 = v20 * v18;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v20, v18);
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v18, v19);
  // pto: %h_tile_scale_dq_inline292__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v88, v89);
  // pto: %h_tile_i8_inline291__ssa_v1_view
  const int64_t v91 = 1;
  // pto: %h_tile_i8_inline291__ssa_v1_view
  const int64_t v92 = 1;
  // pto: %h_tile_i8_inline291__ssa_v1_view
  const int64_t v93 = 1;
  // pto: %h_tile_i8_inline291__ssa_v1_view
  int64_t v94 = v20 * v21;
  // pto: %h_tile_i8_inline291__ssa_v1_view
  int64_t v95 = v93 * v94;
  // pto: %h_tile_i8_inline291__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v96 = pto::Shape<1, 1, 1, -1, -1>(v91, v92, v93, v20, v21);
  // pto: %h_tile_i8_inline291__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v21, v19);
  // pto: %h_tile_i8_inline291__ssa_v1_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v96, v97);
  // pto: %row_block_inline293__ssa_v0, %20
  int64_t v99 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v22);
  // pto: %x_scale_inline295__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v19);
  // pto: %x_scale_inline295__tile
  uint64_t v101 = (uint64_t) v12;
  TASSIGN(v100, v101);
  // pto: %21
  int64_t v102 = (int64_t) ((uint64_t) v9 + (uint64_t) v99);
  // pto: %22
  int64_t v103 = v102 < v23 ? v23 : v102;
  // pto: %x_norm_scale_inline4__ssa_v0_pview
  __gm__ float* v104 = PTOAS__GLOBAL_TENSOR_DATA(v38);
  // pto: %x_norm_scale_inline4__ssa_v0_pview
  const int64_t v105 = 0;
  // pto: %x_norm_scale_inline4__ssa_v0_pview
  pto::Shape<1, 1, 1, 2, 1> v106 = pto::Shape<1, 1, 1, 2, 1>();
  // pto: %x_norm_scale_inline4__ssa_v0_pview
  pto::Stride<2, 2, 2, 1, 8> v107 = pto::Stride<2, 2, 2, 1, 8>();
  // pto: %x_norm_scale_inline4__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 8>, pto::Layout::DN> v108 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 1>, pto::Stride<2, 2, 2, 1, 8>, pto::Layout::DN>(v104 + (v105 + v103), v106, v107);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  TLOAD(v100, v108);
  // pto: %row_amax_inline296__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %row_amax_inline296__tile
  uint64_t v110 = (uint64_t) v13;
  TASSIGN(v109, v110);
  TEXPANDS(v109, v24);
  for (int64_t v111 = v23; v111 < v22; v111 += v19) {
    // pto: %23
    ;
    int64_t v112 = (int64_t) ((uint64_t) v111 * (uint64_t) v25);
    // pto: %gate_rows_i32_inline298__tile
    ;
    Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %gate_rows_i32_inline298__tile
    ;
    uint64_t v114 = (uint64_t) v14;
    TASSIGN(v113, v114);
    // pto: %24
    ;
    int64_t v115 = v99 < v23 ? v23 : v99;
    // pto: %25
    ;
    int64_t v116 = v112 < v23 ? v23 : v112;
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    __gm__ int32_t* v117 = PTOAS__GLOBAL_TENSOR_DATA(v54);
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    const int64_t v118 = 0;
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    const int64_t v119 = 2048;
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 2, 1024> v120 = pto::Shape<1, 1, 1, 2, 1024>();
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 2048, 1> v121 = pto::Stride<4096, 4096, 4096, 2048, 1>();
    // pto: %gate_i32_inline278__ssa_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND> v122 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND>(v117 + (v118 + v115 * v119 + v116), v120, v121);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v113, v122);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %up_rows_i32_inline299__tile
    ;
    Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %up_rows_i32_inline299__tile
    ;
    uint64_t v124 = (uint64_t) v15;
    TASSIGN(v123, v124);
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    __gm__ int32_t* v125 = PTOAS__GLOBAL_TENSOR_DATA(v62);
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    const int64_t v126 = 0;
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    const int64_t v127 = 2048;
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 2, 1024> v128 = pto::Shape<1, 1, 1, 2, 1024>();
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 2048, 1> v129 = pto::Stride<4096, 4096, 4096, 2048, 1>();
    // pto: %up_i32_inline279__ssa_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND> v130 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND>(v125 + (v126 + v115 * v127 + v116), v128, v129);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v123, v130);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %t__tile
    ;
    uint64_t v132 = (uint64_t) v16;
    TASSIGN(v131, v132);
    // pto: %shared_w1_scale__ssa_v0_pview
    ;
    __gm__ float* v133 = PTOAS__GLOBAL_TENSOR_DATA(v72);
    // pto: %shared_w1_scale__ssa_v0_pview
    ;
    const int64_t v134 = 0;
    // pto: %shared_w1_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 1024> v135 = pto::Shape<1, 1, 1, 1, 1024>();
    // pto: %shared_w1_scale__ssa_v0_pview
    ;
    pto::Stride<1024, 1024, 1024, 1024, 1> v136 = pto::Stride<1024, 1024, 1024, 1024, 1>();
    // pto: %shared_w1_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v137 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v133 + (v134 + v116), v135, v136);
    TLOAD(v131, v137);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %0
    ;
    uint64_t v139 = (uint64_t) v17;
    TASSIGN(v138, v139);
    // pto: %shared_w3_scale__ssa_v0_pview
    ;
    __gm__ float* v140 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %shared_w3_scale__ssa_v0_pview
    ;
    const int64_t v141 = 0;
    // pto: %shared_w3_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 1024> v142 = pto::Shape<1, 1, 1, 1, 1024>();
    // pto: %shared_w3_scale__ssa_v0_pview
    ;
    pto::Stride<1024, 1024, 1024, 1024, 1> v143 = pto::Stride<1024, 1024, 1024, 1024, 1>();
    // pto: %shared_w3_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v144 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v140 + (v141 + v116), v142, v143);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v138, v144);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %w1_scale_inline300__tile
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %w1_scale_inline300__tile
    ;
    uint64_t v146 = (uint64_t) v16;
    TASSIGN(v145, v146);
    // pto: %w3_scale_inline301__tile
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %w3_scale_inline301__tile
    ;
    uint64_t v148 = (uint64_t) v17;
    TASSIGN(v147, v148);
    // pto: %gate_fp32_inline302__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %gate_fp32_inline302__tile
    ;
    uint64_t v150 = (uint64_t) v14;
    TASSIGN(v149, v150);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v151 = RoundMode::CAST_NONE;
    SaturationMode v152 = SaturationMode::OFF;
    TCVT(v149, v113, v151, v152);
    // pto: %up_fp32_inline303__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %up_fp32_inline303__tile
    ;
    uint64_t v154 = (uint64_t) v15;
    TASSIGN(v153, v154);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v155 = RoundMode::CAST_NONE;
    SaturationMode v156 = SaturationMode::OFF;
    TCVT(v153, v123, v155, v156);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %1
    ;
    uint64_t v158 = (uint64_t) v14;
    TASSIGN(v157, v158);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v157, v149, v100);
    // pto: %gate_fp32_v1_inline304__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %gate_fp32_v1_inline304__tile
    ;
    uint64_t v160 = (uint64_t) v14;
    TASSIGN(v159, v160);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPANDMUL(v159, v157, v145);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %2
    ;
    uint64_t v162 = (uint64_t) v15;
    TASSIGN(v161, v162);
    TROWEXPANDMUL(v161, v153, v100);
    // pto: %up_fp32_v1_inline305__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %up_fp32_v1_inline305__tile
    ;
    uint64_t v164 = (uint64_t) v15;
    TASSIGN(v163, v164);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPANDMUL(v163, v161, v147);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %3
    ;
    uint64_t v166 = (uint64_t) v14;
    TASSIGN(v165, v166);
    TMINS(v165, v159, v26);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %4
    ;
    uint64_t v168 = (uint64_t) v15;
    TASSIGN(v167, v168);
    pipe_barrier(PIPE_V);
    TMINS(v167, v163, v26);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %5
    ;
    uint64_t v170 = (uint64_t) v15;
    TASSIGN(v169, v170);
    pipe_barrier(PIPE_V);
    TMAXS(v169, v167, v27);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %6
    ;
    uint64_t v172 = (uint64_t) v16;
    TASSIGN(v171, v172);
    TNEG(v171, v165);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %7
    ;
    uint64_t v174 = (uint64_t) v16;
    TASSIGN(v173, v174);
    pipe_barrier(PIPE_V);
    TEXP(v173, v171);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %8
    ;
    uint64_t v176 = (uint64_t) v16;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TADDS(v175, v173, v28);
    // pto: %sigmoid_inline306__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %sigmoid_inline306__tile
    ;
    uint64_t v178 = (uint64_t) v17;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    TRECIP(v177, v175);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %9
    ;
    uint64_t v180 = (uint64_t) v14;
    TASSIGN(v179, v180);
    pipe_barrier(PIPE_V);
    TMUL(v179, v165, v177);
    // pto: %gated_inline307__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %gated_inline307__tile
    ;
    uint64_t v182 = (uint64_t) v14;
    TASSIGN(v181, v182);
    pipe_barrier(PIPE_V);
    TMUL(v181, v179, v169);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %10
    ;
    uint64_t v184 = (uint64_t) v15;
    TASSIGN(v183, v184);
    pipe_barrier(PIPE_V);
    TABS(v183, v181);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v25);
    // pto: %tmp_tile
    ;
    uint64_t v186 = (uint64_t) v16;
    TASSIGN(v185, v186);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v19);
    // pto: %11
    ;
    uint64_t v188 = (uint64_t) v17;
    TASSIGN(v187, v188);
    pipe_barrier(PIPE_V);
    TROWMAX(v187, v183, v185);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %chunk_amax_inline308__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v22);
    // pto: %chunk_amax_inline308__tile
    ;
    uint64_t v190 = (uint64_t) v17;
    TASSIGN(v189, v190);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
    // pto: %12
    ;
    uint64_t v192 = (uint64_t) v13;
    TASSIGN(v191, v192);
    pipe_barrier(PIPE_V);
    TMAX(v191, v109, v189);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 2, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 2, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %13
    ;
    uint64_t v194 = (uint64_t) v14;
    TASSIGN(v193, v194);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, float, 2, 1024, BLayout::RowMajor, 2, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195;
    // pto: %slice_view
    ;
    uint64_t v196 = (uint64_t) v14;
    TASSIGN(v195, v196);
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    __gm__ float* v197 = PTOAS__GLOBAL_TENSOR_DATA(v46);
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    const int64_t v198 = 0;
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    const int64_t v199 = 2048;
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 2, 1024> v200 = pto::Shape<1, 1, 1, 2, 1024>();
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 2048, 1> v201 = pto::Stride<4096, 4096, 4096, 2048, 1>();
    // pto: %h_tile_fp32_inline290__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND> v202 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 1024>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND>(v197 + (v198 + v115 * v199 + v116), v200, v201);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v202, v195);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %14
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %14
  uint64_t v204 = (uint64_t) v14;
  TASSIGN(v203, v204);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v203, v29);
  // pto: %row_scale_q_inline309__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %row_scale_q_inline309__tile
  uint64_t v206 = (uint64_t) v15;
  TASSIGN(v205, v206);
  pipe_barrier(PIPE_V);
  TDIV(v205, v203, v109);
  // pto: %row_scale_q_col_inline310__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v19);
  // pto: %row_scale_q_col_inline310__tile
  uint64_t v208 = (uint64_t) v15;
  TASSIGN(v207, v208);
  // pto: %15
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %15
  uint64_t v210 = (uint64_t) v16;
  TASSIGN(v209, v210);
  pipe_barrier(PIPE_V);
  TRECIP(v209, v205);
  // pto: %row_scale_dq_col_inline311__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v19);
  // pto: %row_scale_dq_col_inline311__tile
  uint64_t v212 = (uint64_t) v16;
  TASSIGN(v211, v212);
  // pto: %16
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v18);
  // pto: %16
  uint64_t v214 = (uint64_t) v14;
  TASSIGN(v213, v214);
  TEXPANDS(v213, v30);
  // pto: %row_scale_dq_inline312__tile
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v18);
  // pto: %row_scale_dq_inline312__tile
  uint64_t v216 = (uint64_t) v14;
  TASSIGN(v215, v216);
  pipe_barrier(PIPE_V);
  TROWEXPAND(v215, v211);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %17
  Tile<TileType::Vec, float, 2, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 2, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v18);
  // pto: %17
  uint64_t v218 = (uint64_t) v14;
  TASSIGN(v217, v218);
  // pto: %32
  Tile<TileType::Vec, float, 2, 8, BLayout::RowMajor, 2, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219;
  // pto: %32
  uint64_t v220 = (uint64_t) v14;
  TASSIGN(v219, v220);
  // pto: %33
  int64_t v221 = v99 < v23 ? v23 : v99;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  __gm__ float* v222 = PTOAS__GLOBAL_TENSOR_DATA(v90);
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  const int64_t v223 = 0;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  const int64_t v224 = 8;
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  pto::Shape<1, 1, 1, 2, 8> v225 = pto::Shape<1, 1, 1, 2, 8>();
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  pto::Stride<16, 16, 16, 8, 1> v226 = pto::Stride<16, 16, 16, 8, 1>();
  // pto: %h_tile_scale_dq_inline292__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 2, 8>, pto::Stride<16, 16, 16, 8, 1>, pto::Layout::ND> v227 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 8>, pto::Stride<16, 16, 16, 8, 1>, pto::Layout::ND>(v222 + (v223 + v221 * v224), v225, v226);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v227, v219);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  // pto: %h_fp32_inline314__tile
  Tile<TileType::Vec, float, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %h_fp32_inline314__tile
  uint64_t v229 = (uint64_t) v14;
  TASSIGN(v228, v229);
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  __gm__ float* v230 = PTOAS__GLOBAL_TENSOR_DATA(v46);
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  const int64_t v231 = 0;
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  const int64_t v232 = 2048;
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  pto::Shape<1, 1, 1, 2, 2048> v233 = pto::Shape<1, 1, 1, 2, 2048>();
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  pto::Stride<4096, 4096, 4096, 2048, 1> v234 = pto::Stride<4096, 4096, 4096, 2048, 1>();
  // pto: %h_tile_fp32_inline290__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 2, 2048>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND> v235 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 2048>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND>(v230 + (v231 + v221 * v232), v233, v234);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v228, v235);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  // pto: %h_scaled_inline315__tile
  Tile<TileType::Vec, float, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %h_scaled_inline315__tile
  uint64_t v237 = (uint64_t) v14;
  TASSIGN(v236, v237);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  TROWEXPANDMUL(v236, v228, v207);
  // pto: %h_i32_inline316__tile
  Tile<TileType::Vec, int32_t, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, int32_t, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %h_i32_inline316__tile
  uint64_t v239 = (uint64_t) v14;
  TASSIGN(v238, v239);
  pipe_barrier(PIPE_V);
  RoundMode v240 = RoundMode::CAST_RINT;
  SaturationMode v241 = SaturationMode::ON;
  TCVT(v238, v236, v240, v241);
  // pto: %h_fp16_inline317__tile
  Tile<TileType::Vec, half, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, half, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %h_fp16_inline317__tile
  uint64_t v243 = (uint64_t) v14;
  TASSIGN(v242, v243);
  pipe_barrier(PIPE_V);
  RoundMode v244 = RoundMode::CAST_ROUND;
  SaturationMode v245 = SaturationMode::OFF;
  TCVT(v242, v238, v244, v245);
  // pto: %18
  Tile<TileType::Vec, int8_t, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, int8_t, 8, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %18
  uint64_t v247 = (uint64_t) v14;
  TASSIGN(v246, v247);
  pipe_barrier(PIPE_V);
  RoundMode v248 = RoundMode::CAST_TRUNC;
  SaturationMode v249 = SaturationMode::ON;
  TCVT(v246, v242, v248, v249);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  // pto: %19
  Tile<TileType::Vec, int8_t, 2, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, int8_t, 2, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
  // pto: %19
  uint64_t v251 = (uint64_t) v14;
  TASSIGN(v250, v251);
  // pto: %35
  Tile<TileType::Vec, int8_t, 2, 2048, BLayout::RowMajor, 2, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252;
  // pto: %35
  uint64_t v253 = (uint64_t) v14;
  TASSIGN(v252, v253);
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  __gm__ int8_t* v254 = PTOAS__GLOBAL_TENSOR_DATA(v98);
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  const int64_t v255 = 0;
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  const int64_t v256 = 2048;
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  pto::Shape<1, 1, 1, 2, 2048> v257 = pto::Shape<1, 1, 1, 2, 2048>();
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  pto::Stride<4096, 4096, 4096, 2048, 1> v258 = pto::Stride<4096, 4096, 4096, 2048, 1>();
  // pto: %h_tile_i8_inline291__ssa_v1_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, 2, 2048>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND> v259 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 2, 2048>, pto::Stride<4096, 4096, 4096, 2048, 1>, pto::Layout::ND>(v254 + (v255 + v221 * v256), v257, v258);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  TSTORE(v259, v252);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}