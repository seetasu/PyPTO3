#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void exp_w2_mm(__gm__ int32_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c8192_i64
  const int64_t v9 = 8192;
  // pto: %c139264_i64
  const int64_t v10 = 139264;
  // pto: %c147456_i64
  const int64_t v11 = 147456;
  // pto: %c6144_i64
  const int64_t v12 = 6144;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c2048_i64
  const int64_t v14 = 2048;
  // pto: %c4096_i64
  const int64_t v15 = 4096;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c4096_index
  const int64_t v17 = 4096;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c2048_index
  const int64_t v19 = 2048;
  // pto: %c32_index
  const int64_t v20 = 32;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c8388608_index
  const int64_t v23 = 8388608;
  // pto: %c131072_index
  const int64_t v24 = 131072;
  // pto: %c512_index
  const int64_t v25 = 512;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c1024_index
  const int64_t v28 = 1024;
  // pto: %c128_index
  const int64_t v29 = 128;
  // pto: %cn128_index
  const int64_t v30 = -128;
  // pto: %cn512_index
  const int64_t v31 = -512;
  // pto: %y_i32_inline495__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %y_i32_inline495__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %y_i32_inline495__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %y_i32_inline495__ssa_v0_view
  int64_t v35 = v16 * v17;
  // pto: %y_i32_inline495__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %y_i32_inline495__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v16, v17);
  // pto: %y_i32_inline495__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v17, v18);
  // pto: %y_i32_inline495__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v37, v38);
  // pto: %h_tile_i8_inline444__rv_v2_view
  const int64_t v40 = 1;
  // pto: %h_tile_i8_inline444__rv_v2_view
  const int64_t v41 = 1;
  // pto: %h_tile_i8_inline444__rv_v2_view
  const int64_t v42 = 1;
  // pto: %h_tile_i8_inline444__rv_v2_view
  int64_t v43 = v16 * v19;
  // pto: %h_tile_i8_inline444__rv_v2_view
  int64_t v44 = v42 * v43;
  // pto: %h_tile_i8_inline444__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v16, v19);
  // pto: %h_tile_i8_inline444__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v19, v18);
  // pto: %h_tile_i8_inline444__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v45, v46);
  // pto: %routed_w2__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v48 = pto::Shape<-1, -1, -1, -1, -1>(v20, v21, v22, v16, v20);
  // pto: %routed_w2__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v25, v20, v18);
  // pto: %routed_w2__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v50 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v48, v49);
  // pto: %wb_idx_inline496__ssa_v0, %12
  int64_t v51 = (int64_t) ((uint64_t) ((int64_t) v6) * (uint64_t) v25);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v52 = v26; v52 < v27; v52 += v18) {
    // pto: %13
    ;
    int64_t v53 = (int64_t) ((uint64_t) v52 * (uint64_t) v22);
    // pto: %14
    ;
    int64_t v54 = (int64_t) ((uint64_t) v51 + (uint64_t) v53);
    // pto: %y_acc_inline500__tile
    ;
    Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v22);
    // pto: %y_acc_inline500__tile
    ;
    uint64_t v56 = (uint64_t) v8;
    TASSIGN(v55, v56);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v57 = v26; v57 < v19; v57 += v28) {
      // pto: %h_k_inline502__tile
      ;
      Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v25);
      // pto: %h_k_inline502__tile
      ;
      uint64_t v59 = (uint64_t) v8;
      TASSIGN(v58, v59);
      // pto: %15
      ;
      int64_t v60 = v57 < v26 ? v26 : v57;
      // pto: %h_tile_i8_inline444__rv_v2_pview
      ;
      __gm__ int8_t* v61 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %h_tile_i8_inline444__rv_v2_pview
      ;
      const int64_t v62 = 0;
      // pto: %h_tile_i8_inline444__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v63 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %h_tile_i8_inline444__rv_v2_pview
      ;
      pto::Stride<32768, 32768, 32768, 2048, 1> v64 = pto::Stride<32768, 32768, 32768, 2048, 1>();
      // pto: %h_tile_i8_inline444__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v65 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v61 + (v62 + v60), v63, v64);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v58, v65);
      // pto: %w2_k_inline503__tile
      ;
      Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
      // pto: %w2_k_inline503__tile
      ;
      uint64_t v67 = (uint64_t) v9;
      TASSIGN(v66, v67);
      // pto: %16
      ;
      int64_t v68 = v4 < v26 ? v26 : v4;
      // pto: %17
      ;
      int64_t v69 = v57 / v20;
      // pto: %18
      ;
      int64_t v70 = v69 < v26 ? v26 : v69;
      // pto: %19
      ;
      int64_t v71 = v54 / v16;
      // pto: %20
      ;
      int64_t v72 = v71 < v26 ? v26 : v71;
      // pto: %routed_w2__ssa_v0_pview
      ;
      __gm__ int8_t* v73 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %routed_w2__ssa_v0_pview
      ;
      const int64_t v74 = 0;
      // pto: %routed_w2__ssa_v0_pview
      ;
      const int64_t v75 = 8388608;
      // pto: %routed_w2__ssa_v0_pview
      ;
      const int64_t v76 = 131072;
      // pto: %routed_w2__ssa_v0_pview
      ;
      const int64_t v77 = 512;
      // pto: %routed_w2__ssa_v0_pview
      ;
      pto::Shape<1, 16, 16, 16, 32> v78 = pto::Shape<1, 16, 16, 16, 32>();
      // pto: %routed_w2__ssa_v0_pview
      ;
      pto::Stride<8388608, 131072, 512, 32, 1> v79 = pto::Stride<8388608, 131072, 512, 32, 1>();
      // pto: %routed_w2__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ> v80 = GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ>(v73 + ((v74 + v68 * v75) + v70 * v76 + v72 * v77), v78, v79);
      __gm__ int8_t* v81 = PTOAS__GLOBAL_TENSOR_DATA(v80);
      __gm__ uint8_t* v82 = reinterpret_cast<__gm__ uint8_t*>(v81);
      __gm__ int8_t* v83 = (__gm__ int8_t*) (v82 + v5);
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ> v84(nullptr);
      v84 = v80;
      TASSIGN(v84, v83);
      TLOAD(v66, v84);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v25);
      // pto: %0
      ;
      uint64_t v86 = (uint64_t) v10;
      TASSIGN(v85, v86);
      // pto: %21
      ;
      int64_t v87 = (int64_t) ((uint64_t) v57 + (uint64_t) v25);
      // pto: %22
      ;
      int64_t v88 = v87 < v26 ? v26 : v87;
      // pto: %23
      ;
      __gm__ int8_t* v89 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %23
      ;
      const int64_t v90 = 0;
      // pto: %23
      ;
      pto::Shape<1, 1, 1, 16, 512> v91 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %23
      ;
      pto::Stride<32768, 32768, 32768, 2048, 1> v92 = pto::Stride<32768, 32768, 32768, 2048, 1>();
      // pto: %23
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND> v93 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<32768, 32768, 32768, 2048, 1>, pto::Layout::ND>(v89 + (v90 + v88), v91, v92);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v85, v93);
      // pto: %1
      ;
      Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Mat, int8_t, 256, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
      // pto: %1
      ;
      uint64_t v95 = (uint64_t) v11;
      TASSIGN(v94, v95);
      // pto: %26
      ;
      int64_t v96 = (int64_t) ((uint64_t) v69 + (uint64_t) v16);
      // pto: %27
      ;
      int64_t v97 = v96 < v26 ? v26 : v96;
      // pto: %30
      ;
      __gm__ int8_t* v98 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %30
      ;
      const int64_t v99 = 0;
      // pto: %30
      ;
      const int64_t v100 = 8388608;
      // pto: %30
      ;
      const int64_t v101 = 131072;
      // pto: %30
      ;
      const int64_t v102 = 512;
      // pto: %30
      ;
      pto::Shape<1, 16, 16, 16, 32> v103 = pto::Shape<1, 16, 16, 16, 32>();
      // pto: %30
      ;
      pto::Stride<8388608, 131072, 512, 32, 1> v104 = pto::Stride<8388608, 131072, 512, 32, 1>();
      // pto: %30
      ;
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ> v105 = GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ>(v98 + ((v99 + v68 * v100) + v97 * v101 + v72 * v102), v103, v104);
      __gm__ int8_t* v106 = PTOAS__GLOBAL_TENSOR_DATA(v105);
      __gm__ uint8_t* v107 = reinterpret_cast<__gm__ uint8_t*>(v106);
      __gm__ int8_t* v108 = (__gm__ int8_t*) (v107 + v5);
      GlobalTensor<int8_t, pto::Shape<1, 16, 16, 16, 32>, pto::Stride<8388608, 131072, 512, 32, 1>, pto::Layout::NZ> v109(nullptr);
      v109 = v105;
      TASSIGN(v109, v108);
      TLOAD(v94, v109);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %w2_k_inline503__tile_t
      ;
      Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v22);
      // pto: %w2_k_inline503__tile_t
      ;
      uint64_t v111 = (uint64_t) v9;
      TASSIGN(v110, v111);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v112 = v26; v112 < v25; v112 += v22) {
        // pto: %y_acc_inline500__iter_v1_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v29);
        // pto: %y_acc_inline500__iter_v1_l0_a
        ;
        uint64_t v114 = (uint64_t) v12;
        TASSIGN(v113, v114);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_MTE1);
        uint16_t v115 = static_cast<uint16_t>(v26);
        uint16_t v116 = static_cast<uint16_t>(v112);
        TEXTRACT(v113, v58, v115, v116);
        // pto: %y_acc_inline500__iter_v1_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v22);
        // pto: %y_acc_inline500__iter_v1_l0_b
        ;
        uint64_t v118 = (uint64_t) v13;
        TASSIGN(v117, v118);
        uint16_t v119 = static_cast<uint16_t>(v112);
        uint16_t v120 = static_cast<uint16_t>(v26);
        TEXTRACT(v117, v110, v119, v120);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %2
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v29);
        // pto: %2
        ;
        uint64_t v122 = (uint64_t) v8;
        TASSIGN(v121, v122);
        // pto: %31
        ;
        int64_t v123 = (int64_t) ((uint64_t) v112 + (uint64_t) v29);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v124 = static_cast<uint16_t>(v26);
        uint16_t v125 = static_cast<uint16_t>(v123);
        TEXTRACT(v121, v58, v124, v125);
        // pto: %3
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v22);
        // pto: %3
        ;
        uint64_t v127 = (uint64_t) v8;
        TASSIGN(v126, v127);
        uint16_t v128 = static_cast<uint16_t>(v123);
        uint16_t v129 = static_cast<uint16_t>(v26);
        TEXTRACT(v126, v110, v128, v129);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %33
        ;
        bool v130 = v57 == v26;
        // pto: %34, %35
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v130 & v112 == v26) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v113, v117);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v113, v117);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %37, %38
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v130 & v112 == v30) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v121, v126);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v121, v126);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %5
      ;
      Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 512, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v22);
      // pto: %5
      ;
      uint64_t v132 = (uint64_t) v11;
      TASSIGN(v131, v132);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      for (int64_t v133 = v26; v133 < v25; v133 += v22) {
        // pto: %6
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v29);
        // pto: %6
        ;
        uint64_t v135 = (uint64_t) v14;
        TASSIGN(v134, v135);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v136 = static_cast<uint16_t>(v26);
        uint16_t v137 = static_cast<uint16_t>(v133);
        TEXTRACT(v134, v85, v136, v137);
        // pto: %7
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v22);
        // pto: %7
        ;
        uint64_t v139 = (uint64_t) v13;
        TASSIGN(v138, v139);
        pipe_barrier(PIPE_MTE1);
        uint16_t v140 = static_cast<uint16_t>(v133);
        uint16_t v141 = static_cast<uint16_t>(v26);
        TEXTRACT(v138, v131, v140, v141);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %8
        ;
        Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Left, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v29);
        // pto: %8
        ;
        uint64_t v143 = (uint64_t) v15;
        TASSIGN(v142, v143);
        // pto: %40
        ;
        int64_t v144 = (int64_t) ((uint64_t) v133 + (uint64_t) v29);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v145 = static_cast<uint16_t>(v26);
        uint16_t v146 = static_cast<uint16_t>(v144);
        TEXTRACT(v142, v85, v145, v146);
        // pto: %9
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v22);
        // pto: %9
        ;
        uint64_t v148 = (uint64_t) v8;
        TASSIGN(v147, v148);
        uint16_t v149 = static_cast<uint16_t>(v144);
        uint16_t v150 = static_cast<uint16_t>(v26);
        TEXTRACT(v147, v131, v149, v150);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %42
        ;
        bool v151 = v57 == v31;
        // pto: %43, %44
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v151 & v133 == v26) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v134, v138);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v134, v138);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %46, %47
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        if (v151 & v133 == v30) {
          pipe_barrier(PIPE_M);
          TMATMUL(v55, v142, v147);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v55, v55, v142, v147);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %t__tile
    ;
    Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Acc, int32_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v22);
    // pto: %t__tile
    ;
    uint64_t v153 = (uint64_t) v8;
    TASSIGN(v152, v153);
    // pto: %48
    ;
    int64_t v154 = v54 < v26 ? v26 : v54;
    // pto: %y_i32_inline495__iter_v1_pview
    ;
    __gm__ int32_t* v155 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %y_i32_inline495__iter_v1_pview
    ;
    const int64_t v156 = 0;
    // pto: %y_i32_inline495__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 256> v157 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %y_i32_inline495__iter_v1_pview
    ;
    pto::Stride<65536, 65536, 65536, 4096, 1> v158 = pto::Stride<65536, 65536, 65536, 4096, 1>();
    // pto: %y_i32_inline495__iter_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v159 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v155 + (v156 + v154), v157, v158);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v159, v152);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}