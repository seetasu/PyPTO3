#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ int32_t* v7, __gm__ bfloat16_t* v8, __gm__ int32_t* v9, __gm__ bfloat16_t* v10, __gm__ bfloat16_t* v11, __gm__ float* v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v24 = 48;
  const int64_t v25 = 1024;
  const int64_t v26 = 32;
  const int32_t v27 = 0;
  // pto: %c32768_i64
  const int64_t v28 = 32768;
  // pto: %c163840_i64
  const int64_t v29 = 163840;
  // pto: %c0_i64
  const int64_t v30 = 0;
  // pto: %c8192_i64
  const int64_t v31 = 8192;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c512_index
  const int64_t v33 = 512;
  // pto: %c8_index
  const int64_t v34 = 8;
  // pto: %c4_index
  const int64_t v35 = 4;
  // pto: %c128_index
  const int64_t v36 = 128;
  // pto: %c0_index
  const int64_t v37 = 0;
  // pto: %c2_index
  const int64_t v38 = 2;
  // pto: %c16_index
  const int64_t v39 = 16;
  // pto: %c64_index
  const int64_t v40 = 64;
  const int64_t v41 = 32;
  // pto: %c256_index
  const int64_t v42 = 256;
  // pto: %cn128_index
  const int64_t v43 = -128;
  // pto: %cn32_index
  const int64_t v44 = -32;
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v48 = (int64_t) v17;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v49 = v48 * v33;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %sparse_blk_oi__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v33);
  // pto: %sparse_blk_oi__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v33, v32);
  // pto: %sparse_blk_oi__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v51, v52);
  // pto: %156
  int64_t v54 = (int64_t) ((uint64_t) v19 * (uint64_t) v36);
  // pto: %ori_kv_flat__ssa_v1_view
  const int64_t v55 = 1;
  // pto: %ori_kv_flat__ssa_v1_view
  const int64_t v56 = 1;
  // pto: %ori_kv_flat__ssa_v1_view
  const int64_t v57 = 1;
  // pto: %ori_kv_flat__ssa_v1_view
  int64_t v58 = v54 * v33;
  // pto: %ori_kv_flat__ssa_v1_view
  int64_t v59 = v57 * v58;
  // pto: %ori_kv_flat__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v54, v33);
  // pto: %ori_kv_flat__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v33, v32);
  // pto: %ori_kv_flat__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v60, v61);
  // pto: %cmp_kv_flat__ssa_v1_view
  const int64_t v63 = 1;
  // pto: %cmp_kv_flat__ssa_v1_view
  const int64_t v64 = 1;
  // pto: %cmp_kv_flat__ssa_v1_view
  const int64_t v65 = 1;
  // pto: %cmp_kv_flat__ssa_v1_view
  int64_t v66 = (int64_t) v21;
  // pto: %cmp_kv_flat__ssa_v1_view
  int64_t v67 = v66 * v33;
  // pto: %cmp_kv_flat__ssa_v1_view
  int64_t v68 = v65 * v67;
  // pto: %cmp_kv_flat__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v33);
  // pto: %cmp_kv_flat__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v33, v32);
  // pto: %cmp_kv_flat__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v69, v70);
  // pto: %q_flat__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %q_flat__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %q_flat__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %q_flat__ssa_v0_view
  int64_t v75 = v33 * v33;
  // pto: %q_flat__ssa_v0_view
  int64_t v76 = v74 * v75;
  // pto: %q_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v77 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v33, v33);
  // pto: %q_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v76, v76, v75, v33, v32);
  // pto: %q_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v77, v78);
  // pto: %qk_kv__phi_v12
  Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
  // pto: %qk_kv__phi_v12
  uint64_t v81 = (uint64_t) v28;
  TASSIGN(v80, v81);
  // pto: %qk_kv__phi_v2
  Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
  // pto: %qk_kv__phi_v2
  uint64_t v83 = (uint64_t) v28;
  TASSIGN(v82, v83);
  // pto: %qk_kv__phi_v4
  Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
  // pto: %qk_kv__phi_v4
  uint64_t v85 = (uint64_t) v28;
  TASSIGN(v84, v85);
  // pto: %qk_kv__phi_v6
  Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
  // pto: %qk_kv__phi_v6
  uint64_t v87 = (uint64_t) v28;
  TASSIGN(v86, v87);
  // pto: %qk_kv__phi_v11
  Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
  // pto: %qk_kv__phi_v11
  uint64_t v89 = (uint64_t) v28;
  TASSIGN(v88, v89);
  auto v90 = TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>(v12, v27, v27);
  // pto: %qk_core__ssa_v0
  int64_t v91 = (int64_t) v22;
  // pto: %30
  int64_t v92 = (int64_t) ((uint64_t) v13 - (uint64_t) v91);
  // pto: %31
  int64_t v93 = (int64_t) ((uint64_t) v92 + (uint64_t) v14);
  // pto: %32, %33
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v94 = v37; v94 < ((int64_t) ((uint64_t) v93 - (uint64_t) v32) / v14); v94 += v32) {
    // pto: %34
    ;
    int64_t v95 = (int64_t) ((uint64_t) v94 * (uint64_t) v14);
    // pto: %35
    ;
    int64_t v96 = (int64_t) ((uint64_t) v91 + (uint64_t) v95);
    // pto: %36
    ;
    int64_t v97 = v96 / v34;
    // pto: %37
    ;
    int64_t v98 = (int64_t) ((uint64_t) v97 * (uint64_t) v34);
    // pto: %38
    ;
    int64_t v99 = (int64_t) ((uint64_t) v96 - (uint64_t) v98);
    // pto: %39
    ;
    int64_t v100 = v99 / v38;
    // pto: %40
    ;
    int64_t v101 = (int64_t) ((uint64_t) v99 * (uint64_t) v35);
    // pto: %41
    ;
    int64_t v102 = (int64_t) ((uint64_t) v101 * (uint64_t) v15);
    // pto: %42
    ;
    int64_t v103 = (int64_t) ((uint64_t) v102 * (uint64_t) v39);
    // pto: %qk_pos__tile
    ;
    int32_t v104 = (v4)[v99];
    // pto: %qk_len__tile
    ;
    int32_t v105 = (v5)[v100];
    // pto: %43
    ;
    int64_t v106 = (int64_t) v104;
    // pto: %44
    ;
    int64_t v107 = (int64_t) ((uint64_t) v106 + (uint64_t) v32);
    // pto: %45
    ;
    int64_t v108 = (int64_t) v105;
    // pto: %46
    ;
    int64_t v109 = v107 < v108 ? v107 : v108;
    // pto: %47
    ;
    int64_t v110 = v109 / v36;
    // pto: %48
    ;
    int64_t v111 = v110 < v16 ? v110 : v16;
    // pto: %49
    ;
    int64_t v112 = (int64_t) ((uint64_t) v97 * (uint64_t) v36);
    // pto: %50, %51
    ;
    if (v112 < (int64_t) ((uint64_t) v111 + (uint64_t) v36)) {
      // pto: %qk_kv__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v33);
      // pto: %qk_kv__tile
      ;
      uint64_t v114 = (uint64_t) v28;
      TASSIGN(v113, v114);
      // pto: %52
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      if (v97 == v37) {
        // pto: %55
        ;
        int64_t v115 = v107 < v36 ? v107 : v36;
        // pto: %57
        ;
        int64_t v116 = (int64_t) ((uint64_t) v106 - (uint64_t) v115);
        // pto: %60, %58, %59
        ;
        int64_t v117 = (int64_t) ((uint64_t) v36 - (uint64_t) ((int64_t) ((uint64_t) v116 + (uint64_t) v32) % v36));
        // pto: %61
        ;
        int64_t v118 = v117 < v115 ? v117 : v115;
        // pto: %62
        ;
        if (v118 > v37) {
          // pto: %flat_offset_mul, %qk_run_raw__tile
          ;
          int32_t v119 = (v7)[(int64_t) ((uint64_t) v99 * (uint64_t) v36)];
          // pto: %63
          ;
          int64_t v120 = (int64_t) v119;
          // pto: %64
          ;
          int64_t v121 = v120 < v37 ? v37 : v120;
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118);
          // pto: %gather_row_view
          ;
          uint64_t v123 = (uint64_t) v28;
          TASSIGN(v122, v123);
          // pto: %67
          ;
          int64_t v124 = v121 < v37 ? v37 : v121;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          const int64_t v125 = 0;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          __gm__ bfloat16_t* v126 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          const int64_t v127 = 1;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          const int64_t v128 = 1;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          const int64_t v129 = 1;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          int64_t v130 = v118 * v33;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          int64_t v131 = v129 * v130;
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          pto::Shape<1, 1, 1, -1, 512> v132 = pto::Shape<1, 1, 1, -1, 512>(v127, v128, v129, v118, v33);
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v133 = pto::Stride<-1, -1, -1, -1, -1>(v128 * v131, v131, v130, v33, v32);
          // pto: %ori_kv_flat__ssa_v1_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v134 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v126 + (v125 + v124 * v33 + v37 * v32), v132, v133);
          TLOAD(v122, v134);
        };
        // pto: %69
        ;
        if (v117 < v115) {
          // pto: %71
          ;
          int64_t v135 = (int64_t) ((uint64_t) v99 * (uint64_t) v36);
          // pto: %72, %70
          ;
          int32_t v136 = (v7)[(int64_t) ((uint64_t) v135 + (uint64_t) v117)];
          // pto: %73
          ;
          int64_t v137 = (int64_t) v136;
          // pto: %74
          ;
          int64_t v138 = v137 < v37 ? v37 : v137;
          // pto: %76
          ;
          int64_t v139 = (int64_t) ((uint64_t) v115 - (uint64_t) v117);
          // pto: %77
          ;
          int64_t v140 = (int64_t) ((uint64_t) v117 * (uint64_t) v26);
          // pto: %77
          ;
          int64_t v141 = (int64_t) ((uint64_t) v140 + (uint64_t) v28);
          // pto: %77
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v139);
          // pto: %77
          ;
          uint64_t v143 = (uint64_t) v141;
          TASSIGN(v142, v143);
          // pto: %78
          ;
          int64_t v144 = v138 < v37 ? v37 : v138;
          // pto: %79
          ;
          const int64_t v145 = 0;
          // pto: %79
          ;
          __gm__ bfloat16_t* v146 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %79
          ;
          const int64_t v147 = 1;
          // pto: %79
          ;
          const int64_t v148 = 1;
          // pto: %79
          ;
          const int64_t v149 = 1;
          // pto: %79
          ;
          int64_t v150 = v139 * v33;
          // pto: %79
          ;
          int64_t v151 = v149 * v150;
          // pto: %79
          ;
          pto::Shape<1, 1, 1, -1, 512> v152 = pto::Shape<1, 1, 1, -1, 512>(v147, v148, v149, v139, v33);
          // pto: %79
          ;
          pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v148 * v151, v151, v150, v33, v32);
          // pto: %79
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v154 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v146 + (v145 + v144 * v33 + v37 * v32), v152, v153);
          TLOAD(v142, v154);
        };
        // pto: %80
        ;
        int64_t v155 = (int64_t) ((uint64_t) v36 - (uint64_t) v115);
        // pto: %81
        ;
        if (v155 > v37) {
          // pto: %82
          ;
          int64_t v156 = (int64_t) ((uint64_t) v115 * (uint64_t) v26);
          // pto: %82
          ;
          int64_t v157 = (int64_t) ((uint64_t) v156 + (uint64_t) v28);
          // pto: %82
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v155);
          // pto: %82
          ;
          uint64_t v159 = (uint64_t) v157;
          TASSIGN(v158, v159);
          // pto: %83
          ;
          const int64_t v160 = 0;
          // pto: %83
          ;
          __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %83
          ;
          const int64_t v162 = 1;
          // pto: %83
          ;
          const int64_t v163 = 1;
          // pto: %83
          ;
          const int64_t v164 = 1;
          // pto: %83
          ;
          int64_t v165 = v155 * v33;
          // pto: %83
          ;
          int64_t v166 = v164 * v165;
          // pto: %83
          ;
          pto::Shape<1, 1, 1, -1, 512> v167 = pto::Shape<1, 1, 1, -1, 512>(v162, v163, v164, v155, v33);
          // pto: %83
          ;
          pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v163 * v166, v166, v165, v33, v32);
          // pto: %83
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v161 + (v160 + v37 * v33 + v37 * v32), v167, v168);
          TLOAD(v158, v169);
        };
      } else {
        // pto: %84
        ;
        int64_t v170 = (int64_t) ((uint64_t) v112 - (uint64_t) v36);
        // pto: %85
        ;
        int64_t v171 = (int64_t) ((uint64_t) v111 - (uint64_t) v170);
        // pto: %86
        ;
        int64_t v172 = v171 < v36 ? v171 : v36;
        for (int64_t v173 = v37; v173 < v172; v173 += v32) {
          // pto: %88
          ;
          int64_t v174 = (int64_t) ((uint64_t) v170 + (uint64_t) v173);
          // pto: %89
          ;
          int64_t v175 = (int64_t) ((uint64_t) v100 * (uint64_t) v20);
          // pto: %90, %87
          ;
          int32_t v176 = (v9)[(int64_t) ((uint64_t) v175 + (uint64_t) v174)];
          // pto: %91
          ;
          int64_t v177 = (int64_t) v176;
          // pto: %92
          ;
          int64_t v178 = (int64_t) ((uint64_t) v173 * (uint64_t) v26);
          // pto: %92
          ;
          int64_t v179 = (int64_t) ((uint64_t) v178 + (uint64_t) v28);
          // pto: %92
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, 1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v180;
          // pto: %92
          ;
          uint64_t v181 = (uint64_t) v179;
          TASSIGN(v180, v181);
          // pto: %93
          ;
          int64_t v182 = v177 < v37 ? v37 : v177;
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          __gm__ bfloat16_t* v183 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          const int64_t v184 = 0;
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          const int64_t v185 = 512;
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v186 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v187 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %cmp_kv_flat__ssa_v1_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v188 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v183 + (v184 + v182 * v185), v186, v187);
          TLOAD(v180, v188);
        };
        // pto: %94
        ;
        int64_t v189 = (int64_t) ((uint64_t) v36 - (uint64_t) v172);
        // pto: %95
        ;
        if (v189 > v37) {
          // pto: %96
          ;
          int64_t v190 = (int64_t) ((uint64_t) v172 * (uint64_t) v26);
          // pto: %96
          ;
          int64_t v191 = (int64_t) ((uint64_t) v190 + (uint64_t) v28);
          // pto: %96
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v189);
          // pto: %96
          ;
          uint64_t v193 = (uint64_t) v191;
          TASSIGN(v192, v193);
          // pto: %97
          ;
          const int64_t v194 = 0;
          // pto: %97
          ;
          __gm__ bfloat16_t* v195 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %97
          ;
          const int64_t v196 = 1;
          // pto: %97
          ;
          const int64_t v197 = 1;
          // pto: %97
          ;
          const int64_t v198 = 1;
          // pto: %97
          ;
          int64_t v199 = v189 * v33;
          // pto: %97
          ;
          int64_t v200 = v198 * v199;
          // pto: %97
          ;
          pto::Shape<1, 1, 1, -1, 512> v201 = pto::Shape<1, 1, 1, -1, 512>(v196, v197, v198, v189, v33);
          // pto: %97
          ;
          pto::Stride<-1, -1, -1, -1, -1> v202 = pto::Stride<-1, -1, -1, -1, -1>(v197 * v200, v200, v199, v33, v32);
          // pto: %97
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v203 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v195 + (v194 + v37 * v33 + v37 * v32), v201, v202);
          TLOAD(v192, v203);
        };
      };
      // pto: %98
      ;
      int64_t v204 = (int64_t) ((uint64_t) v99 * (uint64_t) v40);
      // pto: %qk_q_tile__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
      // pto: %qk_q_tile__tile
      ;
      uint64_t v206 = (uint64_t) v29;
      TASSIGN(v205, v206);
      // pto: %100
      ;
      int64_t v207 = v204 < v37 ? v37 : v204;
      // pto: %q_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v208 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %q_flat__ssa_v0_pview
      ;
      const int64_t v209 = 0;
      // pto: %q_flat__ssa_v0_pview
      ;
      const int64_t v210 = 512;
      // pto: %q_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 512> v211 = pto::Shape<1, 1, 1, 32, 512>();
      // pto: %q_flat__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v212 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %q_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v213 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v208 + (v209 + v207 * v210), v211, v212);
      TLOAD(v205, v213);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %qk_kv__phi_v12_t
      ;
      Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %qk_kv__phi_v12_t
      ;
      uint64_t v215 = (uint64_t) v28;
      TASSIGN(v214, v215);
      // pto: %qk_raw__tile_l0_init
      ;
      Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v41, v36);
      // pto: %qk_raw__tile_l0_init
      ;
      uint64_t v217 = (uint64_t) v30;
      TASSIGN(v216, v217);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v218 = v37; v218 < v33; v218 += v42) {
        // pto: %qk_raw__tile_l0_a
        ;
        Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v36);
        // pto: %qk_raw__tile_l0_a
        ;
        uint64_t v220 = (uint64_t) v30;
        TASSIGN(v219, v220);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_MTE1);
        uint16_t v221 = static_cast<uint16_t>(v37);
        uint16_t v222 = static_cast<uint16_t>(v218);
        TEXTRACT(v219, v205, v221, v222);
        // pto: %qk_raw__tile_l0_b
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %qk_raw__tile_l0_b
        ;
        uint64_t v224 = (uint64_t) v30;
        TASSIGN(v223, v224);
        uint16_t v225 = static_cast<uint16_t>(v218);
        uint16_t v226 = static_cast<uint16_t>(v37);
        TEXTRACT(v223, v214, v225, v226);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %5
        ;
        Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v36);
        // pto: %5
        ;
        uint64_t v228 = (uint64_t) v31;
        TASSIGN(v227, v228);
        // pto: %101
        ;
        int64_t v229 = (int64_t) ((uint64_t) v218 + (uint64_t) v36);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v230 = static_cast<uint16_t>(v37);
        uint16_t v231 = static_cast<uint16_t>(v229);
        TEXTRACT(v227, v205, v230, v231);
        // pto: %6
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %6
        ;
        uint64_t v233 = (uint64_t) v28;
        TASSIGN(v232, v233);
        uint16_t v234 = static_cast<uint16_t>(v229);
        uint16_t v235 = static_cast<uint16_t>(v37);
        TEXTRACT(v232, v214, v234, v235);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %103
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v218 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v216, v219, v223);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v216, v216, v219, v223);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %104
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v218 == v43) {
          pipe_barrier(PIPE_M);
          TMATMUL(v216, v227, v232);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v216, v216, v227, v232);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v90, v216);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      // pto: %106
      ;
      int64_t v236 = (int64_t) ((uint64_t) v204 + (uint64_t) v41);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
      // pto: %8
      ;
      uint64_t v238 = (uint64_t) v29;
      TASSIGN(v237, v238);
      // pto: %107
      ;
      int64_t v239 = v236 < v37 ? v37 : v236;
      // pto: %108
      ;
      __gm__ bfloat16_t* v240 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %108
      ;
      const int64_t v241 = 0;
      // pto: %108
      ;
      const int64_t v242 = 512;
      // pto: %108
      ;
      pto::Shape<1, 1, 1, 32, 512> v243 = pto::Shape<1, 1, 1, 32, 512>();
      // pto: %108
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v244 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %108
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v245 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v240 + (v241 + v239 * v242), v243, v244);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v237, v245);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %9
      ;
      Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %9
      ;
      uint64_t v247 = (uint64_t) v28;
      TASSIGN(v246, v247);
      // pto: %10
      ;
      Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v41, v36);
      // pto: %10
      ;
      uint64_t v249 = (uint64_t) v30;
      TASSIGN(v248, v249);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      for (int64_t v250 = v37; v250 < v33; v250 += v42) {
        // pto: %11
        ;
        Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v36);
        // pto: %11
        ;
        uint64_t v252 = (uint64_t) v30;
        TASSIGN(v251, v252);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v253 = static_cast<uint16_t>(v37);
        uint16_t v254 = static_cast<uint16_t>(v250);
        TEXTRACT(v251, v237, v253, v254);
        // pto: %12
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %12
        ;
        uint64_t v256 = (uint64_t) v30;
        TASSIGN(v255, v256);
        uint16_t v257 = static_cast<uint16_t>(v250);
        uint16_t v258 = static_cast<uint16_t>(v37);
        TEXTRACT(v255, v246, v257, v258);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %13
        ;
        Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v36);
        // pto: %13
        ;
        uint64_t v260 = (uint64_t) v31;
        TASSIGN(v259, v260);
        // pto: %110
        ;
        int64_t v261 = (int64_t) ((uint64_t) v250 + (uint64_t) v36);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v262 = static_cast<uint16_t>(v37);
        uint16_t v263 = static_cast<uint16_t>(v261);
        TEXTRACT(v259, v237, v262, v263);
        // pto: %14
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %14
        ;
        uint64_t v265 = (uint64_t) v28;
        TASSIGN(v264, v265);
        pipe_barrier(PIPE_MTE1);
        uint16_t v266 = static_cast<uint16_t>(v261);
        uint16_t v267 = static_cast<uint16_t>(v37);
        TEXTRACT(v264, v246, v266, v267);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %112
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v250 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v248, v251, v255);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v248, v248, v251, v255);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %113
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        if (v250 == v43) {
          pipe_barrier(PIPE_M);
          TMATMUL(v248, v259, v264);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v248, v248, v259, v264);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v90, v248);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      // pto: %qk_oi__tile_l0_init
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v41, v33);
      // pto: %qk_oi__tile_l0_init
      ;
      uint64_t v269 = (uint64_t) v30;
      TASSIGN(v268, v269);
      // pto: %qk_oi__tile_l0_lmat
      ;
      const int32_t v270 = 32;
      // pto: %qk_oi__tile_l0_lmat
      ;
      const int32_t v271 = 128;
      // pto: %qk_oi__tile_l0_lmat
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v270, v271);
      pipe_barrier(PIPE_MTE2);
      TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v90, v272);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      for (int64_t v273 = v37; v273 < v36; v273 += v40) {
        // pto: %qk_oi__tile_l0_a
        ;
        Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v41);
        // pto: %qk_oi__tile_l0_a
        ;
        uint64_t v275 = (uint64_t) v30;
        TASSIGN(v274, v275);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v276 = static_cast<uint16_t>(v37);
        uint16_t v277 = static_cast<uint16_t>(v273);
        TEXTRACT(v274, v272, v276, v277);
        // pto: %qk_oi__tile_l0_b
        ;
        Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
        // pto: %qk_oi__tile_l0_b
        ;
        uint64_t v279 = (uint64_t) v30;
        TASSIGN(v278, v279);
        uint16_t v280 = static_cast<uint16_t>(v273);
        uint16_t v281 = static_cast<uint16_t>(v37);
        TEXTRACT(v278, v80, v280, v281);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %17
        ;
        Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v41);
        // pto: %17
        ;
        uint64_t v283 = (uint64_t) v31;
        TASSIGN(v282, v283);
        // pto: %114
        ;
        int64_t v284 = (int64_t) ((uint64_t) v273 + (uint64_t) v41);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v285 = static_cast<uint16_t>(v37);
        uint16_t v286 = static_cast<uint16_t>(v284);
        TEXTRACT(v282, v272, v285, v286);
        // pto: %18
        ;
        Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
        // pto: %18
        ;
        uint64_t v288 = (uint64_t) v28;
        TASSIGN(v287, v288);
        pipe_barrier(PIPE_MTE1);
        uint16_t v289 = static_cast<uint16_t>(v284);
        uint16_t v290 = static_cast<uint16_t>(v37);
        TEXTRACT(v287, v80, v289, v290);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %116
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        if (v273 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v268, v274, v278);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v268, v268, v274, v278);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        // pto: %117
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v273 == v44) {
          pipe_barrier(PIPE_M);
          TMATMUL(v268, v282, v287);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v268, v268, v282, v287);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v90);
      // pto: %121
      ;
      int64_t v291 = (int64_t) ((uint64_t) v97 * (uint64_t) v39);
      // pto: %122
      ;
      int64_t v292 = (int64_t) ((uint64_t) v103 + (uint64_t) v291);
      // pto: %t__tile
      ;
      Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v33);
      // pto: %t__tile
      ;
      uint64_t v294 = (uint64_t) v30;
      TASSIGN(v293, v294);
      // pto: %slice_view
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v295;
      // pto: %slice_view
      ;
      uint64_t v296 = (uint64_t) v30;
      TASSIGN(v295, v296);
      // pto: %123
      ;
      int64_t v297 = v292 < v37 ? v37 : v292;
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      __gm__ float* v298 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      const int64_t v299 = 0;
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      const int64_t v300 = 512;
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v301 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v302 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %sparse_blk_oi__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v303 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v298 + (v299 + v297 * v300), v301, v302);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v303, v295);
      // pto: %125
      ;
      int64_t v304 = (int64_t) ((uint64_t) v15 * (uint64_t) v39);
      // pto: %126
      ;
      int64_t v305 = (int64_t) ((uint64_t) v103 + (uint64_t) v304);
      // pto: %128
      ;
      int64_t v306 = (int64_t) ((uint64_t) v305 + (uint64_t) v291);
      // pto: %20
      ;
      Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v33);
      // pto: %20
      ;
      uint64_t v308 = (uint64_t) v28;
      TASSIGN(v307, v308);
      // pto: %129
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v309;
      // pto: %129
      ;
      uint64_t v310 = (uint64_t) v25;
      TASSIGN(v309, v310);
      // pto: %131
      ;
      int64_t v311 = v306 < v37 ? v37 : v306;
      // pto: %sparse_blk_oi__tile_pview
      ;
      __gm__ float* v312 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %sparse_blk_oi__tile_pview
      ;
      const int64_t v313 = 0;
      // pto: %sparse_blk_oi__tile_pview
      ;
      const int64_t v314 = 512;
      // pto: %sparse_blk_oi__tile_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v315 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %sparse_blk_oi__tile_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v316 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %sparse_blk_oi__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v317 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v312 + (v313 + v311 * v314), v315, v316);
      pipe_barrier(PIPE_FIX);
      TSTORE(v317, v309);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      // pto: %21
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v41, v33);
      // pto: %21
      ;
      uint64_t v319 = (uint64_t) v30;
      TASSIGN(v318, v319);
      // pto: %132
      ;
      const int32_t v320 = 32;
      // pto: %132
      ;
      const int32_t v321 = 128;
      // pto: %132
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v320, v321);
      TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v90, v322);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v323 = v37; v323 < v36; v323 += v40) {
        // pto: %22
        ;
        Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v41);
        // pto: %22
        ;
        uint64_t v325 = (uint64_t) v30;
        TASSIGN(v324, v325);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v326 = static_cast<uint16_t>(v37);
        uint16_t v327 = static_cast<uint16_t>(v323);
        TEXTRACT(v324, v322, v326, v327);
        // pto: %23
        ;
        Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
        // pto: %23
        ;
        uint64_t v329 = (uint64_t) v30;
        TASSIGN(v328, v329);
        uint16_t v330 = static_cast<uint16_t>(v323);
        uint16_t v331 = static_cast<uint16_t>(v37);
        TEXTRACT(v328, v80, v330, v331);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %24
        ;
        Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v41, v41);
        // pto: %24
        ;
        uint64_t v333 = (uint64_t) v31;
        TASSIGN(v332, v333);
        // pto: %134
        ;
        int64_t v334 = (int64_t) ((uint64_t) v323 + (uint64_t) v41);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v335 = static_cast<uint16_t>(v37);
        uint16_t v336 = static_cast<uint16_t>(v334);
        TEXTRACT(v332, v322, v335, v336);
        // pto: %25
        ;
        Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v41, v33);
        // pto: %25
        ;
        uint64_t v338 = (uint64_t) v28;
        TASSIGN(v337, v338);
        pipe_barrier(PIPE_MTE1);
        uint16_t v339 = static_cast<uint16_t>(v334);
        uint16_t v340 = static_cast<uint16_t>(v37);
        TEXTRACT(v337, v80, v339, v340);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %136
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        if (v323 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v318, v324, v328);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v318, v318, v324, v328);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %137
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        if (v323 == v44) {
          pipe_barrier(PIPE_M);
          TMATMUL(v318, v332, v337);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v318, v318, v332, v337);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v90);
      int64_t v341 = (int64_t) ((uint64_t) v15 * (uint64_t) v41);
      // pto: %140
      ;
      int64_t v342 = (int64_t) ((uint64_t) v103 + (uint64_t) v341);
      // pto: %142
      ;
      int64_t v343 = (int64_t) ((uint64_t) v342 + (uint64_t) v291);
      // pto: %28
      ;
      Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v33);
      // pto: %28
      ;
      uint64_t v345 = (uint64_t) v30;
      TASSIGN(v344, v345);
      // pto: %143
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v346;
      // pto: %143
      ;
      uint64_t v347 = (uint64_t) v30;
      TASSIGN(v346, v347);
      // pto: %145
      ;
      int64_t v348 = v343 < v37 ? v37 : v343;
      // pto: %146
      ;
      __gm__ float* v349 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %146
      ;
      const int64_t v350 = 0;
      // pto: %146
      ;
      const int64_t v351 = 512;
      // pto: %146
      ;
      pto::Shape<1, 1, 1, 16, 512> v352 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %146
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v353 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %146
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v354 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v349 + (v350 + v348 * v351), v352, v353);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      pipe_barrier(PIPE_FIX);
      TSTORE(v354, v346);
      int64_t v355 = (int64_t) ((uint64_t) v15 * (uint64_t) v24);
      // pto: %149
      ;
      int64_t v356 = (int64_t) ((uint64_t) v103 + (uint64_t) v355);
      // pto: %151
      ;
      int64_t v357 = (int64_t) ((uint64_t) v356 + (uint64_t) v291);
      // pto: %29
      ;
      Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v33);
      // pto: %29
      ;
      uint64_t v359 = (uint64_t) v28;
      TASSIGN(v358, v359);
      // pto: %152
      ;
      Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v360;
      // pto: %152
      ;
      uint64_t v361 = (uint64_t) v25;
      TASSIGN(v360, v361);
      // pto: %154
      ;
      int64_t v362 = v357 < v37 ? v37 : v357;
      // pto: %155
      ;
      __gm__ float* v363 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %155
      ;
      const int64_t v364 = 0;
      // pto: %155
      ;
      const int64_t v365 = 512;
      // pto: %155
      ;
      pto::Shape<1, 1, 1, 16, 512> v366 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %155
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v367 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %155
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v368 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v363 + (v364 + v362 * v365), v366, v367);
      pipe_barrier(PIPE_FIX);
      TSTORE(v368, v360);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ int32_t* v7, __gm__ bfloat16_t* v8, __gm__ int32_t* v9, __gm__ bfloat16_t* v10, __gm__ bfloat16_t* v11, __gm__ float* v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23, int32_t v24) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v25 = 0;
  // pto: %c32768_i64
  const int64_t v26 = 32768;
  // pto: %c49920_i64
  const int64_t v27 = 49920;
  // pto: %c33280_i64
  const int64_t v28 = 33280;
  // pto: %c49664_i64
  const int64_t v29 = 49664;
  // pto: %c49792_i64
  const int64_t v30 = 49792;
  const int64_t v31 = 49728;
  const int64_t v32 = 49856;
  // pto: %c1_index
  const int64_t v33 = 1;
  // pto: %c512_index
  const int64_t v34 = 512;
  // pto: %c8_index
  const int64_t v35 = 8;
  // pto: %c4_index
  const int64_t v36 = 4;
  // pto: %c128_index
  const int64_t v37 = 128;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c2_index
  const int64_t v39 = 2;
  // pto: %c16_index
  const int64_t v40 = 16;
  // pto: %c32_index
  const int64_t v41 = 32;
  // pto: %cst_16
  const float v42 = 0.0441941731f;
  // pto: %cst_17
  const float v43 = -3.00000001E+38f;
  // pto: %cst_18
  const float v44 = 0.0f;
  // pto: %sparse_blk_li__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %sparse_blk_li__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %sparse_blk_li__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %sparse_blk_li__ssa_v0_view
  int64_t v48 = (int64_t) v17;
  // pto: %sparse_blk_li__ssa_v0_view
  int64_t v49 = v48 * v33;
  // pto: %sparse_blk_li__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %sparse_blk_li__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v33);
  // pto: %sparse_blk_li__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v33, (int64_t) v17);
  // pto: %sparse_blk_li__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v1, v51, v52);
  // pto: %sparse_blk_mi__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %sparse_blk_mi__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %sparse_blk_mi__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %sparse_blk_mi__ssa_v0_view
  int64_t v57 = (int64_t) v17;
  // pto: %sparse_blk_mi__ssa_v0_view
  int64_t v58 = v57 * v33;
  // pto: %sparse_blk_mi__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %sparse_blk_mi__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v33);
  // pto: %sparse_blk_mi__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v33, (int64_t) v17);
  // pto: %sparse_blk_mi__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v60, v61);
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v66 = (int64_t) v17;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v67 = v66 * v34;
  // pto: %sparse_blk_oi__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %sparse_blk_oi__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v34);
  // pto: %sparse_blk_oi__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v34, v33);
  // pto: %sparse_blk_oi__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v69, v70);
  // pto: %sparse_bias__rv_v3_view
  const int64_t v72 = 1;
  // pto: %sparse_bias__rv_v3_view
  const int64_t v73 = 1;
  // pto: %sparse_bias__rv_v3_view
  const int64_t v74 = 1;
  // pto: %sparse_bias__rv_v3_view
  int64_t v75 = (int64_t) v18;
  // pto: %sparse_bias__rv_v3_view
  int64_t v76 = v35 * v75;
  // pto: %sparse_bias__rv_v3_view
  int64_t v77 = v74 * v76;
  // pto: %sparse_bias__rv_v3_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v35, (int64_t) v18);
  // pto: %sparse_bias__rv_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v75, v33);
  // pto: %sparse_bias__rv_v3_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v78, v79);
  auto v81 = TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>(v12, v25, v25);
  // pto: %subblock_idx, %26
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  if ((int64_t) v24 == v38) {
    // pto: %qk_core__ssa_v0
    ;
    int64_t v82 = (int64_t) v22;
    // pto: %27
    ;
    int64_t v83 = (int64_t) ((uint64_t) v13 - (uint64_t) v82);
    // pto: %28
    ;
    int64_t v84 = (int64_t) ((uint64_t) v83 + (uint64_t) v14);
    // pto: %29, %30
    ;
    for (int64_t v85 = v38; v85 < ((int64_t) ((uint64_t) v84 - (uint64_t) v33) / v14); v85 += v33) {
      // pto: %31
      ;
      int64_t v86 = (int64_t) ((uint64_t) v85 * (uint64_t) v14);
      // pto: %32
      ;
      int64_t v87 = (int64_t) ((uint64_t) v82 + (uint64_t) v86);
      // pto: %33
      ;
      int64_t v88 = v87 / v35;
      // pto: %34
      ;
      int64_t v89 = (int64_t) ((uint64_t) v88 * (uint64_t) v35);
      // pto: %35
      ;
      int64_t v90 = (int64_t) ((uint64_t) v87 - (uint64_t) v89);
      // pto: %37
      ;
      int64_t v91 = (int64_t) ((uint64_t) v90 * (uint64_t) v36);
      // pto: %38
      ;
      int64_t v92 = (int64_t) ((uint64_t) v91 * (uint64_t) v15);
      // pto: %39
      ;
      int64_t v93 = (int64_t) ((uint64_t) v92 * (uint64_t) v40);
      // pto: %qk_pos__tile
      ;
      int32_t v94 = (v4)[v90];
      // pto: %36, %qk_len__tile
      ;
      int32_t v95 = (v5)[v90 / v39];
      // pto: %40, %41
      ;
      int64_t v96 = (int64_t) ((uint64_t) ((int64_t) v94) + (uint64_t) v33);
      // pto: %42
      ;
      int64_t v97 = (int64_t) v95;
      // pto: %43
      ;
      int64_t v98 = v96 < v97 ? v96 : v97;
      // pto: %44
      ;
      int64_t v99 = v98 / v37;
      // pto: %45
      ;
      int64_t v100 = v99 < v16 ? v99 : v16;
      // pto: %46
      ;
      int64_t v101 = (int64_t) ((uint64_t) v88 * (uint64_t) v37);
      // pto: %47, %48
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      if (v101 < (int64_t) ((uint64_t) v100 + (uint64_t) v37)) {
        // pto: %qk_bias_row__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v33, v37);
        // pto: %qk_bias_row__tile
        ;
        uint64_t v103 = (uint64_t) v26;
        TASSIGN(v102, v103);
        // pto: %49
        ;
        int64_t v104 = v90 < v38 ? v38 : v90;
        // pto: %50
        ;
        int64_t v105 = v101 < v38 ? v38 : v101;
        // pto: %sparse_bias__rv_v3_pview
        ;
        int64_t v106 = (int64_t) v18;
        // pto: %sparse_bias__rv_v3_pview
        ;
        const int64_t v107 = 0;
        // pto: %sparse_bias__rv_v3_pview
        ;
        __gm__ float* v108 = PTOAS__GLOBAL_TENSOR_DATA(v80);
        // pto: %sparse_bias__rv_v3_pview
        ;
        const int64_t v109 = 1;
        // pto: %sparse_bias__rv_v3_pview
        ;
        const int64_t v110 = 1;
        // pto: %sparse_bias__rv_v3_pview
        ;
        const int64_t v111 = 1;
        // pto: %sparse_bias__rv_v3_pview
        ;
        int64_t v112 = v33 * v106;
        // pto: %sparse_bias__rv_v3_pview
        ;
        int64_t v113 = v111 * v112;
        // pto: %sparse_bias__rv_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v114 = pto::Shape<1, 1, 1, 1, 128>(v109, v110, v111, v33, v37);
        // pto: %sparse_bias__rv_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v115 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v113, v113, v112, v106, v33);
        // pto: %sparse_bias__rv_v3_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v116 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v108 + (v107 + v104 * v106 + v105 * v33), v114, v115);
        TLOAD(v102, v116);
        for (int64_t v117 = v38; v117 < v39; v117 += v33) {
          // pto: %qk_raw__tile_Vec
          ;
          const int32_t v118 = 32;
          // pto: %qk_raw__tile_Vec
          ;
          const int32_t v119 = 128;
          // pto: %qk_raw__tile_Vec
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v118, v119);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v81, v120);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %qk_scaled__tile
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %qk_scaled__tile
          ;
          uint64_t v122 = (uint64_t) v27;
          TASSIGN(v121, v122);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          TMULS(v121, v120, v42);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v81);
          // pto: %qk_scores__tile
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %qk_scores__tile
          ;
          uint64_t v124 = (uint64_t) v27;
          TASSIGN(v123, v124);
          pipe_barrier(PIPE_V);
          TCOLEXPANDADD(v123, v121, v102);
          // pto: %tmp_tile
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %tmp_tile
          ;
          uint64_t v126 = (uint64_t) v28;
          TASSIGN(v125, v126);
          // pto: %qk_mi__tile
          ;
          Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v33);
          // pto: %qk_mi__tile
          ;
          uint64_t v128 = (uint64_t) v29;
          TASSIGN(v127, v128);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          TROWMAX(v127, v123, v125);
          // pto: %t__tile
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %t__tile
          ;
          uint64_t v130 = (uint64_t) v27;
          TASSIGN(v129, v130);
          pipe_barrier(PIPE_V);
          TROWEXPANDSUB(v129, v123, v127);
          // pto: %qk_exp__tile
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %qk_exp__tile
          ;
          uint64_t v132 = (uint64_t) v27;
          TASSIGN(v131, v132);
          pipe_barrier(PIPE_V);
          TEXP(v131, v129);
          // pto: %0
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %0
          ;
          uint64_t v134 = (uint64_t) v28;
          TASSIGN(v133, v134);
          // pto: %qk_li__tile
          ;
          Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v33);
          // pto: %qk_li__tile
          ;
          uint64_t v136 = (uint64_t) v30;
          TASSIGN(v135, v136);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
          TROWSUM(v135, v131, v133);
          // pto: %qk_exp_bf16__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v37);
          // pto: %qk_exp_bf16__tile
          ;
          uint64_t v138 = (uint64_t) v27;
          TASSIGN(v137, v138);
          pipe_barrier(PIPE_V);
          RoundMode v139 = RoundMode::CAST_RINT;
          SaturationMode v140 = SaturationMode::OFF;
          TCVT(v137, v131, v139, v140);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v81, v137);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          // pto: %51
          ;
          int64_t v141 = (int64_t) ((uint64_t) v117 * (uint64_t) v39);
          // pto: %52
          ;
          int64_t v142 = (int64_t) ((uint64_t) v141 * (uint64_t) v15);
          // pto: %53
          ;
          int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v40);
          // pto: %54
          ;
          int64_t v144 = (int64_t) ((uint64_t) v93 + (uint64_t) v143);
          // pto: %55
          ;
          int64_t v145 = (int64_t) ((uint64_t) v88 * (uint64_t) v40);
          // pto: %56
          ;
          int64_t v146 = (int64_t) ((uint64_t) v144 + (uint64_t) v145);
          // pto: %1
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
          // pto: %1
          ;
          uint64_t v148 = (uint64_t) v29;
          TASSIGN(v147, v148);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149;
          // pto: %slice_view
          ;
          uint64_t v150 = (uint64_t) v29;
          TASSIGN(v149, v150);
          // pto: %57
          ;
          int64_t v151 = v146 < v38 ? v38 : v146;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          int64_t v152 = (int64_t) v17;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          const int64_t v153 = 0;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          __gm__ float* v154 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          const int64_t v155 = 1;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          const int64_t v156 = 1;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          const int64_t v157 = 1;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          int64_t v158 = v40 * v33;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          int64_t v159 = v157 * v158;
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v160 = pto::Shape<1, 1, 1, 16, 1>(v155, v156, v157, v40, v33);
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v161 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v159, v159, v158, v33, v152);
          // pto: %sparse_blk_mi__iter_v3_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v154 + (v153 + v151 * v33 + v38 * v152), v160, v161);
          TSTORE(v162, v149);
          // pto: %2
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
          // pto: %2
          ;
          uint64_t v164 = (uint64_t) v30;
          TASSIGN(v163, v164);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165;
          // pto: %58
          ;
          uint64_t v166 = (uint64_t) v30;
          TASSIGN(v165, v166);
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          int64_t v167 = (int64_t) v17;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          const int64_t v168 = 0;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          __gm__ float* v169 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          const int64_t v170 = 1;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          const int64_t v171 = 1;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          const int64_t v172 = 1;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          int64_t v173 = v40 * v33;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          int64_t v174 = v172 * v173;
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v175 = pto::Shape<1, 1, 1, 16, 1>(v170, v171, v172, v40, v33);
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v176 = pto::Stride<-1, -1, -1, -1, -1>(v171 * v174, v174, v173, v33, v167);
          // pto: %sparse_blk_li__iter_v3_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v177 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v169 + (v168 + v151 * v33 + v38 * v167), v175, v176);
          TSTORE(v177, v165);
          // pto: %61
          ;
          int64_t v178 = (int64_t) ((uint64_t) v141 + (uint64_t) v33);
          // pto: %62
          ;
          int64_t v179 = (int64_t) ((uint64_t) v178 * (uint64_t) v15);
          // pto: %63
          ;
          int64_t v180 = (int64_t) ((uint64_t) v179 * (uint64_t) v40);
          // pto: %64
          ;
          int64_t v181 = (int64_t) ((uint64_t) v93 + (uint64_t) v180);
          // pto: %66
          ;
          int64_t v182 = (int64_t) ((uint64_t) v181 + (uint64_t) v145);
          // pto: %3
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
          // pto: %3
          ;
          uint64_t v184 = (uint64_t) v31;
          TASSIGN(v183, v184);
          // pto: %67
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185;
          // pto: %67
          ;
          uint64_t v186 = (uint64_t) v31;
          TASSIGN(v185, v186);
          // pto: %69
          ;
          int64_t v187 = v182 < v38 ? v38 : v182;
          // pto: %sparse_blk_mi__tile_pview
          ;
          int64_t v188 = (int64_t) v17;
          // pto: %sparse_blk_mi__tile_pview
          ;
          const int64_t v189 = 0;
          // pto: %sparse_blk_mi__tile_pview
          ;
          __gm__ float* v190 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %sparse_blk_mi__tile_pview
          ;
          const int64_t v191 = 1;
          // pto: %sparse_blk_mi__tile_pview
          ;
          const int64_t v192 = 1;
          // pto: %sparse_blk_mi__tile_pview
          ;
          const int64_t v193 = 1;
          // pto: %sparse_blk_mi__tile_pview
          ;
          int64_t v194 = v40 * v33;
          // pto: %sparse_blk_mi__tile_pview
          ;
          int64_t v195 = v193 * v194;
          // pto: %sparse_blk_mi__tile_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v196 = pto::Shape<1, 1, 1, 16, 1>(v191, v192, v193, v40, v33);
          // pto: %sparse_blk_mi__tile_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v197 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v195, v195, v194, v33, v188);
          // pto: %sparse_blk_mi__tile_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v198 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v190 + (v189 + v187 * v33 + v38 * v188), v196, v197);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v198, v185);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          // pto: %4
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
          // pto: %4
          ;
          uint64_t v200 = (uint64_t) v32;
          TASSIGN(v199, v200);
          // pto: %70
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201;
          // pto: %70
          ;
          uint64_t v202 = (uint64_t) v32;
          TASSIGN(v201, v202);
          // pto: %sparse_blk_li__tile_pview
          ;
          int64_t v203 = (int64_t) v17;
          // pto: %sparse_blk_li__tile_pview
          ;
          const int64_t v204 = 0;
          // pto: %sparse_blk_li__tile_pview
          ;
          __gm__ float* v205 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %sparse_blk_li__tile_pview
          ;
          const int64_t v206 = 1;
          // pto: %sparse_blk_li__tile_pview
          ;
          const int64_t v207 = 1;
          // pto: %sparse_blk_li__tile_pview
          ;
          const int64_t v208 = 1;
          // pto: %sparse_blk_li__tile_pview
          ;
          int64_t v209 = v40 * v33;
          // pto: %sparse_blk_li__tile_pview
          ;
          int64_t v210 = v208 * v209;
          // pto: %sparse_blk_li__tile_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v211 = pto::Shape<1, 1, 1, 16, 1>(v206, v207, v208, v40, v33);
          // pto: %sparse_blk_li__tile_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v212 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v210, v210, v209, v33, v203);
          // pto: %sparse_blk_li__tile_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v213 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v205 + (v204 + v187 * v33 + v38 * v203), v211, v212);
          TSTORE(v213, v201);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        };
      } else {
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v33, v40);
        // pto: %5
        ;
        uint64_t v215 = (uint64_t) v28;
        TASSIGN(v214, v215);
        pipe_barrier(PIPE_V);
        TEXPANDS(v214, v43);
        // pto: %qk_mi_neg__tile
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
        // pto: %qk_mi_neg__tile
        ;
        uint64_t v217 = (uint64_t) v28;
        TASSIGN(v216, v217);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v33, v40);
        // pto: %6
        ;
        uint64_t v219 = (uint64_t) v26;
        TASSIGN(v218, v219);
        TEXPANDS(v218, v44);
        // pto: %qk_li_zero__tile
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v33);
        // pto: %qk_li_zero__tile
        ;
        uint64_t v221 = (uint64_t) v26;
        TASSIGN(v220, v221);
        // pto: %qk_oi_zero__tile
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v34);
        // pto: %qk_oi_zero__tile
        ;
        uint64_t v223 = (uint64_t) v27;
        TASSIGN(v222, v223);
        TEXPANDS(v222, v44);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        for (int64_t v224 = v38; v224 < v36; v224 += v33) {
          // pto: %73
          ;
          int64_t v225 = (int64_t) ((uint64_t) v224 * (uint64_t) v15);
          // pto: %74
          ;
          int64_t v226 = (int64_t) ((uint64_t) v225 * (uint64_t) v40);
          // pto: %75
          ;
          int64_t v227 = (int64_t) ((uint64_t) v93 + (uint64_t) v226);
          // pto: %76
          ;
          int64_t v228 = (int64_t) ((uint64_t) v88 * (uint64_t) v40);
          // pto: %77
          ;
          int64_t v229 = (int64_t) ((uint64_t) v227 + (uint64_t) v228);
          // pto: %79
          ;
          int64_t v230 = v229 < v38 ? v38 : v229;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          int64_t v231 = (int64_t) v17;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          const int64_t v232 = 0;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          __gm__ float* v233 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          const int64_t v234 = 1;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          const int64_t v235 = 1;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          const int64_t v236 = 1;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          int64_t v237 = v40 * v33;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          int64_t v238 = v236 * v237;
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v239 = pto::Shape<1, 1, 1, 16, 1>(v234, v235, v236, v40, v33);
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v240 = pto::Stride<-1, -1, -1, -1, -1>(v235 * v238, v238, v237, v33, v231);
          // pto: %sparse_blk_mi__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v241 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v233 + (v232 + v230 * v33 + v38 * v231), v239, v240);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v241, v216);
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          int64_t v242 = (int64_t) v17;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          const int64_t v243 = 0;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          __gm__ float* v244 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          const int64_t v245 = 1;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          const int64_t v246 = 1;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          const int64_t v247 = 1;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          int64_t v248 = v40 * v33;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          int64_t v249 = v247 * v248;
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, 16, 1> v250 = pto::Shape<1, 1, 1, 16, 1>(v245, v246, v247, v40, v33);
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v251 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v249, v249, v248, v33, v242);
          // pto: %sparse_blk_li__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v244 + (v243 + v230 * v33 + v38 * v242), v250, v251);
          TSTORE(v252, v220);
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          __gm__ float* v253 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          const int64_t v254 = 0;
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          const int64_t v255 = 512;
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, 16, 512> v256 = pto::Shape<1, 1, 1, 16, 512>();
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          pto::Stride<8192, 8192, 8192, 512, 1> v257 = pto::Stride<8192, 8192, 8192, 512, 1>();
          // pto: %sparse_blk_oi__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v258 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v253 + (v254 + v230 * v255), v256, v257);
          TSTORE(v258, v222);
        };
      };
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  } else {
    // pto: %83
    ;
    int64_t v259 = (int64_t) v22;
    // pto: %84
    ;
    int64_t v260 = (int64_t) ((uint64_t) v13 - (uint64_t) v259);
    // pto: %85
    ;
    int64_t v261 = (int64_t) ((uint64_t) v260 + (uint64_t) v14);
    // pto: %86, %87
    ;
    for (int64_t v262 = v38; v262 < ((int64_t) ((uint64_t) v261 - (uint64_t) v33) / v14); v262 += v33) {
      // pto: %89
      ;
      int64_t v263 = (int64_t) ((uint64_t) v262 * (uint64_t) v14);
      // pto: %90
      ;
      int64_t v264 = (int64_t) ((uint64_t) v259 + (uint64_t) v263);
      // pto: %91
      ;
      int64_t v265 = v264 / v35;
      // pto: %92
      ;
      int64_t v266 = (int64_t) ((uint64_t) v265 * (uint64_t) v35);
      // pto: %93
      ;
      int64_t v267 = (int64_t) ((uint64_t) v264 - (uint64_t) v266);
      // pto: %95
      ;
      int32_t v268 = (v4)[v267];
      // pto: %94, %96
      ;
      int32_t v269 = (v5)[v267 / v39];
      // pto: %97, %98
      ;
      int64_t v270 = (int64_t) ((uint64_t) ((int64_t) v268) + (uint64_t) v33);
      // pto: %99
      ;
      int64_t v271 = (int64_t) v269;
      // pto: %100
      ;
      int64_t v272 = v270 < v271 ? v270 : v271;
      // pto: %101
      ;
      int64_t v273 = v272 / v37;
      // pto: %102
      ;
      int64_t v274 = v273 < v16 ? v273 : v16;
      // pto: %103, %104, %105
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if ((int64_t) ((uint64_t) v265 * (uint64_t) v37) < (int64_t) ((uint64_t) v274 + (uint64_t) v37)) {
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %7
        ;
        uint64_t v276 = (uint64_t) v26;
        TASSIGN(v275, v276);
        for (int64_t v277 = v38; v277 < v39; v277 += v33) {
          // pto: %107
          ;
          const int32_t v278 = 32;
          // pto: %107
          ;
          const int32_t v279 = 128;
          // pto: %107
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v278, v279);
          v280.SetValidShape(v38, v38);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v81, v280);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %8
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %8
          ;
          uint64_t v282 = (uint64_t) v27;
          TASSIGN(v281, v282);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          pipe_barrier(PIPE_V);
          TMULS(v281, v280, v42);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v81);
          // pto: %9
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %9
          ;
          uint64_t v284 = (uint64_t) v27;
          TASSIGN(v283, v284);
          pipe_barrier(PIPE_V);
          TCOLEXPANDADD(v283, v281, v275);
          // pto: %10
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %10
          ;
          uint64_t v286 = (uint64_t) v28;
          TASSIGN(v285, v286);
          // pto: %11
          ;
          Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %11
          ;
          uint64_t v288 = (uint64_t) v29;
          TASSIGN(v287, v288);
          pipe_barrier(PIPE_V);
          TROWMAX(v287, v283, v285);
          // pto: %12
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %12
          ;
          uint64_t v290 = (uint64_t) v27;
          TASSIGN(v289, v290);
          pipe_barrier(PIPE_V);
          TROWEXPANDSUB(v289, v283, v287);
          // pto: %13
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %13
          ;
          uint64_t v292 = (uint64_t) v27;
          TASSIGN(v291, v292);
          pipe_barrier(PIPE_V);
          TEXP(v291, v289);
          // pto: %14
          ;
          Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %14
          ;
          uint64_t v294 = (uint64_t) v28;
          TASSIGN(v293, v294);
          // pto: %15
          ;
          Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %15
          ;
          uint64_t v296 = (uint64_t) v29;
          TASSIGN(v295, v296);
          pipe_barrier(PIPE_V);
          TROWSUM(v295, v291, v293);
          // pto: %16
          ;
          Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %16
          ;
          uint64_t v298 = (uint64_t) v27;
          TASSIGN(v297, v298);
          pipe_barrier(PIPE_V);
          RoundMode v299 = RoundMode::CAST_RINT;
          SaturationMode v300 = SaturationMode::OFF;
          TCVT(v297, v291, v299, v300);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v81, v297);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          // pto: %17
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %17
          ;
          uint64_t v302 = (uint64_t) v27;
          TASSIGN(v301, v302);
          // pto: %18
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %18
          ;
          uint64_t v304 = (uint64_t) v27;
          TASSIGN(v303, v304);
          // pto: %19
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %19
          ;
          uint64_t v306 = (uint64_t) v27;
          TASSIGN(v305, v306);
          // pto: %20
          ;
          Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
          // pto: %20
          ;
          uint64_t v308 = (uint64_t) v27;
          TASSIGN(v307, v308);
        };
      } else {
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %21
        ;
        uint64_t v310 = (uint64_t) v27;
        TASSIGN(v309, v310);
        pipe_barrier(PIPE_V);
        TEXPANDS(v309, v43);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %22
        ;
        uint64_t v312 = (uint64_t) v27;
        TASSIGN(v311, v312);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %23
        ;
        uint64_t v314 = (uint64_t) v27;
        TASSIGN(v313, v314);
        pipe_barrier(PIPE_V);
        TEXPANDS(v313, v44);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %24
        ;
        uint64_t v316 = (uint64_t) v27;
        TASSIGN(v315, v316);
        // pto: %25
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v38);
        // pto: %25
        ;
        uint64_t v318 = (uint64_t) v27;
        TASSIGN(v317, v318);
        pipe_barrier(PIPE_V);
        TEXPANDS(v317, v44);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}