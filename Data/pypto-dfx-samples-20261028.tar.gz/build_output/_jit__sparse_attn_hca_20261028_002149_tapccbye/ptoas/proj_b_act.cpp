#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void proj_b_act(__gm__ float* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, int32_t v5, int32_t v6) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v7 = 0;
  // pto: %c2048_i64
  const int64_t v8 = 2048;
  // pto: %c18432_i64
  const int64_t v9 = 18432;
  // pto: %c34816_i64
  const int64_t v10 = 34816;
  // pto: %c34848_i64
  const int64_t v11 = 34848;
  // pto: %c51232_i64
  const int64_t v12 = 51232;
  // pto: %c4096_index
  const int64_t v13 = 4096;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c16_index
  const int64_t v15 = 16;
  // pto: %c32768_index
  const int64_t v16 = 32768;
  // pto: %c8_index
  const int64_t v17 = 8;
  // pto: %c512_index
  const int64_t v18 = 512;
  const int64_t v19 = 0;
  // pto: %cst_13
  const float v20 = 0.0f;
  // pto: %c2_index
  const int64_t v21 = 2;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v26 = v13 * v14;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v27 = v25 * v26;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v28 = v24 * v27;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v29 = pto::Shape<1, 1, 1, 1, -1>(v22, v23, v24, v25, v13);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v28, v28, v27, v26, v14);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v29, v30);
  // pto: %partials__rv_v2_view
  const int64_t v32 = 1;
  // pto: %partials__rv_v2_view
  const int64_t v33 = 1;
  // pto: %partials__rv_v2_view
  const int64_t v34 = 1;
  // pto: %partials__rv_v2_view
  int64_t v35 = v15 * v16;
  // pto: %partials__rv_v2_view
  int64_t v36 = v34 * v35;
  // pto: %partials__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v15, v16);
  // pto: %partials__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v16, v14);
  // pto: %partials__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v37, v38);
  // pto: %act_scale_dq__rv_v2_view
  const int64_t v40 = 1;
  // pto: %act_scale_dq__rv_v2_view
  const int64_t v41 = 1;
  // pto: %act_scale_dq__rv_v2_view
  const int64_t v42 = 1;
  // pto: %act_scale_dq__rv_v2_view
  int64_t v43 = v17 * v17;
  // pto: %act_scale_dq__rv_v2_view
  int64_t v44 = v42 * v43;
  // pto: %act_scale_dq__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v17, v17);
  // pto: %act_scale_dq__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v14);
  // pto: %act_scale_dq__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %attn_out__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %attn_out__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %attn_out__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %attn_out__ssa_v0_view
  int64_t v51 = v17 * v13;
  // pto: %attn_out__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %attn_out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v17, v13);
  // pto: %attn_out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v13, v14);
  // pto: %attn_out__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %act_idx__ssa_v0, %8
  int64_t v56 = (int64_t) ((uint64_t) ((int64_t) v5) * (uint64_t) v18);
  // pto: %wb_scale__tile
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v18);
  // pto: %wb_scale__tile
  uint64_t v58 = (uint64_t) v7;
  TASSIGN(v57, v58);
  // pto: %10
  int64_t v59 = v56 < v19 ? v19 : v56;
  // pto: %wo_b_scale__ssa_v0_pview
  __gm__ float* v60 = PTOAS__GLOBAL_TENSOR_DATA(v31);
  // pto: %wo_b_scale__ssa_v0_pview
  const int64_t v61 = 0;
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 512> v62 = pto::Shape<1, 1, 1, 1, 512>();
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Stride<512, 512, 512, 512, 1> v63 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %wo_b_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v60 + (v61 + v59), v62, v63);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v57, v64);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  // pto: %wb_scale_chunk__tile
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v18);
  // pto: %wb_scale_chunk__tile
  uint64_t v66 = (uint64_t) v7;
  TASSIGN(v65, v66);
  // pto: %acc__tile
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %acc__tile
  uint64_t v68 = (uint64_t) v8;
  TASSIGN(v67, v68);
  TEXPANDS(v67, v20);
  for (int64_t v69 = v19; v69 < v17; v69 += v21) {
    // pto: %11
    ;
    int64_t v70 = (int64_t) ((uint64_t) v69 * (uint64_t) v13);
    // pto: %12
    ;
    int64_t v71 = (int64_t) ((uint64_t) v70 + (uint64_t) v56);
    // pto: %15
    ;
    int64_t v72 = (int64_t) ((uint64_t) v71 + (uint64_t) v13);
    // pto: %p_g__tile
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %p_g__tile
    ;
    uint64_t v74 = (uint64_t) v9;
    TASSIGN(v73, v74);
    // pto: %17
    ;
    int64_t v75 = v71 < v19 ? v19 : v71;
    // pto: %partials__rv_v2_pview
    ;
    __gm__ int32_t* v76 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %partials__rv_v2_pview
    ;
    const int64_t v77 = 0;
    // pto: %partials__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 8, 512> v78 = pto::Shape<1, 1, 1, 8, 512>();
    // pto: %partials__rv_v2_pview
    ;
    pto::Stride<262144, 262144, 262144, 32768, 1> v79 = pto::Stride<262144, 262144, 262144, 32768, 1>();
    // pto: %partials__rv_v2_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v80 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v76 + (v77 + v75), v78, v79);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v73, v80);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %g_scale_row__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v17);
    // pto: %g_scale_row__tile
    ;
    uint64_t v82 = (uint64_t) v10;
    TASSIGN(v81, v82);
    // pto: %18
    ;
    int64_t v83 = v69 < v19 ? v19 : v69;
    // pto: %act_scale_dq__rv_v2_pview
    ;
    __gm__ float* v84 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %act_scale_dq__rv_v2_pview
    ;
    const int64_t v85 = 0;
    // pto: %act_scale_dq__rv_v2_pview
    ;
    const int64_t v86 = 8;
    // pto: %act_scale_dq__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v87 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %act_scale_dq__rv_v2_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v88 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %act_scale_dq__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v84 + (v85 + v83 * v86), v87, v88);
    TLOAD(v81, v89);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %0
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %0
    ;
    uint64_t v91 = (uint64_t) v11;
    TASSIGN(v90, v91);
    // pto: %21
    ;
    int64_t v92 = v72 < v19 ? v19 : v72;
    // pto: %22
    ;
    __gm__ int32_t* v93 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %22
    ;
    const int64_t v94 = 0;
    // pto: %22
    ;
    pto::Shape<1, 1, 1, 8, 512> v95 = pto::Shape<1, 1, 1, 8, 512>();
    // pto: %22
    ;
    pto::Stride<262144, 262144, 262144, 32768, 1> v96 = pto::Stride<262144, 262144, 262144, 32768, 1>();
    // pto: %22
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v97 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v93 + (v94 + v92), v95, v96);
    TLOAD(v90, v97);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v17);
    // pto: %1
    ;
    uint64_t v99 = (uint64_t) v12;
    TASSIGN(v98, v99);
    // pto: %23
    ;
    int64_t v100 = (int64_t) ((uint64_t) v69 + (uint64_t) v14);
    // pto: %24
    ;
    int64_t v101 = v100 < v19 ? v19 : v100;
    // pto: %26
    ;
    __gm__ float* v102 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %26
    ;
    const int64_t v103 = 0;
    // pto: %26
    ;
    const int64_t v104 = 8;
    // pto: %26
    ;
    pto::Shape<1, 1, 1, 1, 8> v105 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %26
    ;
    pto::Stride<8, 8, 8, 8, 1> v106 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %26
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v107 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v102 + (v103 + v101 * v104), v105, v106);
    TLOAD(v98, v107);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %g_scale__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %g_scale__tile
    ;
    uint64_t v109 = (uint64_t) v10;
    TASSIGN(v108, v109);
    // pto: %p_g_f32__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %p_g_f32__tile
    ;
    uint64_t v111 = (uint64_t) v9;
    TASSIGN(v110, v111);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v112 = RoundMode::CAST_NONE;
    SaturationMode v113 = SaturationMode::OFF;
    TCVT(v110, v73, v112, v113);
    // pto: %p_g_scaled__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %p_g_scaled__tile
    ;
    uint64_t v115 = (uint64_t) v9;
    TASSIGN(v114, v115);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v114, v110, v108);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %2
    ;
    uint64_t v117 = (uint64_t) v9;
    TASSIGN(v116, v117);
    pipe_barrier(PIPE_V);
    TADD(v116, v67, v114);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %3
    ;
    uint64_t v119 = (uint64_t) v12;
    TASSIGN(v118, v119);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %4
    ;
    uint64_t v121 = (uint64_t) v11;
    TASSIGN(v120, v121);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v122 = RoundMode::CAST_NONE;
    SaturationMode v123 = SaturationMode::OFF;
    TCVT(v120, v90, v122, v123);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %5
    ;
    uint64_t v125 = (uint64_t) v11;
    TASSIGN(v124, v125);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TROWEXPANDMUL(v124, v120, v118);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
    // pto: %6
    ;
    uint64_t v127 = (uint64_t) v8;
    TASSIGN(v126, v127);
    pipe_barrier(PIPE_V);
    TADD(v126, v116, v124);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  // pto: %out_t__tile
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %out_t__tile
  uint64_t v129 = (uint64_t) v8;
  TASSIGN(v128, v129);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  TCOLEXPANDMUL(v128, v67, v65);
  // pto: %out_bf16__tile
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %out_bf16__tile
  uint64_t v131 = (uint64_t) v8;
  TASSIGN(v130, v131);
  pipe_barrier(PIPE_V);
  RoundMode v132 = RoundMode::CAST_RINT;
  SaturationMode v133 = SaturationMode::OFF;
  TCVT(v130, v128, v132, v133);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %attn_out__ssa_v0_pview
  __gm__ bfloat16_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v55);
  // pto: %attn_out__ssa_v0_pview
  const int64_t v135 = 0;
  // pto: %attn_out__ssa_v0_pview
  pto::Shape<1, 1, 1, 8, 512> v136 = pto::Shape<1, 1, 1, 8, 512>();
  // pto: %attn_out__ssa_v0_pview
  pto::Stride<32768, 32768, 32768, 4096, 1> v137 = pto::Stride<32768, 32768, 32768, 4096, 1>();
  // pto: %attn_out__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<32768, 32768, 32768, 4096, 1>, pto::Layout::ND>(v134 + (v135 + v59), v136, v137);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v138, v130);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}