#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void quant(__gm__ float* v1, __gm__ int8_t* v2, __gm__ float* v3, int64_t v4, int64_t v5) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v6 = 0;
  // pto: %c32768_i64
  const int64_t v7 = 32768;
  // pto: %c65536_i64
  const int64_t v8 = 65536;
  // pto: %c8_index
  const int64_t v9 = 8;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c16_index
  const int64_t v11 = 16;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1024_index
  const int64_t v13 = 1024;
  // pto: %c0_index
  const int64_t v14 = 0;
  // pto: %cst_9
  const float v15 = 9.99999974E-5f;
  // pto: %cst_10
  const float v16 = 127.0f;
  // pto: %cst_11
  const half v17 = 0.0f;
  // pto: %act_scale_dq__iter_v1_view
  const int64_t v18 = 1;
  // pto: %act_scale_dq__iter_v1_view
  const int64_t v19 = 1;
  // pto: %act_scale_dq__iter_v1_view
  const int64_t v20 = 1;
  // pto: %act_scale_dq__iter_v1_view
  int64_t v21 = v9 * v9;
  // pto: %act_scale_dq__iter_v1_view
  int64_t v22 = v20 * v21;
  // pto: %act_scale_dq__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v23 = pto::Shape<1, 1, 1, -1, -1>(v18, v19, v20, v9, v9);
  // pto: %act_scale_dq__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v24 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v22, v22, v21, v9, v10);
  // pto: %act_scale_dq__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v25 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v23, v24);
  // pto: %o_r_i8_pad__iter_v1_view
  const int64_t v26 = 1;
  // pto: %o_r_i8_pad__iter_v1_view
  const int64_t v27 = 1;
  // pto: %o_r_i8_pad__iter_v1_view
  const int64_t v28 = 1;
  // pto: %o_r_i8_pad__iter_v1_view
  int64_t v29 = v11 * v12;
  // pto: %o_r_i8_pad__iter_v1_view
  int64_t v30 = v28 * v29;
  // pto: %o_r_i8_pad__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v11, v12);
  // pto: %o_r_i8_pad__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v30, v30, v29, v12, v10);
  // pto: %o_r_i8_pad__iter_v1_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v31, v32);
  // pto: %o_r_pad__ssa_v3_view
  const int64_t v34 = 1;
  // pto: %o_r_pad__ssa_v3_view
  const int64_t v35 = 1;
  // pto: %o_r_pad__ssa_v3_view
  const int64_t v36 = 1;
  // pto: %o_r_pad__ssa_v3_view
  int64_t v37 = v11 * v12;
  // pto: %o_r_pad__ssa_v3_view
  int64_t v38 = v36 * v37;
  // pto: %o_r_pad__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v11, v12);
  // pto: %o_r_pad__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v38, v38, v37, v12, v10);
  // pto: %o_r_pad__ssa_v3_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v39, v40);
  // pto: %oc_amax__tile
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oc_amax__tile
  uint64_t v43 = (uint64_t) v6;
  TASSIGN(v42, v43);
  // pto: %0
  int64_t v44 = v4 < v14 ? v14 : v4;
  // pto: %o_r_pad__ssa_v3_pview
  __gm__ float* v45 = PTOAS__GLOBAL_TENSOR_DATA(v41);
  // pto: %o_r_pad__ssa_v3_pview
  const int64_t v46 = 0;
  // pto: %o_r_pad__ssa_v3_pview
  pto::Shape<1, 1, 1, 8, 1024> v47 = pto::Shape<1, 1, 1, 8, 1024>();
  // pto: %o_r_pad__ssa_v3_pview
  pto::Stride<65536, 65536, 65536, 8192, 1> v48 = pto::Stride<65536, 65536, 65536, 8192, 1>();
  // pto: %o_r_pad__ssa_v3_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v45 + (v46 + v44), v47, v48);
  TLOAD(v42, v49);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %g_abs__tile
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %g_abs__tile
  uint64_t v51 = (uint64_t) v6;
  TASSIGN(v50, v51);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TABS(v50, v42);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %tmp_tile
  uint64_t v53 = (uint64_t) v7;
  TASSIGN(v52, v53);
  // pto: %g_row_max__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v10);
  // pto: %g_row_max__tile
  uint64_t v55 = (uint64_t) v8;
  TASSIGN(v54, v55);
  pipe_barrier(PIPE_V);
  TROWMAX(v54, v50, v52);
  // pto: %g_row_max_v1__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %g_row_max_v1__tile
  uint64_t v57 = (uint64_t) v8;
  TASSIGN(v56, v57);
  // pto: %g_amax_floor__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %g_amax_floor__tile
  uint64_t v59 = (uint64_t) v6;
  TASSIGN(v58, v59);
  pipe_barrier(PIPE_V);
  TEXPANDS(v58, v15);
  // pto: %g_amax__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %g_amax__tile
  uint64_t v61 = (uint64_t) v6;
  TASSIGN(v60, v61);
  pipe_barrier(PIPE_V);
  TMAX(v60, v58, v56);
  // pto: %g_scale_num__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %g_scale_num__tile
  uint64_t v63 = (uint64_t) v7;
  TASSIGN(v62, v63);
  TEXPANDS(v62, v16);
  // pto: %g_sq_row__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %g_sq_row__tile
  uint64_t v65 = (uint64_t) v7;
  TASSIGN(v64, v65);
  pipe_barrier(PIPE_V);
  TDIV(v64, v62, v60);
  // pto: %t__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
  // pto: %t__tile
  uint64_t v67 = (uint64_t) v6;
  TASSIGN(v66, v67);
  pipe_barrier(PIPE_V);
  TRECIP(v66, v64);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %1
  int64_t v68 = v5 < v14 ? v14 : v5;
  // pto: %act_scale_dq__iter_v1_pview
  __gm__ float* v69 = PTOAS__GLOBAL_TENSOR_DATA(v25);
  // pto: %act_scale_dq__iter_v1_pview
  const int64_t v70 = 0;
  // pto: %act_scale_dq__iter_v1_pview
  const int64_t v71 = 8;
  // pto: %act_scale_dq__iter_v1_pview
  pto::Shape<1, 1, 1, 1, 8> v72 = pto::Shape<1, 1, 1, 1, 8>();
  // pto: %act_scale_dq__iter_v1_pview
  pto::Stride<8, 8, 8, 8, 1> v73 = pto::Stride<8, 8, 8, 8, 1>();
  // pto: %act_scale_dq__iter_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v69 + (v70 + v68 * v71), v72, v73);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v74, v66);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  // pto: %g_sq_col__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v10);
  // pto: %g_sq_col__tile
  uint64_t v76 = (uint64_t) v7;
  TASSIGN(v75, v76);
  // pto: %oc_q__tile
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oc_q__tile
  uint64_t v78 = (uint64_t) v6;
  TASSIGN(v77, v78);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  TLOAD(v77, v49);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %oq_scaled__tile
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oq_scaled__tile
  uint64_t v80 = (uint64_t) v6;
  TASSIGN(v79, v80);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TROWEXPANDMUL(v79, v77, v75);
  // pto: %oq_i32__tile
  Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oq_i32__tile
  uint64_t v82 = (uint64_t) v6;
  TASSIGN(v81, v82);
  pipe_barrier(PIPE_V);
  RoundMode v83 = RoundMode::CAST_RINT;
  SaturationMode v84 = SaturationMode::ON;
  TCVT(v81, v79, v83, v84);
  // pto: %oq_half__tile
  Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oq_half__tile
  uint64_t v86 = (uint64_t) v6;
  TASSIGN(v85, v86);
  pipe_barrier(PIPE_V);
  RoundMode v87 = RoundMode::CAST_ROUND;
  SaturationMode v88 = SaturationMode::OFF;
  TCVT(v85, v81, v87, v88);
  // pto: %oq_i8__tile
  Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %oq_i8__tile
  uint64_t v90 = (uint64_t) v6;
  TASSIGN(v89, v90);
  pipe_barrier(PIPE_V);
  RoundMode v91 = RoundMode::CAST_TRUNC;
  SaturationMode v92 = SaturationMode::ON;
  TCVT(v89, v85, v91, v92);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %o_r_i8_pad__iter_v1_pview
  __gm__ int8_t* v93 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %o_r_i8_pad__iter_v1_pview
  const int64_t v94 = 0;
  // pto: %o_r_i8_pad__iter_v1_pview
  pto::Shape<1, 1, 1, 8, 1024> v95 = pto::Shape<1, 1, 1, 8, 1024>();
  // pto: %o_r_i8_pad__iter_v1_pview
  pto::Stride<65536, 65536, 65536, 8192, 1> v96 = pto::Stride<65536, 65536, 65536, 8192, 1>();
  // pto: %o_r_i8_pad__iter_v1_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v97 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v93 + (v94 + v44), v95, v96);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v97, v89);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %zero_half__tile
  Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %zero_half__tile
  uint64_t v99 = (uint64_t) v6;
  TASSIGN(v98, v99);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v98, v17);
  // pto: %zero_i8__tile
  Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v13);
  // pto: %zero_i8__tile
  uint64_t v101 = (uint64_t) v6;
  TASSIGN(v100, v101);
  pipe_barrier(PIPE_V);
  RoundMode v102 = RoundMode::CAST_TRUNC;
  SaturationMode v103 = SaturationMode::ON;
  TCVT(v100, v98, v102, v103);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  // pto: %o_r_i8_pad__tile_pview
  __gm__ int8_t* v104 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %o_r_i8_pad__tile_pview
  const int64_t v105 = 65536;
  // pto: %o_r_i8_pad__tile_pview
  pto::Shape<1, 1, 1, 8, 1024> v106 = pto::Shape<1, 1, 1, 8, 1024>();
  // pto: %o_r_i8_pad__tile_pview
  pto::Stride<65536, 65536, 65536, 8192, 1> v107 = pto::Stride<65536, 65536, 65536, 8192, 1>();
  // pto: %o_r_i8_pad__tile_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v108 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v104 + (v105 + v44), v106, v107);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  TSTORE(v108, v100);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}