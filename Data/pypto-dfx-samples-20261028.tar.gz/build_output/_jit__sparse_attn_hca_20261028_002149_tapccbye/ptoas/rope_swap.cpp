#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rope_swap(__gm__ int32_t* v1) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v2 = 0;
  // pto: %c4352_i64
  const int64_t v3 = 4352;
  // pto: %c4096_i64
  const int64_t v4 = 4096;
  // pto: %c16_index
  const int64_t v5 = 16;
  // pto: %c64_index
  const int64_t v6 = 64;
  // pto: %c1_index
  const int64_t v7 = 1;
  // pto: %cst_6
  const float v8 = 1.0f;
  // pto: %c192_index
  const int64_t v9 = 192;
  // pto: %c0_i32
  const int32_t v10 = 0;
  // pto: %cst_9
  const float v11 = 0.5f;
  // pto: %cst_10
  const float v12 = 2.0f;
  // pto: %rope_swap_idx__ssa_v0_view
  const int64_t v13 = 1;
  // pto: %rope_swap_idx__ssa_v0_view
  const int64_t v14 = 1;
  // pto: %rope_swap_idx__ssa_v0_view
  const int64_t v15 = 1;
  // pto: %rope_swap_idx__ssa_v0_view
  int64_t v16 = v5 * v6;
  // pto: %rope_swap_idx__ssa_v0_view
  int64_t v17 = v15 * v16;
  // pto: %rope_swap_idx__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v18 = pto::Shape<1, 1, 1, -1, -1>(v13, v14, v15, v5, v6);
  // pto: %rope_swap_idx__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v19 = pto::Stride<-1, -1, -1, -1, -1>(v14 * v17, v17, v16, v6, v7);
  // pto: %rope_swap_idx__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v20 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v18, v19);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v21 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %t__tile
  uint64_t v22 = (uint64_t) v2;
  TASSIGN(v21, v22);
  TEXPANDS(v21, v8);
  // pto: %t__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v7, v9);
  // pto: %t__ci_tmp_v0
  uint64_t v24 = (uint64_t) v3;
  TASSIGN(v23, v24);
  // pto: %0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v7, v6);
  // pto: %0
  uint64_t v26 = (uint64_t) v4;
  TASSIGN(v25, v26);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v27;
  TRESHAPE(v27, v23);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v28;
  TRESHAPE(v28, v25);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v28, v10, v27);
  // pto: %1
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v7, v6);
  // pto: %1
  uint64_t v30 = (uint64_t) v3;
  TASSIGN(v29, v30);
  pipe_barrier(PIPE_V);
  RoundMode v31 = RoundMode::CAST_ROUND;
  SaturationMode v32 = SaturationMode::OFF;
  TCVT(v29, v25, v31, v32);
  // pto: %sw_col__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %sw_col__tile
  uint64_t v34 = (uint64_t) v2;
  TASSIGN(v33, v34);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v33, v21, v29);
  // pto: %2
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %2
  uint64_t v36 = (uint64_t) v3;
  TASSIGN(v35, v36);
  pipe_barrier(PIPE_V);
  TMULS(v35, v33, v11);
  // pto: %3
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %3
  uint64_t v38 = (uint64_t) v3;
  TASSIGN(v37, v38);
  pipe_barrier(PIPE_V);
  RoundMode v39 = RoundMode::CAST_TRUNC;
  SaturationMode v40 = SaturationMode::ON;
  TCVT(v37, v35, v39, v40);
  // pto: %sw_dup_f__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %sw_dup_f__tile
  uint64_t v42 = (uint64_t) v3;
  TASSIGN(v41, v42);
  pipe_barrier(PIPE_V);
  RoundMode v43 = RoundMode::CAST_ROUND;
  SaturationMode v44 = SaturationMode::OFF;
  TCVT(v41, v37, v43, v44);
  // pto: %4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %4
  uint64_t v46 = (uint64_t) v3;
  TASSIGN(v45, v46);
  pipe_barrier(PIPE_V);
  TMULS(v45, v41, v12);
  // pto: %sw_lane__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %sw_lane__tile
  uint64_t v48 = (uint64_t) v3;
  TASSIGN(v47, v48);
  pipe_barrier(PIPE_V);
  TSUB(v47, v33, v45);
  // pto: %5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %5
  uint64_t v50 = (uint64_t) v2;
  TASSIGN(v49, v50);
  pipe_barrier(PIPE_V);
  TADDS(v49, v33, v8);
  // pto: %6
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %6
  uint64_t v52 = (uint64_t) v3;
  TASSIGN(v51, v52);
  TMULS(v51, v47, v12);
  // pto: %7
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %7
  uint64_t v54 = (uint64_t) v2;
  TASSIGN(v53, v54);
  pipe_barrier(PIPE_V);
  TSUB(v53, v49, v51);
  // pto: %8
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
  // pto: %8
  uint64_t v56 = (uint64_t) v2;
  TASSIGN(v55, v56);
  pipe_barrier(PIPE_V);
  RoundMode v57 = RoundMode::CAST_ROUND;
  SaturationMode v58 = SaturationMode::ON;
  TCVT(v55, v53, v57, v58);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %rope_swap_idx__ssa_v0_pview
  __gm__ int32_t* v59 = PTOAS__GLOBAL_TENSOR_DATA(v20);
  // pto: %rope_swap_idx__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 64> v60 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %rope_swap_idx__ssa_v0_pview
  pto::Stride<1024, 1024, 1024, 64, 1> v61 = pto::Stride<1024, 1024, 1024, 64, 1>();
  // pto: %rope_swap_idx__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v62 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v59, v60, v61);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v62, v55);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}