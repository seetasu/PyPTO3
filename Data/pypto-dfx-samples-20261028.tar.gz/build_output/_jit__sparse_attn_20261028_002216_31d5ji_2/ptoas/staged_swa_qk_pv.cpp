#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void staged_swa_qk_pv_aic(__gm__ float* v1, __gm__ float* v2, __gm__ half* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int32_t v16, int32_t v17) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v18 = 1024;
  const int32_t v19 = 0;
  const int64_t v20 = 240;
  const int64_t v21 = 160;
  const int64_t v22 = 80;
  // pto: %c65536_i64
  const int64_t v23 = 65536;
  // pto: %c196608_i64
  const int64_t v24 = 196608;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c0_i64
  const int64_t v26 = 0;
  // pto: %c8192_i64
  const int64_t v27 = 8192;
  // pto: %c1_index
  const int64_t v28 = 1;
  // pto: %c512_index
  const int64_t v29 = 512;
  // pto: %c8_index
  const int64_t v30 = 8;
  // pto: %c640_index
  const int64_t v31 = 640;
  // pto: %c6_index
  const int64_t v32 = 6;
  // pto: %c0_index
  const int64_t v33 = 0;
  // pto: %c320_index
  const int64_t v34 = 320;
  // pto: %c5_index
  const int64_t v35 = 5;
  // pto: %c128_index
  const int64_t v36 = 128;
  // pto: %c1_i32
  const int32_t v37 = 1;
  // pto: %c64_index
  const int64_t v38 = 64;
  // pto: %c32_index
  const int64_t v39 = 32;
  // pto: %c256_index
  const int64_t v40 = 256;
  // pto: %cn128_index
  const int64_t v41 = -128;
  // pto: %cn32_index
  const int64_t v42 = -32;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  int64_t v47 = (int64_t) v11;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  int64_t v48 = v47 * v29;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  int64_t v49 = v46 * v48;
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v50 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v47, v29);
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v49, v49, v48, v29, v28);
  // pto: %sparse_blk_oi_inline388__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v50, v51);
  // pto: %staged_kv_inline560__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %staged_kv_inline560__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %staged_kv_inline560__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %staged_kv_inline560__ssa_v0_view
  int64_t v56 = (int64_t) v14;
  // pto: %staged_kv_inline560__ssa_v0_view
  int64_t v57 = v56 * v29;
  // pto: %staged_kv_inline560__ssa_v0_view
  int64_t v58 = v55 * v57;
  // pto: %staged_kv_inline560__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v59 = pto::Shape<1, 1, 1, -1, -1>(v53, v54, v55, v56, v29);
  // pto: %staged_kv_inline560__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v54 * v58, v58, v57, v29, v28);
  // pto: %staged_kv_inline560__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v59, v60);
  // pto: %q_flat_inline567__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %q_flat_inline567__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %q_flat_inline567__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %q_flat_inline567__ssa_v0_view
  int64_t v65 = (int64_t) v15;
  // pto: %q_flat_inline567__ssa_v0_view
  int64_t v66 = v65 * v29;
  // pto: %q_flat_inline567__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %q_flat_inline567__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v29);
  // pto: %q_flat_inline567__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v29, v28);
  // pto: %q_flat_inline567__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v68, v69);
  auto v71 = TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>(v8, v19, v19);
  // pto: %t__tmp_v25, %25
  int64_t v72 = (int64_t) ((uint64_t) ((int64_t) v16) * (uint64_t) v32);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v73 = v33; v73 < v32; v73 += v28) {
    // pto: %26
    ;
    int64_t v74 = (int64_t) ((uint64_t) v72 + (uint64_t) v73);
    // pto: %27, %28, %29
    ;
    if (v74 < v9 & v74 < v10) {
      // pto: %30
      ;
      int64_t v75 = (int64_t) ((uint64_t) v74 * (uint64_t) v31);
      // pto: %31
      ;
      int64_t v76 = (int64_t) ((uint64_t) v74 * (uint64_t) v34);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v77 = v33; v77 < v35; v77 += v28) {
        // pto: %32
        ;
        int64_t v78 = (int64_t) ((uint64_t) v77 * (uint64_t) v36);
        // pto: %33
        ;
        int64_t v79 = (int64_t) ((uint64_t) v75 + (uint64_t) v78);
        // pto: %flat_offset_mul
        ;
        int64_t v80 = (int64_t) ((uint64_t) v74 * (uint64_t) v30);
        // pto: %flat_offset, %qk_block_valid_inline581__tile
        ;
        int32_t v81 = (v4)[(int64_t) ((uint64_t) v80 + (uint64_t) v77)];
        // pto: %34, %qk_block_valid_inline581__phi_v2
        ;
        int32_t v82 = v77 == v33 ? v37 : v81;
        // pto: %35, %36
        ;
        if ((int64_t) v82 > v33) {
          // pto: %qk_kv_k_inline583__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v29);
          // pto: %qk_kv_k_inline583__tile
          ;
          uint64_t v84 = (uint64_t) v23;
          TASSIGN(v83, v84);
          // pto: %37
          ;
          int64_t v85 = v79 < v33 ? v33 : v79;
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v86 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          const int64_t v87 = 0;
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          const int64_t v88 = 512;
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 128, 512> v89 = pto::Shape<1, 1, 1, 128, 512>();
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          pto::Stride<65536, 65536, 65536, 512, 1> v90 = pto::Stride<65536, 65536, 65536, 512, 1>();
          // pto: %staged_kv_inline560__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v91 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v86 + (v87 + v85 * v88), v89, v90);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          TLOAD(v83, v91);
          // pto: %qk_kv_v_inline584__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Mat, bfloat16_t, 128, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v29);
          // pto: %qk_kv_v_inline584__tile
          ;
          uint64_t v93 = (uint64_t) v24;
          TASSIGN(v92, v93);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v92, v91);
          // pto: %40
          ;
          int64_t v94 = (int64_t) ((uint64_t) v74 * (uint64_t) v38);
          // pto: %qk_q_tile_inline587__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
          // pto: %qk_q_tile_inline587__tile
          ;
          uint64_t v96 = (uint64_t) v25;
          TASSIGN(v95, v96);
          // pto: %41
          ;
          int64_t v97 = v94 < v33 ? v33 : v94;
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v98 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          const int64_t v99 = 0;
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          const int64_t v100 = 512;
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 512> v101 = pto::Shape<1, 1, 1, 32, 512>();
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          pto::Stride<16384, 16384, 16384, 512, 1> v102 = pto::Stride<16384, 16384, 16384, 512, 1>();
          // pto: %q_flat_inline567__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v103 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v98 + (v99 + v97 * v100), v101, v102);
          TLOAD(v95, v103);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %qk_kv_k_inline583__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v36);
          // pto: %qk_kv_k_inline583__tile_t
          ;
          uint64_t v105 = (uint64_t) v23;
          TASSIGN(v104, v105);
          // pto: %qk_raw_inline588__tile_l0_init
          ;
          Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v36);
          // pto: %qk_raw_inline588__tile_l0_init
          ;
          uint64_t v107 = (uint64_t) v26;
          TASSIGN(v106, v107);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v108 = v33; v108 < v29; v108 += v40) {
            // pto: %qk_raw_inline588__tile_l0_a
            ;
            Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v36);
            // pto: %qk_raw_inline588__tile_l0_a
            ;
            uint64_t v110 = (uint64_t) v26;
            TASSIGN(v109, v110);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            pipe_barrier(PIPE_MTE1);
            uint16_t v111 = static_cast<uint16_t>(v33);
            uint16_t v112 = static_cast<uint16_t>(v108);
            TEXTRACT(v109, v95, v111, v112);
            // pto: %qk_raw_inline588__tile_l0_b
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %qk_raw_inline588__tile_l0_b
            ;
            uint64_t v114 = (uint64_t) v26;
            TASSIGN(v113, v114);
            uint16_t v115 = static_cast<uint16_t>(v108);
            uint16_t v116 = static_cast<uint16_t>(v33);
            TEXTRACT(v113, v104, v115, v116);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %0
            ;
            Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v36);
            // pto: %0
            ;
            uint64_t v118 = (uint64_t) v27;
            TASSIGN(v117, v118);
            // pto: %42
            ;
            int64_t v119 = (int64_t) ((uint64_t) v108 + (uint64_t) v36);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            uint16_t v120 = static_cast<uint16_t>(v33);
            uint16_t v121 = static_cast<uint16_t>(v119);
            TEXTRACT(v117, v95, v120, v121);
            // pto: %1
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %1
            ;
            uint64_t v123 = (uint64_t) v25;
            TASSIGN(v122, v123);
            uint16_t v124 = static_cast<uint16_t>(v119);
            uint16_t v125 = static_cast<uint16_t>(v33);
            TEXTRACT(v122, v104, v124, v125);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            // pto: %44
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            if (v108 == v33) {
              pipe_barrier(PIPE_M);
              TMATMUL(v106, v109, v113);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v106, v106, v109, v113);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            // pto: %45
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            if (v108 == v41) {
              pipe_barrier(PIPE_M);
              TMATMUL(v106, v117, v122);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v106, v106, v117, v122);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v71, v106);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          // pto: %47
          ;
          int64_t v126 = (int64_t) ((uint64_t) v94 + (uint64_t) v39);
          // pto: %3
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Mat, bfloat16_t, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
          // pto: %3
          ;
          uint64_t v128 = (uint64_t) v25;
          TASSIGN(v127, v128);
          // pto: %48
          ;
          int64_t v129 = v126 < v33 ? v33 : v126;
          // pto: %49
          ;
          __gm__ bfloat16_t* v130 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %49
          ;
          const int64_t v131 = 0;
          // pto: %49
          ;
          const int64_t v132 = 512;
          // pto: %49
          ;
          pto::Shape<1, 1, 1, 32, 512> v133 = pto::Shape<1, 1, 1, 32, 512>();
          // pto: %49
          ;
          pto::Stride<16384, 16384, 16384, 512, 1> v134 = pto::Stride<16384, 16384, 16384, 512, 1>();
          // pto: %49
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v135 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 512>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v130 + (v131 + v129 * v132), v133, v134);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v127, v135);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %4
          ;
          Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Mat, bfloat16_t, 512, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v29, v36);
          // pto: %4
          ;
          uint64_t v137 = (uint64_t) v23;
          TASSIGN(v136, v137);
          // pto: %5
          ;
          Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v36);
          // pto: %5
          ;
          uint64_t v139 = (uint64_t) v26;
          TASSIGN(v138, v139);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
          for (int64_t v140 = v33; v140 < v29; v140 += v40) {
            // pto: %6
            ;
            Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v36);
            // pto: %6
            ;
            uint64_t v142 = (uint64_t) v26;
            TASSIGN(v141, v142);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            uint16_t v143 = static_cast<uint16_t>(v33);
            uint16_t v144 = static_cast<uint16_t>(v140);
            TEXTRACT(v141, v127, v143, v144);
            // pto: %7
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %7
            ;
            uint64_t v146 = (uint64_t) v26;
            TASSIGN(v145, v146);
            uint16_t v147 = static_cast<uint16_t>(v140);
            uint16_t v148 = static_cast<uint16_t>(v33);
            TEXTRACT(v145, v136, v147, v148);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
            // pto: %8
            ;
            Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Left, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v36);
            // pto: %8
            ;
            uint64_t v150 = (uint64_t) v27;
            TASSIGN(v149, v150);
            // pto: %51
            ;
            int64_t v151 = (int64_t) ((uint64_t) v140 + (uint64_t) v36);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v152 = static_cast<uint16_t>(v33);
            uint16_t v153 = static_cast<uint16_t>(v151);
            TEXTRACT(v149, v127, v152, v153);
            // pto: %9
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %9
            ;
            uint64_t v155 = (uint64_t) v25;
            TASSIGN(v154, v155);
            pipe_barrier(PIPE_MTE1);
            uint16_t v156 = static_cast<uint16_t>(v151);
            uint16_t v157 = static_cast<uint16_t>(v33);
            TEXTRACT(v154, v136, v156, v157);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            // pto: %53
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
            if (v140 == v33) {
              pipe_barrier(PIPE_M);
              TMATMUL(v138, v141, v145);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v138, v138, v141, v145);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            // pto: %54
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            if (v140 == v41) {
              pipe_barrier(PIPE_M);
              TMATMUL(v138, v149, v154);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v138, v138, v149, v154);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Acc, float, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v71, v138);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
          // pto: %qk_oi_inline595__tile_l0_init
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v29);
          // pto: %qk_oi_inline595__tile_l0_init
          ;
          uint64_t v159 = (uint64_t) v26;
          TASSIGN(v158, v159);
          // pto: %qk_oi_inline595__tile_l0_lmat
          ;
          const int32_t v160 = 32;
          // pto: %qk_oi_inline595__tile_l0_lmat
          ;
          const int32_t v161 = 128;
          // pto: %qk_oi_inline595__tile_l0_lmat
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v160, v161);
          pipe_barrier(PIPE_MTE2);
          TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v71, v162);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          for (int64_t v163 = v33; v163 < v36; v163 += v38) {
            // pto: %qk_oi_inline595__tile_l0_a
            ;
            Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
            // pto: %qk_oi_inline595__tile_l0_a
            ;
            uint64_t v165 = (uint64_t) v26;
            TASSIGN(v164, v165);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            uint16_t v166 = static_cast<uint16_t>(v33);
            uint16_t v167 = static_cast<uint16_t>(v163);
            TEXTRACT(v164, v162, v166, v167);
            // pto: %qk_oi_inline595__tile_l0_b
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
            // pto: %qk_oi_inline595__tile_l0_b
            ;
            uint64_t v169 = (uint64_t) v26;
            TASSIGN(v168, v169);
            uint16_t v170 = static_cast<uint16_t>(v163);
            uint16_t v171 = static_cast<uint16_t>(v33);
            TEXTRACT(v168, v92, v170, v171);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            // pto: %12
            ;
            Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
            // pto: %12
            ;
            uint64_t v173 = (uint64_t) v27;
            TASSIGN(v172, v173);
            // pto: %55
            ;
            int64_t v174 = (int64_t) ((uint64_t) v163 + (uint64_t) v39);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v175 = static_cast<uint16_t>(v33);
            uint16_t v176 = static_cast<uint16_t>(v174);
            TEXTRACT(v172, v162, v175, v176);
            // pto: %13
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
            // pto: %13
            ;
            uint64_t v178 = (uint64_t) v25;
            TASSIGN(v177, v178);
            pipe_barrier(PIPE_MTE1);
            uint16_t v179 = static_cast<uint16_t>(v174);
            uint16_t v180 = static_cast<uint16_t>(v33);
            TEXTRACT(v177, v92, v179, v180);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
            // pto: %57
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            if (v163 == v33) {
              pipe_barrier(PIPE_M);
              TMATMUL(v158, v164, v168);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v158, v158, v164, v168);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            // pto: %58
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
            if (v163 == v42) {
              pipe_barrier(PIPE_M);
              TMATMUL(v158, v172, v177);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v158, v158, v172, v177);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v71);
          // pto: %61
          ;
          int64_t v181 = (int64_t) ((uint64_t) v77 * (uint64_t) v43);
          // pto: %62
          ;
          int64_t v182 = (int64_t) ((uint64_t) v76 + (uint64_t) v181);
          // pto: %t__tile
          ;
          Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v43, v29);
          // pto: %t__tile
          ;
          uint64_t v184 = (uint64_t) v26;
          TASSIGN(v183, v184);
          // pto: %slice_view
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v185;
          // pto: %slice_view
          ;
          uint64_t v186 = (uint64_t) v26;
          TASSIGN(v185, v186);
          // pto: %63
          ;
          int64_t v187 = v182 < v33 ? v33 : v182;
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          __gm__ half* v188 = PTOAS__GLOBAL_TENSOR_DATA(v52);
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          const int64_t v189 = 0;
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          const int64_t v190 = 512;
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 16, 512> v191 = pto::Shape<1, 1, 1, 16, 512>();
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          pto::Stride<8192, 8192, 8192, 512, 1> v192 = pto::Stride<8192, 8192, 8192, 512, 1>();
          // pto: %sparse_blk_oi_inline388__iter_v3_pview
          ;
          GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v193 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v188 + (v189 + v187 * v190), v191, v192);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          pipe_barrier(PIPE_FIX);
          TSTORE(v193, v185);
          // pto: %65
          ;
          int64_t v194 = (int64_t) ((uint64_t) v76 + (uint64_t) v22);
          // pto: %67
          ;
          int64_t v195 = (int64_t) ((uint64_t) v194 + (uint64_t) v181);
          // pto: %15
          ;
          Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v43, v29);
          // pto: %15
          ;
          uint64_t v197 = (uint64_t) v25;
          TASSIGN(v196, v197);
          // pto: %68
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v198;
          // pto: %68
          ;
          uint64_t v199 = (uint64_t) v18;
          TASSIGN(v198, v199);
          // pto: %70
          ;
          int64_t v200 = v195 < v33 ? v33 : v195;
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          __gm__ half* v201 = PTOAS__GLOBAL_TENSOR_DATA(v52);
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          const int64_t v202 = 0;
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          const int64_t v203 = 512;
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          pto::Shape<1, 1, 1, 16, 512> v204 = pto::Shape<1, 1, 1, 16, 512>();
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          pto::Stride<8192, 8192, 8192, 512, 1> v205 = pto::Stride<8192, 8192, 8192, 512, 1>();
          // pto: %sparse_blk_oi_inline388__tile_pview
          ;
          GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v206 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v201 + (v202 + v200 * v203), v204, v205);
          pipe_barrier(PIPE_FIX);
          TSTORE(v206, v198);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          // pto: %16
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v39, v29);
          // pto: %16
          ;
          uint64_t v208 = (uint64_t) v26;
          TASSIGN(v207, v208);
          // pto: %71
          ;
          const int32_t v209 = 32;
          // pto: %71
          ;
          const int32_t v210 = 128;
          // pto: %71
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v209, v210);
          TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v71, v211);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v212 = v33; v212 < v36; v212 += v38) {
            // pto: %17
            ;
            Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
            // pto: %17
            ;
            uint64_t v214 = (uint64_t) v26;
            TASSIGN(v213, v214);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v215 = static_cast<uint16_t>(v33);
            uint16_t v216 = static_cast<uint16_t>(v212);
            TEXTRACT(v213, v211, v215, v216);
            // pto: %18
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
            // pto: %18
            ;
            uint64_t v218 = (uint64_t) v26;
            TASSIGN(v217, v218);
            uint16_t v219 = static_cast<uint16_t>(v212);
            uint16_t v220 = static_cast<uint16_t>(v33);
            TEXTRACT(v217, v92, v219, v220);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            // pto: %19
            ;
            Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Left, bfloat16_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
            // pto: %19
            ;
            uint64_t v222 = (uint64_t) v27;
            TASSIGN(v221, v222);
            // pto: %73
            ;
            int64_t v223 = (int64_t) ((uint64_t) v212 + (uint64_t) v39);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            uint16_t v224 = static_cast<uint16_t>(v33);
            uint16_t v225 = static_cast<uint16_t>(v223);
            TEXTRACT(v221, v211, v224, v225);
            // pto: %20
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v29);
            // pto: %20
            ;
            uint64_t v227 = (uint64_t) v25;
            TASSIGN(v226, v227);
            pipe_barrier(PIPE_MTE1);
            uint16_t v228 = static_cast<uint16_t>(v223);
            uint16_t v229 = static_cast<uint16_t>(v33);
            TEXTRACT(v226, v92, v228, v229);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            // pto: %75
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            if (v212 == v33) {
              pipe_barrier(PIPE_M);
              TMATMUL(v207, v213, v217);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v207, v207, v213, v217);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            // pto: %76
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            if (v212 == v42) {
              pipe_barrier(PIPE_M);
              TMATMUL(v207, v221, v226);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v207, v207, v221, v226);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v71);
          // pto: %78
          ;
          int64_t v230 = (int64_t) ((uint64_t) v76 + (uint64_t) v21);
          // pto: %80
          ;
          int64_t v231 = (int64_t) ((uint64_t) v230 + (uint64_t) v181);
          // pto: %23
          ;
          Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v43, v29);
          // pto: %23
          ;
          uint64_t v233 = (uint64_t) v26;
          TASSIGN(v232, v233);
          // pto: %81
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v234;
          // pto: %81
          ;
          uint64_t v235 = (uint64_t) v26;
          TASSIGN(v234, v235);
          // pto: %83
          ;
          int64_t v236 = v231 < v33 ? v33 : v231;
          // pto: %84
          ;
          __gm__ half* v237 = PTOAS__GLOBAL_TENSOR_DATA(v52);
          // pto: %84
          ;
          const int64_t v238 = 0;
          // pto: %84
          ;
          const int64_t v239 = 512;
          // pto: %84
          ;
          pto::Shape<1, 1, 1, 16, 512> v240 = pto::Shape<1, 1, 1, 16, 512>();
          // pto: %84
          ;
          pto::Stride<8192, 8192, 8192, 512, 1> v241 = pto::Stride<8192, 8192, 8192, 512, 1>();
          // pto: %84
          ;
          GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v242 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v237 + (v238 + v236 * v239), v240, v241);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
          pipe_barrier(PIPE_FIX);
          TSTORE(v242, v234);
          // pto: %86
          ;
          int64_t v243 = (int64_t) ((uint64_t) v76 + (uint64_t) v20);
          // pto: %88
          ;
          int64_t v244 = (int64_t) ((uint64_t) v243 + (uint64_t) v181);
          // pto: %24
          ;
          Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v43, v29);
          // pto: %24
          ;
          uint64_t v246 = (uint64_t) v25;
          TASSIGN(v245, v246);
          // pto: %89
          ;
          Tile<TileType::Acc, float, 32, 512, BLayout::ColMajor, 16, 512, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v247;
          // pto: %89
          ;
          uint64_t v248 = (uint64_t) v18;
          TASSIGN(v247, v248);
          // pto: %91
          ;
          int64_t v249 = v244 < v33 ? v33 : v244;
          // pto: %92
          ;
          __gm__ half* v250 = PTOAS__GLOBAL_TENSOR_DATA(v52);
          // pto: %92
          ;
          const int64_t v251 = 0;
          // pto: %92
          ;
          const int64_t v252 = 512;
          // pto: %92
          ;
          pto::Shape<1, 1, 1, 16, 512> v253 = pto::Shape<1, 1, 1, 16, 512>();
          // pto: %92
          ;
          pto::Stride<8192, 8192, 8192, 512, 1> v254 = pto::Stride<8192, 8192, 8192, 512, 1>();
          // pto: %92
          ;
          GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v255 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v250 + (v251 + v249 * v252), v253, v254);
          pipe_barrier(PIPE_FIX);
          TSTORE(v255, v247);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        };
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void staged_swa_qk_pv_aiv(__gm__ float* v1, __gm__ float* v2, __gm__ half* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int32_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 160;
  const int32_t v20 = 0;
  // pto: %c49408_i64
  const int64_t v21 = 49408;
  // pto: %c49920_i64
  const int64_t v22 = 49920;
  // pto: %c32768_i64
  const int64_t v23 = 32768;
  // pto: %c49152_i64
  const int64_t v24 = 49152;
  // pto: %c49280_i64
  const int64_t v25 = 49280;
  const int64_t v26 = 49216;
  const int64_t v27 = 49344;
  // pto: %c1_index
  const int64_t v28 = 1;
  // pto: %c8_index
  const int64_t v29 = 8;
  // pto: %c640_index
  const int64_t v30 = 640;
  // pto: %c0_index
  const int64_t v31 = 0;
  // pto: %c6_index
  const int64_t v32 = 6;
  // pto: %c320_index
  const int64_t v33 = 320;
  // pto: %c5_index
  const int64_t v34 = 5;
  // pto: %c128_index
  const int64_t v35 = 128;
  // pto: %c1_i32
  const int32_t v36 = 1;
  // pto: %c2_index
  const int64_t v37 = 2;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %cst_19
  const float v39 = 0.0441941731f;
  // pto: %c80_index
  const int64_t v40 = 80;
  // pto: %c16_index
  const int64_t v41 = 16;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  int64_t v45 = (int64_t) v11;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  int64_t v46 = v45 * v28;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  int64_t v47 = v44 * v46;
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v48 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v45, v28);
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v47, v47, v46, v28, (int64_t) v11);
  // pto: %sparse_blk_li_inline387__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v50 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v1, v48, v49);
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  int64_t v54 = (int64_t) v11;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  int64_t v55 = v54 * v28;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  int64_t v56 = v53 * v55;
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v51, v52, v53, v54, v28);
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v52 * v56, v56, v55, v28, (int64_t) v11);
  // pto: %sparse_blk_mi_inline386__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v57, v58);
  // pto: %staged_bias_inline561__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %staged_bias_inline561__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %staged_bias_inline561__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %staged_bias_inline561__ssa_v0_view
  int64_t v63 = (int64_t) v13;
  // pto: %staged_bias_inline561__ssa_v0_view
  int64_t v64 = v63 * v30;
  // pto: %staged_bias_inline561__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %staged_bias_inline561__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v30);
  // pto: %staged_bias_inline561__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v30, v28);
  // pto: %staged_bias_inline561__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v66, v67);
  auto v69 = TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>(v8, v20, v20);
  // pto: %subblock_idx, %19
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  if ((int64_t) v18 == v31) {
    // pto: %t__tmp_v25, %20
    ;
    int64_t v70 = (int64_t) ((uint64_t) ((int64_t) v16) * (uint64_t) v32);
    for (int64_t v71 = v31; v71 < v32; v71 += v28) {
      // pto: %21
      ;
      int64_t v72 = (int64_t) ((uint64_t) v70 + (uint64_t) v71);
      // pto: %22, %23, %24
      ;
      if (v72 < v9 & v72 < v10) {
        // pto: %25
        ;
        int64_t v73 = (int64_t) ((uint64_t) v72 * (uint64_t) v33);
        for (int64_t v74 = v31; v74 < v34; v74 += v28) {
          // pto: %26
          ;
          int64_t v75 = (int64_t) ((uint64_t) v74 * (uint64_t) v35);
          // pto: %flat_offset_mul
          ;
          int64_t v76 = (int64_t) ((uint64_t) v72 * (uint64_t) v29);
          // pto: %flat_offset, %qk_block_valid_inline581__tile
          ;
          int32_t v77 = (v4)[(int64_t) ((uint64_t) v76 + (uint64_t) v74)];
          // pto: %27, %qk_block_valid_inline581__phi_v2
          ;
          int32_t v78 = v74 == v31 ? v36 : v77;
          // pto: %28, %29
          ;
          if ((int64_t) v78 > v31) {
            // pto: %qk_bias_row_inline582__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v28, v35);
            // pto: %qk_bias_row_inline582__tile
            ;
            uint64_t v80 = (uint64_t) v21;
            TASSIGN(v79, v80);
            // pto: %30
            ;
            int64_t v81 = v72 < v31 ? v31 : v72;
            // pto: %31
            ;
            int64_t v82 = v75 < v31 ? v31 : v75;
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            __gm__ float* v83 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            const int64_t v84 = 0;
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            const int64_t v85 = 640;
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 128> v86 = pto::Shape<1, 1, 1, 1, 128>();
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            pto::Stride<640, 640, 640, 640, 1> v87 = pto::Stride<640, 640, 640, 640, 1>();
            // pto: %staged_bias_inline561__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND> v88 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND>(v83 + (v84 + v81 * v85 + v82), v86, v87);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            TLOAD(v79, v88);
            for (int64_t v89 = v31; v89 < v37; v89 += v28) {
              // pto: %qk_raw_inline588__tile_Vec
              ;
              const int32_t v90 = 32;
              // pto: %qk_raw_inline588__tile_Vec
              ;
              const int32_t v91 = 128;
              // pto: %qk_raw_inline588__tile_Vec
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v90, v91);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
              TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v69, v92);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              // pto: %qk_scaled_inline589__tile
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %qk_scaled_inline589__tile
              ;
              uint64_t v94 = (uint64_t) v22;
              TASSIGN(v93, v94);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
              TMULS(v93, v92, v39);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
              TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v69);
              // pto: %qk_scores_inline590__tile
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %qk_scores_inline590__tile
              ;
              uint64_t v96 = (uint64_t) v22;
              TASSIGN(v95, v96);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v95, v93, v79);
              // pto: %tmp_tile
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %tmp_tile
              ;
              uint64_t v98 = (uint64_t) v23;
              TASSIGN(v97, v98);
              // pto: %qk_mi_inline591__tile
              ;
              Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v28);
              // pto: %qk_mi_inline591__tile
              ;
              uint64_t v100 = (uint64_t) v24;
              TASSIGN(v99, v100);
              pipe_barrier(PIPE_V);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
              TROWMAX(v99, v95, v97);
              // pto: %t__tile
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %t__tile
              ;
              uint64_t v102 = (uint64_t) v22;
              TASSIGN(v101, v102);
              pipe_barrier(PIPE_V);
              TROWEXPANDSUB(v101, v95, v99);
              // pto: %qk_exp_inline592__tile
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %qk_exp_inline592__tile
              ;
              uint64_t v104 = (uint64_t) v22;
              TASSIGN(v103, v104);
              pipe_barrier(PIPE_V);
              TEXP(v103, v101);
              // pto: %0
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %0
              ;
              uint64_t v106 = (uint64_t) v23;
              TASSIGN(v105, v106);
              // pto: %qk_li_inline593__tile
              ;
              Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v28);
              // pto: %qk_li_inline593__tile
              ;
              uint64_t v108 = (uint64_t) v25;
              TASSIGN(v107, v108);
              pipe_barrier(PIPE_V);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
              TROWSUM(v107, v103, v105);
              // pto: %qk_exp_bf16_inline594__tile
              ;
              Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
              // pto: %qk_exp_bf16_inline594__tile
              ;
              uint64_t v110 = (uint64_t) v22;
              TASSIGN(v109, v110);
              pipe_barrier(PIPE_V);
              RoundMode v111 = RoundMode::CAST_RINT;
              SaturationMode v112 = SaturationMode::OFF;
              TCVT(v109, v103, v111, v112);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v69, v109);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
              // pto: %32
              ;
              int64_t v113 = (int64_t) ((uint64_t) v89 * (uint64_t) v37);
              int64_t v114 = (int64_t) ((uint64_t) v89 * (uint64_t) v19);
              // pto: %34
              ;
              int64_t v115 = (int64_t) ((uint64_t) v73 + (uint64_t) v114);
              // pto: %35
              ;
              int64_t v116 = (int64_t) ((uint64_t) v74 * (uint64_t) v41);
              // pto: %36
              ;
              int64_t v117 = (int64_t) ((uint64_t) v115 + (uint64_t) v116);
              // pto: %1
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v28);
              // pto: %1
              ;
              uint64_t v119 = (uint64_t) v24;
              TASSIGN(v118, v119);
              // pto: %slice_view
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120;
              // pto: %slice_view
              ;
              uint64_t v121 = (uint64_t) v24;
              TASSIGN(v120, v121);
              // pto: %37
              ;
              int64_t v122 = v117 < v31 ? v31 : v117;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              int64_t v123 = (int64_t) v11;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              const int64_t v124 = 0;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              __gm__ float* v125 = PTOAS__GLOBAL_TENSOR_DATA(v59);
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              const int64_t v126 = 1;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              const int64_t v127 = 1;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              const int64_t v128 = 1;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              int64_t v129 = v41 * v28;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              int64_t v130 = v128 * v129;
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              pto::Shape<1, 1, 1, 16, 1> v131 = pto::Shape<1, 1, 1, 16, 1>(v126, v127, v128, v41, v28);
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v132 = pto::Stride<-1, -1, -1, -1, -1>(v127 * v130, v130, v129, v28, v123);
              // pto: %sparse_blk_mi_inline386__iter_v5_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v133 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v125 + (v124 + v122 * v28 + v31 * v123), v131, v132);
              TSTORE(v133, v120);
              // pto: %2
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v28);
              // pto: %2
              ;
              uint64_t v135 = (uint64_t) v25;
              TASSIGN(v134, v135);
              // pto: %38
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136;
              // pto: %38
              ;
              uint64_t v137 = (uint64_t) v25;
              TASSIGN(v136, v137);
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              int64_t v138 = (int64_t) v11;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              const int64_t v139 = 0;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              __gm__ float* v140 = PTOAS__GLOBAL_TENSOR_DATA(v50);
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              const int64_t v141 = 1;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              const int64_t v142 = 1;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              const int64_t v143 = 1;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              int64_t v144 = v41 * v28;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              int64_t v145 = v143 * v144;
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              pto::Shape<1, 1, 1, 16, 1> v146 = pto::Shape<1, 1, 1, 16, 1>(v141, v142, v143, v41, v28);
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v145, v145, v144, v28, v138);
              // pto: %sparse_blk_li_inline387__iter_v5_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v140 + (v139 + v122 * v28 + v31 * v138), v146, v147);
              TSTORE(v148, v136);
              // pto: %41
              ;
              int64_t v149 = (int64_t) ((uint64_t) v113 + (uint64_t) v28);
              // pto: %42
              ;
              int64_t v150 = (int64_t) ((uint64_t) v149 * (uint64_t) v40);
              // pto: %43
              ;
              int64_t v151 = (int64_t) ((uint64_t) v73 + (uint64_t) v150);
              // pto: %45
              ;
              int64_t v152 = (int64_t) ((uint64_t) v151 + (uint64_t) v116);
              // pto: %3
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v28);
              // pto: %3
              ;
              uint64_t v154 = (uint64_t) v26;
              TASSIGN(v153, v154);
              // pto: %46
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155;
              // pto: %46
              ;
              uint64_t v156 = (uint64_t) v26;
              TASSIGN(v155, v156);
              // pto: %48
              ;
              int64_t v157 = v152 < v31 ? v31 : v152;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              int64_t v158 = (int64_t) v11;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              const int64_t v159 = 0;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              __gm__ float* v160 = PTOAS__GLOBAL_TENSOR_DATA(v59);
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              const int64_t v161 = 1;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              const int64_t v162 = 1;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              const int64_t v163 = 1;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              int64_t v164 = v41 * v28;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              int64_t v165 = v163 * v164;
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              pto::Shape<1, 1, 1, 16, 1> v166 = pto::Shape<1, 1, 1, 16, 1>(v161, v162, v163, v41, v28);
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v167 = pto::Stride<-1, -1, -1, -1, -1>(v162 * v165, v165, v164, v28, v158);
              // pto: %sparse_blk_mi_inline386__tile_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v168 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v160 + (v159 + v157 * v28 + v31 * v158), v166, v167);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v168, v155);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
              // pto: %4
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v41, v28);
              // pto: %4
              ;
              uint64_t v170 = (uint64_t) v27;
              TASSIGN(v169, v170);
              // pto: %49
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, 16, 1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171;
              // pto: %49
              ;
              uint64_t v172 = (uint64_t) v27;
              TASSIGN(v171, v172);
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              int64_t v173 = (int64_t) v11;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              const int64_t v174 = 0;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              __gm__ float* v175 = PTOAS__GLOBAL_TENSOR_DATA(v50);
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              const int64_t v176 = 1;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              const int64_t v177 = 1;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              const int64_t v178 = 1;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              int64_t v179 = v41 * v28;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              int64_t v180 = v178 * v179;
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              pto::Shape<1, 1, 1, 16, 1> v181 = pto::Shape<1, 1, 1, 16, 1>(v176, v177, v178, v41, v28);
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v28, v173);
              // pto: %sparse_blk_li_inline387__tile_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v183 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v175 + (v174 + v157 * v28 + v31 * v173), v181, v182);
              TSTORE(v183, v171);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          };
        };
      };
    };
  } else {
    // pto: %52, %53
    ;
    int64_t v184 = (int64_t) ((uint64_t) ((int64_t) v16) * (uint64_t) v32);
    for (int64_t v185 = v31; v185 < v32; v185 += v28) {
      // pto: %55
      ;
      int64_t v186 = (int64_t) ((uint64_t) v184 + (uint64_t) v185);
      // pto: %56, %57, %58
      ;
      if (v186 < v9 & v186 < v10) {
        for (int64_t v187 = v31; v187 < v34; v187 += v28) {
          // pto: %61
          ;
          int64_t v188 = (int64_t) ((uint64_t) v186 * (uint64_t) v29);
          // pto: %62, %60
          ;
          int32_t v189 = (v4)[(int64_t) ((uint64_t) v188 + (uint64_t) v187)];
          // pto: %63, %64
          ;
          int32_t v190 = v187 == v31 ? v36 : v189;
          // pto: %65, %66
          ;
          if ((int64_t) v190 > v31) {
            // pto: %5
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
            // pto: %5
            ;
            uint64_t v192 = (uint64_t) v21;
            TASSIGN(v191, v192);
            for (int64_t v193 = v31; v193 < v37; v193 += v28) {
              // pto: %68
              ;
              const int32_t v194 = 32;
              // pto: %68
              ;
              const int32_t v195 = 128;
              // pto: %68
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v194, v195);
              v196.SetValidShape(v31, v31);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              TPOP<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v69, v196);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              // pto: %6
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %6
              ;
              uint64_t v198 = (uint64_t) v22;
              TASSIGN(v197, v198);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
              TMULS(v197, v196, v39);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              TFREE<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, TileSplitAxis::TILE_NO_SPLIT>(v69);
              // pto: %7
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %7
              ;
              uint64_t v200 = (uint64_t) v22;
              TASSIGN(v199, v200);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v199, v197, v191);
              // pto: %8
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %8
              ;
              uint64_t v202 = (uint64_t) v23;
              TASSIGN(v201, v202);
              // pto: %9
              ;
              Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %9
              ;
              uint64_t v204 = (uint64_t) v24;
              TASSIGN(v203, v204);
              pipe_barrier(PIPE_V);
              TROWMAX(v203, v199, v201);
              // pto: %10
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %10
              ;
              uint64_t v206 = (uint64_t) v22;
              TASSIGN(v205, v206);
              pipe_barrier(PIPE_V);
              TROWEXPANDSUB(v205, v199, v203);
              // pto: %11
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %11
              ;
              uint64_t v208 = (uint64_t) v22;
              TASSIGN(v207, v208);
              pipe_barrier(PIPE_V);
              TEXP(v207, v205);
              // pto: %12
              ;
              Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %12
              ;
              uint64_t v210 = (uint64_t) v23;
              TASSIGN(v209, v210);
              // pto: %13
              ;
              Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %13
              ;
              uint64_t v212 = (uint64_t) v24;
              TASSIGN(v211, v212);
              pipe_barrier(PIPE_V);
              TROWSUM(v211, v207, v209);
              // pto: %14
              ;
              Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %14
              ;
              uint64_t v214 = (uint64_t) v22;
              TASSIGN(v213, v214);
              pipe_barrier(PIPE_V);
              RoundMode v215 = RoundMode::CAST_RINT;
              SaturationMode v216 = SaturationMode::OFF;
              TCVT(v213, v207, v215, v216);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              TPUSH<TPipe<0, Direction::DIR_BOTH, 16384, 2, 2, true>, Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_NO_SPLIT>(v69, v213);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
              // pto: %15
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %15
              ;
              uint64_t v218 = (uint64_t) v22;
              TASSIGN(v217, v218);
              // pto: %16
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %16
              ;
              uint64_t v220 = (uint64_t) v22;
              TASSIGN(v219, v220);
              // pto: %17
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %17
              ;
              uint64_t v222 = (uint64_t) v22;
              TASSIGN(v221, v222);
              // pto: %18
              ;
              Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v31);
              // pto: %18
              ;
              uint64_t v224 = (uint64_t) v22;
              TASSIGN(v223, v224);
            };
          };
        };
      };
    };
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}