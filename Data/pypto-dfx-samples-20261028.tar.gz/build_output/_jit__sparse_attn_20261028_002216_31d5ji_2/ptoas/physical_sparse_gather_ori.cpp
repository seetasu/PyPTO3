#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void physical_sparse_gather_ori(__gm__ int32_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c131072_i64
  const int64_t v12 = 131072;
  // pto: %c128_index
  const int64_t v13 = 128;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %c4_index
  const int64_t v16 = 4;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c640_index
  const int64_t v18 = 640;
  // pto: %c127_index
  const int64_t v19 = 127;
  // pto: %c0_i32
  const int32_t v20 = 0;
  // pto: %c1_i32
  const int32_t v21 = 1;
  // pto: %swa_indices__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %swa_indices__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %swa_indices__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %swa_indices__ssa_v0_view
  int64_t v25 = (int64_t) v6;
  // pto: %swa_indices__ssa_v0_view
  int64_t v26 = v25 * v13;
  // pto: %swa_indices__ssa_v0_view
  int64_t v27 = v24 * v26;
  // pto: %swa_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v25, v13);
  // pto: %swa_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v27, v27, v26, v13, v14);
  // pto: %swa_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %10
  int64_t v31 = (int64_t) ((uint64_t) v7 * (uint64_t) v13);
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  int64_t v35 = v31 * v15;
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v31, v15);
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v15, v14);
  // pto: %ori_kv_flat_inline435__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v37, v38);
  // pto: %source_view_inline433__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %source_view_inline433__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %source_view_inline433__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %source_view_inline433__ssa_v0_view
  int64_t v43 = (int64_t) v8;
  // pto: %source_view_inline433__ssa_v0_view
  int64_t v44 = v43 * v15;
  // pto: %source_view_inline433__ssa_v0_view
  int64_t v45 = v42 * v44;
  // pto: %source_view_inline433__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v43, v15);
  // pto: %source_view_inline433__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v45, v45, v44, v15, v14);
  // pto: %source_view_inline433__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %0
  int64_t v49 = (int64_t) ((uint64_t) v4 - (uint64_t) v14);
  // pto: %1, %gather_schedule_block_inline446__ssa_v0
  int64_t v50 = (int64_t) ((uint64_t) v49 - (uint64_t) ((int64_t) v9));
  // pto: %2
  int64_t v51 = (int64_t) ((uint64_t) v50 * (uint64_t) v16);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  for (int64_t v52 = v17; v52 < v16; v52 += v14) {
    // pto: %3
    ;
    int64_t v53 = (int64_t) ((uint64_t) v51 + (uint64_t) v52);
    // pto: %4
    ;
    if (v53 < v5) {
      // pto: %5
      ;
      int64_t v54 = (int64_t) ((uint64_t) v53 * (uint64_t) v18);
      // pto: %flat_offset_mul
      ;
      int64_t v55 = (int64_t) ((uint64_t) v53 * (uint64_t) v13);
      // pto: %flat_offset, %t__tile
      ;
      int32_t v56 = (v1)[(int64_t) ((uint64_t) v55 + (uint64_t) v19)];
      // pto: %6
      ;
      int32_t v57 = v56 < v20 ? v20 : v56;
      // pto: %gather_idx_inline454__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %gather_idx_inline454__ssa_v0
      ;
      uint64_t v59 = (uint64_t) v11;
      TASSIGN(v58, v59);
      // pto: %7
      ;
      int64_t v60 = v53 < v17 ? v17 : v53;
      // pto: %swa_indices__ssa_v0_pview
      ;
      __gm__ int32_t* v61 = PTOAS__GLOBAL_TENSOR_DATA(v30);
      // pto: %swa_indices__ssa_v0_pview
      ;
      const int64_t v62 = 0;
      // pto: %swa_indices__ssa_v0_pview
      ;
      const int64_t v63 = 128;
      // pto: %swa_indices__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v64 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %swa_indices__ssa_v0_pview
      ;
      pto::Stride<128, 128, 128, 128, 1> v65 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %swa_indices__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v66 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v61 + (v62 + v60 * v63), v64, v65);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v58, v66);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %t__tmp_v12
      ;
      uint64_t v68 = (uint64_t) v12;
      TASSIGN(v67, v68);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TADDS(v67, v58, v21);
      // pto: %t__tmp_v13
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %t__tmp_v13
      ;
      uint64_t v70 = (uint64_t) v12;
      TASSIGN(v69, v70);
      pipe_barrier(PIPE_V);
      TMAXS(v69, v67, v20);
      // pto: %gather_flag_inline455__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %gather_flag_inline455__ssa_v0
      ;
      uint64_t v72 = (uint64_t) v12;
      TASSIGN(v71, v72);
      pipe_barrier(PIPE_V);
      TMINS(v71, v69, v21);
      // pto: %t__tmp_v14
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %t__tmp_v14
      ;
      uint64_t v74 = (uint64_t) v11;
      TASSIGN(v73, v74);
      TSUBS(v73, v58, v57);
      // pto: %t__tmp_v15
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %t__tmp_v15
      ;
      uint64_t v76 = (uint64_t) v11;
      TASSIGN(v75, v76);
      pipe_barrier(PIPE_V);
      TMUL(v75, v71, v73);
      // pto: %gather_fix_inline456__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
      // pto: %gather_fix_inline456__ssa_v0
      ;
      uint64_t v78 = (uint64_t) v12;
      TASSIGN(v77, v78);
      pipe_barrier(PIPE_V);
      TADDS(v77, v75, v57);
      set_flag(PIPE_V, PIPE_S, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %ori_stage_inline457__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 128, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, bfloat16_t, 128, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v15);
      // pto: %ori_stage_inline457__ssa_v0
      ;
      uint64_t v80 = (uint64_t) v11;
      TASSIGN(v79, v80);
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      const int64_t v81 = 0;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v82 = PTOAS__GLOBAL_TENSOR_DATA(v39);
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      const int64_t v83 = 1;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      const int64_t v84 = 1;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      const int64_t v85 = 1;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      int64_t v86 = v31 * v15;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      int64_t v87 = v85 * v86;
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 512> v88 = pto::Shape<1, 1, 1, -1, 512>(v83, v84, v85, v31, v15);
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v15, v14);
      // pto: %ori_kv_flat_inline435__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v82 + (v81 + v17 * v15 + v17 * v14), v88, v89);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      MGATHER<pto::Coalesce::Row>(v79, v90, v77);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %9
      ;
      int64_t v91 = v54 < v17 ? v17 : v54;
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v92 = PTOAS__GLOBAL_TENSOR_DATA(v48);
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      const int64_t v93 = 0;
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      const int64_t v94 = 512;
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 512> v95 = pto::Shape<1, 1, 1, 128, 512>();
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 512, 1> v96 = pto::Stride<65536, 65536, 65536, 512, 1>();
      // pto: %source_view_inline433__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v92 + (v93 + v91 * v94), v95, v96);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v97, v79);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}