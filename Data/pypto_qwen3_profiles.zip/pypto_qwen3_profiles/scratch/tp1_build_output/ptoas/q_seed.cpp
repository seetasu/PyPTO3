#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void q_seed(__gm__ float* v1) {
  const float v2 = 0.0f;
  const int64_t v3 = 512;
  const int64_t v4 = 2;
  const int64_t v5 = 10;
  const int64_t v6 = 16;
  const int64_t v7 = 32768;
  const int64_t v8 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t i9 = v8; i9 < v5; i9 += v4) {
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v10 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v6, v3);
    // pto: %t__tile
    uint64_t v11 = (uint64_t) v8;
    TASSIGN(v10, v11);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v10, v2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %1
    int64_t v12 = (int64_t) ((uint64_t) i9 * (uint64_t) v3);
    // pto: %q_proj_inline1340__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 512> v13 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %q_proj_inline1340__iter_v1_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v14 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %2, %q_proj_inline1340__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v15 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v8 + (v12 < v8 ? v8 : v12)), v13, v14);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v15, v10);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v16 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v6, v3);
    // pto: %0
    uint64_t v17 = (uint64_t) v7;
    TASSIGN(v16, v17);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v16, v2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %5
    int64_t v18 = (int64_t) ((uint64_t) v12 + (uint64_t) v3);
    // pto: %q_proj_inline1340__tile_pview
    pto::Shape<1, 1, 1, 16, 512> v19 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %q_proj_inline1340__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v20 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %6, %q_proj_inline1340__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v21 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v8 + (v18 < v8 ? v8 : v18)), v19, v20);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v21, v16);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}