#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void out_proj_aic_0(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  unsigned v8 = 4864;
  const int64_t v9 = 5120;
  const int64_t v10 = 4864;
  const int64_t v11 = 2;
  const int64_t v12 = 19;
  const int64_t v13 = 128;
  const int64_t v14 = 256;
  const int64_t v15 = 20;
  const int64_t v16 = 1;
  const int64_t v17 = 64;
  const int64_t v18 = 8192;
  const int64_t v19 = 32768;
  const int64_t v20 = 24576;
  const int64_t v21 = 16384;
  const int64_t v22 = 0;
  const int64_t v23 = 196608;
  const int64_t v24 = 65536;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %o_acc_inline465__tile_l0_c_phi
  Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %o_acc_inline465__tile_l0_c_phi
  uint64_t v26 = (uint64_t) v22;
  TASSIGN(v25, v26);
  // pto: %out_core_inline467__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i27 = (int64_t) v6; i27 < v15; i27 += v15) {
    // pto: %25
    int64_t v28 = (int64_t) ((uint64_t) i27 * (uint64_t) v14);
    // pto: %tile_a_inline536__tile
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %tile_a_inline536__tile
    uint64_t v30 = (uint64_t) v24;
    TASSIGN(v29, v30);
    // pto: %attn_tile_inline594__rv_v2_pview
    pto::Shape<1, 1, 1, 64, 256> v31 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %attn_tile_inline594__rv_v2_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v32 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %attn_tile_inline594__rv_v2_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v33 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2, v31, v32);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v29, v33);
    // pto: %tile_w_inline497__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %tile_w_inline497__tile
    uint64_t v35 = (uint64_t) v23;
    TASSIGN(v34, v35);
    // pto: %27
    int64_t v36 = v28 < v22 ? v22 : v28;
    // pto: %wo__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v37 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wo__ssa_v0_pview
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v38 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %26, %wo__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v39 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v4 < v22 ? v22 : v4) * v9) + v36), v37, v38);
    TLOAD(v34, v39);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %o_acc_inline465__tile_l0_init
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %o_acc_inline465__tile_l0_init
    uint64_t v41 = (uint64_t) v22;
    TASSIGN(v40, v41);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j42 = v22; j42 < v14; j42 += v13) {
      // pto: %o_acc_inline465__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
      // pto: %o_acc_inline465__tile_l0_a
      uint64_t v44 = (uint64_t) v21;
      TASSIGN(v43, v44);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v43, v29, v22, j42);
      // pto: %o_acc_inline465__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %o_acc_inline465__tile_l0_b
      uint64_t v46 = (uint64_t) v22;
      TASSIGN(v45, v46);
      TEXTRACT(v45, v34, j42, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
      // pto: %0
      uint64_t v48 = (uint64_t) v20;
      TASSIGN(v47, v48);
      // pto: %28
      int64_t v49 = (int64_t) ((uint64_t) j42 + (uint64_t) v17);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v47, v29, v22, v49);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %1
      uint64_t v51 = (uint64_t) v19;
      TASSIGN(v50, v51);
      TEXTRACT(v50, v34, v49, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %30
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j42 == v22) {
        // pto: %o_acc_inline465__tile_l0_c_first
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %o_acc_inline465__tile_l0_c_first
        uint64_t v53 = (uint64_t) v22;
        TASSIGN(v52, v53);
        pipe_barrier(PIPE_M);
        TMATMUL(v52, v43, v45);
      } else {
        // pto: %o_acc_inline465__tile_l0_c_acc
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %o_acc_inline465__tile_l0_c_acc
        uint64_t v55 = (uint64_t) v22;
        TASSIGN(v54, v55);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v54, v54, v43, v45);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %2
      uint64_t v57 = (uint64_t) v22;
      TASSIGN(v56, v57);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v56, v56, v47, v50);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j58 = v16; j58 < v12; j58 += v11) {
      // pto: %31
      int64_t v59 = (int64_t) ((uint64_t) j58 * (uint64_t) v14);
      // pto: %33
      int64_t v60 = (int64_t) ((uint64_t) v59 + (uint64_t) v14);
      // pto: %tile_a_i_inline569__tile
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %tile_a_i_inline569__tile
      uint64_t v62 = (uint64_t) v22;
      TASSIGN(v61, v62);
      // pto: %35
      pto::Shape<1, 1, 1, 64, 256> v63 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %35
      pto::Stride<327680, 327680, 327680, 5120, 1> v64 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %34, %35
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v59 < v22 ? v22 : v59)), v63, v64);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v61, v65);
      // pto: %tile_w_i_inline573__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %tile_w_i_inline573__tile
      uint64_t v67 = (uint64_t) v23;
      TASSIGN(v66, v67);
      // pto: %36
      int64_t v68 = (int64_t) ((uint64_t) v4 + (uint64_t) v59);
      // pto: %39
      pto::Shape<1, 1, 1, 256, 256> v69 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %39
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v70 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %37, %39
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v71 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v68 < v22 ? v22 : v68) * v9) + v36), v69, v70);
      TLOAD(v66, v71);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %3
      uint64_t v73 = (uint64_t) v19;
      TASSIGN(v72, v73);
      // pto: %41
      pto::Shape<1, 1, 1, 64, 256> v74 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %41
      pto::Stride<327680, 327680, 327680, 5120, 1> v75 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %40, %41
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v76 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v60 < v22 ? v22 : v60)), v74, v75);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v72, v76);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %4
      uint64_t v78 = (uint64_t) v24;
      TASSIGN(v77, v78);
      // pto: %42
      int64_t v79 = (int64_t) ((uint64_t) v4 + (uint64_t) v60);
      // pto: %45
      pto::Shape<1, 1, 1, 256, 256> v80 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %45
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v81 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %43, %45
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v79 < v22 ? v22 : v79) * v9) + v36), v80, v81);
      TLOAD(v77, v82);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k83 = v22; k83 < v14; k83 += v13) {
        // pto: %5
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
        // pto: %5
        uint64_t v85 = (uint64_t) v21;
        TASSIGN(v84, v85);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v84, v61, v22, k83);
        // pto: %6
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %6
        uint64_t v87 = (uint64_t) v22;
        TASSIGN(v86, v87);
        TEXTRACT(v86, v66, k83, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %7
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
        // pto: %7
        uint64_t v89 = (uint64_t) v20;
        TASSIGN(v88, v89);
        // pto: %47
        int64_t v90 = (int64_t) ((uint64_t) k83 + (uint64_t) v17);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v88, v61, v22, v90);
        // pto: %8
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %8
        uint64_t v92 = (uint64_t) v19;
        TASSIGN(v91, v92);
        TEXTRACT(v91, v66, v90, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %9
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %9
        uint64_t v94 = (uint64_t) v22;
        TASSIGN(v93, v94);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v93, v93, v84, v86);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %10
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %10
        uint64_t v96 = (uint64_t) v22;
        TASSIGN(v95, v96);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v95, v95, v88, v91);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k97 = v22; k97 < v14; k97 += v13) {
        // pto: %11
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
        // pto: %11
        uint64_t v99 = (uint64_t) v22;
        TASSIGN(v98, v99);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v98, v72, v22, k97);
        // pto: %12
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %12
        uint64_t v101 = (uint64_t) v22;
        TASSIGN(v100, v101);
        TEXTRACT(v100, v77, k97, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %13
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
        // pto: %13
        uint64_t v103 = (uint64_t) v18;
        TASSIGN(v102, v103);
        // pto: %50
        int64_t v104 = (int64_t) ((uint64_t) k97 + (uint64_t) v17);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v102, v72, v22, v104);
        // pto: %14
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %14
        uint64_t v106 = (uint64_t) v19;
        TASSIGN(v105, v106);
        TEXTRACT(v105, v77, v104, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %15
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %15
        uint64_t v108 = (uint64_t) v22;
        TASSIGN(v107, v108);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v107, v107, v98, v100);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %16
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %16
        uint64_t v110 = (uint64_t) v22;
        TASSIGN(v109, v110);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v109, v109, v102, v105);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %17
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %17
    uint64_t v112 = (uint64_t) v24;
    TASSIGN(v111, v112);
    // pto: %53
    pto::Shape<1, 1, 1, 64, 256> v113 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %53
    pto::Stride<327680, 327680, 327680, 5120, 1> v114 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %53
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + v8, v113, v114);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v111, v115);
    // pto: %18
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %18
    uint64_t v117 = (uint64_t) v23;
    TASSIGN(v116, v117);
    // pto: %54
    int64_t v118 = (int64_t) ((uint64_t) v4 + (uint64_t) v10);
    // pto: %57
    pto::Shape<1, 1, 1, 256, 256> v119 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %57
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v120 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %55, %57
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v118 < v22 ? v22 : v118) * v9) + v36), v119, v120);
    TLOAD(v116, v121);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j122 = v22; j122 < v14; j122 += v13) {
      // pto: %19
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
      // pto: %19
      uint64_t v124 = (uint64_t) v21;
      TASSIGN(v123, v124);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v123, v111, v22, j122);
      // pto: %20
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %20
      uint64_t v126 = (uint64_t) v22;
      TASSIGN(v125, v126);
      TEXTRACT(v125, v116, j122, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %21
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v17);
      // pto: %21
      uint64_t v128 = (uint64_t) v20;
      TASSIGN(v127, v128);
      // pto: %59
      int64_t v129 = (int64_t) ((uint64_t) j122 + (uint64_t) v17);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v127, v111, v22, v129);
      // pto: %22
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %22
      uint64_t v131 = (uint64_t) v19;
      TASSIGN(v130, v131);
      TEXTRACT(v130, v116, v129, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %23
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %23
      uint64_t v133 = (uint64_t) v22;
      TASSIGN(v132, v133);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v132, v132, v123, v125);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %24
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %24
      uint64_t v135 = (uint64_t) v22;
      TASSIGN(v134, v135);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v134, v134, v127, v130);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %o_acc_inline465__rv_v2
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %o_acc_inline465__rv_v2
    uint64_t v137 = (uint64_t) v22;
    TASSIGN(v136, v137);
    // pto: %out_proj_tile_inline469__iter_v1_pview
    pto::Shape<1, 1, 1, 64, 256> v138 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %out_proj_tile_inline469__iter_v1_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v139 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %out_proj_tile_inline469__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v1 + (v22 + v36), v138, v139);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v140, v136);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}