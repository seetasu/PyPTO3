#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void attn_out_seed(__gm__ bfloat16_t* v1, int32_t v2) {
  const bfloat16_t v3 = 0.0f;
  const int64_t v4 = 1;
  const int64_t v5 = 5120;
  const int64_t v6 = 16;
  const int64_t v7 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t i8 = v7; i8 < v6; i8 += v4) {
    // pto: %0, %1
    if ((int64_t) v2 <= i8) {
      // pto: %t__tile
      Tile<TileType::Vec, bfloat16_t, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v9 = Tile<TileType::Vec, bfloat16_t, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v4, v5);
      // pto: %t__tile
      uint64_t v10 = (uint64_t) v7;
      TASSIGN(v9, v10);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v9, v3);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %attn_out_inline1234__iter_v1_pview
      pto::Shape<1, 1, 1, 1, 5120> v11 = pto::Shape<1, 1, 1, 1, 5120>();
      // pto: %attn_out_inline1234__iter_v1_pview
      pto::Stride<5120, 5120, 5120, 5120, 1> v12 = pto::Stride<5120, 5120, 5120, 5120, 1>();
      // pto: %2, %attn_out_inline1234__iter_v1_pview
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 5120>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v13 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 5120>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v1 + (v7 + (i8 < v7 ? v7 : i8) * v5), v11, v12);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v13, v9);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    }
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}