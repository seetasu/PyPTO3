#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void lm_head(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  const int64_t v9 = 4608;
  unsigned v10 = 4608;
  const int64_t v11 = 5120;
  const int64_t v12 = 2;
  const int64_t v13 = 9;
  const int64_t v14 = 64;
  const int64_t v15 = 128;
  const int64_t v16 = 512;
  const int64_t v17 = 192;
  const int64_t v18 = 24;
  const int64_t v19 = 792;
  const int64_t v20 = 16;
  const int64_t v21 = 1;
  const int64_t v22 = 152064;
  const int64_t v23 = 2048;
  const int64_t v24 = 16384;
  const int64_t v25 = 24576;
  const int64_t v26 = 6144;
  const int64_t v27 = 4096;
  const int64_t v28 = 0;
  const int64_t v29 = 229376;
  const int64_t v30 = 212992;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %out__iter_v1_view
  int64_t v31 = v6 * v22;
  // pto: %out__iter_v1_view
  int64_t v32 = v21 * v31;
  // pto: %out__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v21, v21, v21, v6, v22);
  // pto: %out__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v21 * v32, v32, v31, v22, v21);
  // pto: %out__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v33, v34);
  // pto: %lm_acc_inline1418__tile_l0_c_phi
  Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
  // pto: %lm_acc_inline1418__tile_l0_c_phi
  uint64_t v37 = (uint64_t) v28;
  TASSIGN(v36, v37);
  // pto: %lm_core_inline1438__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i38 = (int64_t) v7; i38 < v19; i38 += v18) {
    // pto: %30
    int64_t v39 = (int64_t) ((uint64_t) i38 * (uint64_t) v17);
    // pto: %lm_hidden_chunk_inline1433__tile
    Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %lm_hidden_chunk_inline1433__tile
    uint64_t v41 = (uint64_t) v30;
    TASSIGN(v40, v41);
    // pto: %final_normed_inline1422__rv_v2_pview
    pto::Shape<1, 1, 1, 16, 512> v42 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %final_normed_inline1422__rv_v2_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v43 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %final_normed_inline1422__rv_v2_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v44 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2, v42, v43);
    TLOAD(v40, v44);
    // pto: %lm_weight_chunk_inline1419__tile
    Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v16);
    // pto: %lm_weight_chunk_inline1419__tile
    uint64_t v46 = (uint64_t) v29;
    TASSIGN(v45, v46);
    // pto: %31
    int64_t v47 = v39 < v28 ? v28 : v39;
    // pto: %lm_head_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 192, 512> v48 = pto::Shape<1, 1, 1, 192, 512>();
    // pto: %lm_head_weight__ssa_v0_pview
    pto::Stride<983040, 983040, 983040, 5120, 1> v49 = pto::Stride<983040, 983040, 983040, 5120, 1>();
    // pto: %lm_head_weight__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND> v50 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND>(v3 + (v28 + v47 * v11), v48, v49);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v45, v50);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %lm_weight_chunk_inline1419__tile_t
    Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v17);
    // pto: %lm_weight_chunk_inline1419__tile_t
    uint64_t v52 = (uint64_t) v29;
    TASSIGN(v51, v52);
    // pto: %lm_acc_inline1418__tile_l0_init
    Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
    // pto: %lm_acc_inline1418__tile_l0_init
    uint64_t v54 = (uint64_t) v28;
    TASSIGN(v53, v54);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j55 = v28; j55 < v16; j55 += v15) {
      // pto: %lm_acc_inline1418__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
      // pto: %lm_acc_inline1418__tile_l0_a
      uint64_t v57 = (uint64_t) v27;
      TASSIGN(v56, v57);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v56, v40, v28, j55);
      // pto: %lm_acc_inline1418__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
      // pto: %lm_acc_inline1418__tile_l0_b
      uint64_t v59 = (uint64_t) v28;
      TASSIGN(v58, v59);
      TEXTRACT(v58, v51, j55, v28);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
      // pto: %0
      uint64_t v61 = (uint64_t) v26;
      TASSIGN(v60, v61);
      // pto: %32
      int64_t v62 = (int64_t) ((uint64_t) j55 + (uint64_t) v14);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v60, v40, v28, v62);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
      // pto: %1
      uint64_t v64 = (uint64_t) v25;
      TASSIGN(v63, v64);
      TEXTRACT(v63, v51, v62, v28);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %34
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j55 == v28) {
        // pto: %lm_acc_inline1418__tile_l0_c_first
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %lm_acc_inline1418__tile_l0_c_first
        uint64_t v66 = (uint64_t) v28;
        TASSIGN(v65, v66);
        pipe_barrier(PIPE_M);
        TMATMUL(v65, v56, v58);
      } else {
        // pto: %lm_acc_inline1418__tile_l0_c_acc
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %lm_acc_inline1418__tile_l0_c_acc
        uint64_t v68 = (uint64_t) v28;
        TASSIGN(v67, v68);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v67, v67, v56, v58);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
      // pto: %2
      uint64_t v70 = (uint64_t) v28;
      TASSIGN(v69, v70);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v69, v69, v60, v63);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j71 = v21; j71 < v13; j71 += v12) {
      // pto: %35
      int64_t v72 = (int64_t) ((uint64_t) j71 * (uint64_t) v16);
      // pto: %37
      int64_t v73 = (int64_t) ((uint64_t) v72 + (uint64_t) v16);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %3
      uint64_t v75 = (uint64_t) v28;
      TASSIGN(v74, v75);
      // pto: %38
      int64_t v76 = v72 < v28 ? v28 : v72;
      // pto: %39
      pto::Shape<1, 1, 1, 16, 512> v77 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %39
      pto::Stride<81920, 81920, 81920, 5120, 1> v78 = pto::Stride<81920, 81920, 81920, 5120, 1>();
      // pto: %39
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v28 + v76), v77, v78);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v74, v79);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %4
      uint64_t v81 = (uint64_t) v24;
      TASSIGN(v80, v81);
      // pto: %42
      pto::Shape<1, 1, 1, 192, 512> v82 = pto::Shape<1, 1, 1, 192, 512>();
      // pto: %42
      pto::Stride<983040, 983040, 983040, 5120, 1> v83 = pto::Stride<983040, 983040, 983040, 5120, 1>();
      // pto: %42
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND> v84 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND>(v3 + ((v28 + v47 * v11) + v76), v82, v83);
      TLOAD(v80, v84);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %5
      Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %5
      uint64_t v86 = (uint64_t) v30;
      TASSIGN(v85, v86);
      // pto: %43
      int64_t v87 = v73 < v28 ? v28 : v73;
      // pto: %44
      pto::Shape<1, 1, 1, 16, 512> v88 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %44
      pto::Stride<81920, 81920, 81920, 5120, 1> v89 = pto::Stride<81920, 81920, 81920, 5120, 1>();
      // pto: %44
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v28 + v87), v88, v89);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v85, v90);
      // pto: %6
      Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %6
      uint64_t v92 = (uint64_t) v29;
      TASSIGN(v91, v92);
      // pto: %47
      pto::Shape<1, 1, 1, 192, 512> v93 = pto::Shape<1, 1, 1, 192, 512>();
      // pto: %47
      pto::Stride<983040, 983040, 983040, 5120, 1> v94 = pto::Stride<983040, 983040, 983040, 5120, 1>();
      // pto: %47
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND> v95 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND>(v3 + ((v28 + v47 * v11) + v87), v93, v94);
      TLOAD(v91, v95);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %7
      Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v17);
      // pto: %7
      uint64_t v97 = (uint64_t) v24;
      TASSIGN(v96, v97);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k98 = v28; k98 < v16; k98 += v15) {
        // pto: %8
        Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
        // pto: %8
        uint64_t v100 = (uint64_t) v27;
        TASSIGN(v99, v100);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v99, v74, v28, k98);
        // pto: %9
        Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
        // pto: %9
        uint64_t v102 = (uint64_t) v28;
        TASSIGN(v101, v102);
        TEXTRACT(v101, v96, k98, v28);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %10
        Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
        // pto: %10
        uint64_t v104 = (uint64_t) v26;
        TASSIGN(v103, v104);
        // pto: %49
        int64_t v105 = (int64_t) ((uint64_t) k98 + (uint64_t) v14);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v103, v74, v28, v105);
        // pto: %11
        Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
        // pto: %11
        uint64_t v107 = (uint64_t) v25;
        TASSIGN(v106, v107);
        TEXTRACT(v106, v96, v105, v28);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %12
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %12
        uint64_t v109 = (uint64_t) v28;
        TASSIGN(v108, v109);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v108, v108, v99, v101);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %13
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %13
        uint64_t v111 = (uint64_t) v28;
        TASSIGN(v110, v111);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v110, v110, v103, v106);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %14
      Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v17);
      // pto: %14
      uint64_t v113 = (uint64_t) v29;
      TASSIGN(v112, v113);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k114 = v28; k114 < v16; k114 += v15) {
        // pto: %15
        Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
        // pto: %15
        uint64_t v116 = (uint64_t) v28;
        TASSIGN(v115, v116);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v115, v85, v28, k114);
        // pto: %16
        Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
        // pto: %16
        uint64_t v118 = (uint64_t) v28;
        TASSIGN(v117, v118);
        TEXTRACT(v117, v112, k114, v28);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %17
        Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
        // pto: %17
        uint64_t v120 = (uint64_t) v23;
        TASSIGN(v119, v120);
        // pto: %52
        int64_t v121 = (int64_t) ((uint64_t) k114 + (uint64_t) v14);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v119, v85, v28, v121);
        // pto: %18
        Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
        // pto: %18
        uint64_t v123 = (uint64_t) v25;
        TASSIGN(v122, v123);
        TEXTRACT(v122, v112, v121, v28);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %19
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %19
        uint64_t v125 = (uint64_t) v28;
        TASSIGN(v124, v125);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v124, v124, v115, v117);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %20
        Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
        // pto: %20
        uint64_t v127 = (uint64_t) v28;
        TASSIGN(v126, v127);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v126, v126, v119, v122);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %21
    Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %21
    uint64_t v129 = (uint64_t) v24;
    TASSIGN(v128, v129);
    // pto: %55
    pto::Shape<1, 1, 1, 16, 512> v130 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %55
    pto::Stride<81920, 81920, 81920, 5120, 1> v131 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %55
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + v10, v130, v131);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v128, v132);
    // pto: %22
    Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v16);
    // pto: %22
    uint64_t v134 = (uint64_t) v29;
    TASSIGN(v133, v134);
    // pto: %58
    pto::Shape<1, 1, 1, 192, 512> v135 = pto::Shape<1, 1, 1, 192, 512>();
    // pto: %58
    pto::Stride<983040, 983040, 983040, 5120, 1> v136 = pto::Stride<983040, 983040, 983040, 5120, 1>();
    // pto: %58
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 192, 512>, pto::Stride<983040, 983040, 983040, 5120, 1>, pto::Layout::ND>(v3 + (v9 + v47 * v11), v135, v136);
    TLOAD(v133, v137);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %23
    Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, bfloat16_t, 512, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v17);
    // pto: %23
    uint64_t v139 = (uint64_t) v29;
    TASSIGN(v138, v139);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j140 = v28; j140 < v16; j140 += v15) {
      // pto: %24
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
      // pto: %24
      uint64_t v142 = (uint64_t) v27;
      TASSIGN(v141, v142);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v141, v128, v28, j140);
      // pto: %25
      Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
      // pto: %25
      uint64_t v144 = (uint64_t) v28;
      TASSIGN(v143, v144);
      TEXTRACT(v143, v138, j140, v28);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %26
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v14);
      // pto: %26
      uint64_t v146 = (uint64_t) v26;
      TASSIGN(v145, v146);
      // pto: %60
      int64_t v147 = (int64_t) ((uint64_t) j140 + (uint64_t) v14);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v145, v128, v28, v147);
      // pto: %27
      Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Right, bfloat16_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v17);
      // pto: %27
      uint64_t v149 = (uint64_t) v25;
      TASSIGN(v148, v149);
      TEXTRACT(v148, v138, v147, v28);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %28
      Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
      // pto: %28
      uint64_t v151 = (uint64_t) v28;
      TASSIGN(v150, v151);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v150, v150, v141, v143);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %29
      Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
      // pto: %29
      uint64_t v153 = (uint64_t) v28;
      TASSIGN(v152, v153);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v152, v152, v145, v148);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %lm_acc_inline1418__rv_v2
    Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Acc, float, 16, 192, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v17);
    // pto: %lm_acc_inline1418__rv_v2
    uint64_t v155 = (uint64_t) v28;
    TASSIGN(v154, v155);
    // pto: %lm_hidden_chunk_inline1433__rv_v2
    Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Mat, bfloat16_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %lm_hidden_chunk_inline1433__rv_v2
    uint64_t v157 = (uint64_t) v24;
    TASSIGN(v156, v157);
    // pto: %lm_weight_chunk_inline1419__rv_v2
    Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Mat, bfloat16_t, 192, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v16);
    // pto: %lm_weight_chunk_inline1419__rv_v2
    uint64_t v159 = (uint64_t) v29;
    TASSIGN(v158, v159);
    v154.SetValidShape(v4, v17);
    // pto: %out__iter_v5_pview
    __gm__ float* v160 = PTOAS__GLOBAL_TENSOR_DATA(v35);
    // pto: %out__iter_v5_pview
    int64_t v161 = v4 * v22;
    // pto: %out__iter_v5_pview
    int64_t v162 = v21 * v161;
    // pto: %out__iter_v5_pview
    pto::Shape<1, 1, 1, -1, 192> v163 = pto::Shape<1, 1, 1, -1, 192>(v21, v21, v21, v4, v17);
    // pto: %out__iter_v5_pview
    pto::Stride<-1, -1, -1, -1, -1> v164 = pto::Stride<-1, -1, -1, -1, -1>(v21 * v162, v162, v161, v22, v21);
    // pto: %62, %out__iter_v5_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 192>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v165 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 192>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v160 + ((v28 + (v5 < v28 ? v28 : v5) * v22) + v47 * v21), v163, v164);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v165, v154);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}