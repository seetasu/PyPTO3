#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void out_proj_aiv(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  SaturationMode v8 = SaturationMode::OFF;
  RoundMode v9 = RoundMode::CAST_ROUND;
  const int64_t v10 = 256;
  const int64_t v11 = 20;
  const int64_t v12 = 128;
  const int64_t v13 = 1;
  const int64_t v14 = 5120;
  const int64_t v15 = 64;
  const int64_t v16 = 0;
  const int64_t v17 = 65536;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %window_hidden__iter_v7_view
  int64_t v18 = v12 * v14;
  // pto: %window_hidden__iter_v7_view
  int64_t v19 = v13 * v18;
  // pto: %window_hidden__iter_v7_view
  pto::Shape<1, 1, 1, -1, -1> v20 = pto::Shape<1, 1, 1, -1, -1>(v13, v13, v13, v12, v14);
  // pto: %window_hidden__iter_v7_view
  pto::Stride<-1, -1, -1, -1, -1> v21 = pto::Stride<-1, -1, -1, -1, -1>(v13 * v19, v19, v18, v14, v13);
  // pto: %window_hidden__iter_v7_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v22 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v20, v21);
  // pto: %out_core_inline244__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t i23 = (int64_t) v6; i23 < v11; i23 += v11) {
    // pto: %1
    int64_t v24 = (int64_t) ((uint64_t) i23 * (uint64_t) v10);
    // pto: %t__tile
    Tile<TileType::Vec, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Vec, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v10);
    // pto: %t__tile
    uint64_t v26 = (uint64_t) v17;
    TASSIGN(v25, v26);
    // pto: %3
    int64_t v27 = v24 < v16 ? v16 : v24;
    // pto: %window_hidden__iter_v7_pview
    __gm__ bfloat16_t* v28 = PTOAS__GLOBAL_TENSOR_DATA(v22);
    // pto: %window_hidden__iter_v7_pview
    int64_t v29 = v5 * v14;
    // pto: %window_hidden__iter_v7_pview
    int64_t v30 = v13 * v29;
    // pto: %window_hidden__iter_v7_pview
    pto::Shape<1, 1, 1, -1, 256> v31 = pto::Shape<1, 1, 1, -1, 256>(v13, v13, v13, v5, v10);
    // pto: %window_hidden__iter_v7_pview
    pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v13 * v30, v30, v29, v14, v13);
    // pto: %2, %window_hidden__iter_v7_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v28 + ((v16 + (v4 < v16 ? v16 : v4) * v14) + v27 * v13), v31, v32);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v25, v33);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %resid_chunk_inline415__tile
    Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v10);
    // pto: %resid_chunk_inline415__tile
    uint64_t v35 = (uint64_t) v16;
    TASSIGN(v34, v35);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TCVT(v34, v25, v9, v8);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %out_proj_chunk_inline243__tile
    Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v10);
    // pto: %out_proj_chunk_inline243__tile
    uint64_t v37 = (uint64_t) v17;
    TASSIGN(v36, v37);
    // pto: %out_proj_tile_inline251__rv_v2_pview
    pto::Shape<1, 1, 1, 64, 256> v38 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %out_proj_tile_inline251__rv_v2_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v39 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %out_proj_tile_inline251__rv_v2_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + (v16 + v27), v38, v39);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v36, v40);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %0
    Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 64, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v10);
    // pto: %0
    uint64_t v42 = (uint64_t) v16;
    TASSIGN(v41, v42);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TADD(v41, v36, v34);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %resid1_tile_inline250__iter_v1_pview
    pto::Shape<1, 1, 1, 64, 256> v43 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %resid1_tile_inline250__iter_v1_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v44 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %resid1_tile_inline250__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v1 + (v16 + v27), v43, v44);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v45, v41);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}