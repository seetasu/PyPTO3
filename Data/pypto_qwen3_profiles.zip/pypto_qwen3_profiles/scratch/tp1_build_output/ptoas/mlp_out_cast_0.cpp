#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mlp_out_cast_0(__gm__ bfloat16_t* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  SaturationMode v8 = SaturationMode::OFF;
  RoundMode v9 = RoundMode::CAST_ROUND;
  const int64_t v10 = 256;
  const int64_t v11 = 20;
  const int64_t v12 = 128;
  const int64_t v13 = 1;
  const int64_t v14 = 5120;
  const int64_t v15 = 2048;
  const int64_t v16 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %group_next__iter_v1_view
  int64_t v17 = v15 * v14;
  // pto: %group_next__iter_v1_view
  int64_t v18 = v13 * v17;
  // pto: %group_next__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v19 = pto::Shape<1, 1, 1, -1, -1>(v13, v13, v13, v15, v14);
  // pto: %group_next__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v20 = pto::Stride<-1, -1, -1, -1, -1>(v13 * v18, v18, v17, v14, v13);
  // pto: %group_next__iter_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v21 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v19, v20);
  // pto: %cast_core_inline429__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i22 = (int64_t) v6; i22 < v3; i22 += v11) {
    // pto: %0
    int64_t v23 = (int64_t) ((uint64_t) i22 * (uint64_t) v10);
    // pto: %acc_chunk_inline595__tile
    Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v24 = Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %acc_chunk_inline595__tile
    uint64_t v25 = (uint64_t) v16;
    TASSIGN(v24, v25);
    // pto: %1
    int64_t v26 = v23 < v16 ? v16 : v23;
    // pto: %mlp_out_acc_tile_inline449__rv_v5_pview
    pto::Shape<1, 1, 1, 128, 256> v27 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %mlp_out_acc_tile_inline449__rv_v5_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v28 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %mlp_out_acc_tile_inline449__rv_v5_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v29 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v26), v27, v28);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v24, v29);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %out_bf_inline612__tile
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %out_bf_inline612__tile
    uint64_t v31 = (uint64_t) v16;
    TASSIGN(v30, v31);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCVT(v30, v24, v9, v8);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %out_valid_inline427__tile
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v4, v10);
    // pto: %out_valid_inline427__tile
    uint64_t v33 = (uint64_t) v16;
    TASSIGN(v32, v33);
    // pto: %slice_view
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v4);
    // pto: %slice_view
    uint64_t v35 = (uint64_t) v16;
    TASSIGN(v34, v35);
    // pto: %group_next__iter_v3_pview
    __gm__ bfloat16_t* v36 = PTOAS__GLOBAL_TENSOR_DATA(v21);
    // pto: %group_next__iter_v3_pview
    int64_t v37 = v4 * v14;
    // pto: %group_next__iter_v3_pview
    int64_t v38 = v13 * v37;
    // pto: %group_next__iter_v3_pview
    pto::Shape<1, 1, 1, -1, 256> v39 = pto::Shape<1, 1, 1, -1, 256>(v13, v13, v13, v4, v10);
    // pto: %group_next__iter_v3_pview
    pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v13 * v38, v38, v37, v14, v13);
    // pto: %2, %group_next__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v36 + ((v16 + (v5 < v16 ? v16 : v5) * v14) + v26 * v13), v39, v40);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v41, v34);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}