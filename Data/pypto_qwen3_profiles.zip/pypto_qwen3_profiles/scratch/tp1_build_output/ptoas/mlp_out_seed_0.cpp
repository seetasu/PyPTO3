#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mlp_out_seed_0(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  const int64_t v8 = 5120;
  const int64_t v9 = 256;
  const int64_t v10 = 20;
  const int64_t v11 = 128;
  const int64_t v12 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %seed_core_inline640__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i13 = (int64_t) v6; i13 < v3; i13 += v10) {
    // pto: %0
    int64_t v14 = (int64_t) ((uint64_t) i13 * (uint64_t) v9);
    // pto: %t__tile
    Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v15 = Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v9);
    // pto: %t__tile
    uint64_t v16 = (uint64_t) v12;
    TASSIGN(v15, v16);
    // pto: %2
    int64_t v17 = v14 < v12 ? v12 : v14;
    // pto: %resid1_all_inline510__ssa_v0_pview
    pto::Shape<1, 1, 1, 128, 256> v18 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %resid1_all_inline510__ssa_v0_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v19 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %1, %resid1_all_inline510__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v20 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + ((v12 + (v4 < v12 ? v12 : v4) * v8) + v17), v18, v19);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v15, v20);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %mlp_out_acc_tile_inline449__iter_v1_pview
    pto::Shape<1, 1, 1, 128, 256> v21 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %mlp_out_acc_tile_inline449__iter_v1_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v22 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %mlp_out_acc_tile_inline449__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v23 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v1 + (v12 + v17), v21, v22);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v23, v15);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}