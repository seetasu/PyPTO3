#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_proj(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  unsigned v10 = 4864;
  const int64_t v11 = 1024;
  const int64_t v12 = 4864;
  const int64_t v13 = 2;
  const int64_t v14 = 19;
  const int64_t v15 = 128;
  const int64_t v16 = 256;
  const int64_t v17 = 8;
  const int64_t v18 = 4;
  const int64_t v19 = 1;
  const int64_t v20 = 64;
  const int64_t v21 = 16384;
  const int64_t v22 = 8192;
  const int64_t v23 = 32768;
  const int64_t v24 = 24576;
  const int64_t v25 = 0;
  const int64_t v26 = 196608;
  const int64_t v27 = 65536;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %k_acc_inline375__tile_l0_c_phi
  Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v28 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
  // pto: %k_acc_inline375__tile_l0_c_phi
  uint64_t v29 = (uint64_t) v25;
  TASSIGN(v28, v29);
  // pto: %v_acc_inline373__tile_l0_c_phi
  Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
  // pto: %v_acc_inline373__tile_l0_c_phi
  uint64_t v31 = (uint64_t) v25;
  TASSIGN(v30, v31);
  // pto: %kv_core_inline364__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t i32 = (int64_t) v8; i32 < v18; i32 += v17) {
    // pto: %51
    int64_t v33 = (int64_t) ((uint64_t) i32 * (uint64_t) v16);
    // pto: %tile_a_inline318__tile
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %tile_a_inline318__tile
    uint64_t v35 = (uint64_t) v27;
    TASSIGN(v34, v35);
    // pto: %normed_tile_inline289__rv_v2_pview
    pto::Shape<1, 1, 1, 64, 256> v36 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %normed_tile_inline289__rv_v2_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v37 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %normed_tile_inline289__rv_v2_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v38 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3, v36, v37);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v34, v38);
    // pto: %tile_wk_inline334__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
    // pto: %tile_wk_inline334__tile
    uint64_t v40 = (uint64_t) v26;
    TASSIGN(v39, v40);
    // pto: %52
    int64_t v41 = v6 < v25 ? v25 : v6;
    // pto: %53
    int64_t v42 = v33 < v25 ? v25 : v33;
    // pto: %wk__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v43 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wk__ssa_v0_pview
    pto::Stride<262144, 262144, 262144, 1024, 1> v44 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %wk__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v45 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v4 + ((v25 + v41 * v11) + v42), v43, v44);
    TLOAD(v39, v45);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %k_acc_inline375__tile_l0_init
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %k_acc_inline375__tile_l0_init
    uint64_t v47 = (uint64_t) v25;
    TASSIGN(v46, v47);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j48 = v25; j48 < v16; j48 += v15) {
      // pto: %k_acc_inline375__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %k_acc_inline375__tile_l0_a
      uint64_t v50 = (uint64_t) v24;
      TASSIGN(v49, v50);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v49, v34, v25, j48);
      // pto: %k_acc_inline375__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %k_acc_inline375__tile_l0_b
      uint64_t v52 = (uint64_t) v23;
      TASSIGN(v51, v52);
      TEXTRACT(v51, v39, j48, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %0
      uint64_t v54 = (uint64_t) v25;
      TASSIGN(v53, v54);
      // pto: %54
      int64_t v55 = (int64_t) ((uint64_t) j48 + (uint64_t) v20);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v53, v34, v25, v55);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %1
      uint64_t v57 = (uint64_t) v25;
      TASSIGN(v56, v57);
      TEXTRACT(v56, v39, v55, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %56
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j48 == v25) {
        // pto: %k_acc_inline375__tile_l0_c_first
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %k_acc_inline375__tile_l0_c_first
        uint64_t v59 = (uint64_t) v25;
        TASSIGN(v58, v59);
        pipe_barrier(PIPE_M);
        TMATMUL(v58, v49, v51);
      } else {
        // pto: %k_acc_inline375__tile_l0_c_acc
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %k_acc_inline375__tile_l0_c_acc
        uint64_t v61 = (uint64_t) v25;
        TASSIGN(v60, v61);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v60, v60, v49, v51);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %2
      uint64_t v63 = (uint64_t) v25;
      TASSIGN(v62, v63);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v62, v62, v53, v56);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    for (int64_t j64 = v19; j64 < v14; j64 += v13) {
      // pto: %57
      int64_t v65 = (int64_t) ((uint64_t) j64 * (uint64_t) v16);
      // pto: %59
      int64_t v66 = (int64_t) ((uint64_t) v65 + (uint64_t) v16);
      // pto: %tile_a_i_inline351__tile
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %tile_a_i_inline351__tile
      uint64_t v68 = (uint64_t) v25;
      TASSIGN(v67, v68);
      // pto: %61
      pto::Shape<1, 1, 1, 64, 256> v69 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %61
      pto::Stride<327680, 327680, 327680, 5120, 1> v70 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %60, %61
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v71 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + (v25 + (v65 < v25 ? v25 : v65)), v69, v70);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v67, v71);
      // pto: %tile_wk_i_inline366__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %tile_wk_i_inline366__tile
      uint64_t v73 = (uint64_t) v26;
      TASSIGN(v72, v73);
      // pto: %62
      int64_t v74 = (int64_t) ((uint64_t) v6 + (uint64_t) v65);
      // pto: %65
      pto::Shape<1, 1, 1, 256, 256> v75 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %65
      pto::Stride<262144, 262144, 262144, 1024, 1> v76 = pto::Stride<262144, 262144, 262144, 1024, 1>();
      // pto: %63, %65
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v77 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v4 + ((v25 + (v74 < v25 ? v25 : v74) * v11) + v42), v75, v76);
      TLOAD(v72, v77);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %3
      uint64_t v79 = (uint64_t) v23;
      TASSIGN(v78, v79);
      // pto: %67
      pto::Shape<1, 1, 1, 64, 256> v80 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %67
      pto::Stride<327680, 327680, 327680, 5120, 1> v81 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %66, %67
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + (v25 + (v66 < v25 ? v25 : v66)), v80, v81);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v78, v82);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %4
      uint64_t v84 = (uint64_t) v27;
      TASSIGN(v83, v84);
      // pto: %68
      int64_t v85 = (int64_t) ((uint64_t) v6 + (uint64_t) v66);
      // pto: %71
      pto::Shape<1, 1, 1, 256, 256> v86 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %71
      pto::Stride<262144, 262144, 262144, 1024, 1> v87 = pto::Stride<262144, 262144, 262144, 1024, 1>();
      // pto: %69, %71
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v4 + ((v25 + (v85 < v25 ? v25 : v85) * v11) + v42), v86, v87);
      TLOAD(v83, v88);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k89 = v25; k89 < v16; k89 += v15) {
        // pto: %5
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %5
        uint64_t v91 = (uint64_t) v24;
        TASSIGN(v90, v91);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v90, v67, v25, k89);
        // pto: %6
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %6
        uint64_t v93 = (uint64_t) v23;
        TASSIGN(v92, v93);
        TEXTRACT(v92, v72, k89, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %7
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %7
        uint64_t v95 = (uint64_t) v25;
        TASSIGN(v94, v95);
        // pto: %73
        int64_t v96 = (int64_t) ((uint64_t) k89 + (uint64_t) v20);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v94, v67, v25, v96);
        // pto: %8
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %8
        uint64_t v98 = (uint64_t) v25;
        TASSIGN(v97, v98);
        TEXTRACT(v97, v72, v96, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %9
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %9
        uint64_t v100 = (uint64_t) v25;
        TASSIGN(v99, v100);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v99, v99, v90, v92);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %10
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %10
        uint64_t v102 = (uint64_t) v25;
        TASSIGN(v101, v102);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v101, v101, v94, v97);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k103 = v25; k103 < v16; k103 += v15) {
        // pto: %11
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %11
        uint64_t v105 = (uint64_t) v22;
        TASSIGN(v104, v105);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v104, v78, v25, k103);
        // pto: %12
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %12
        uint64_t v107 = (uint64_t) v23;
        TASSIGN(v106, v107);
        TEXTRACT(v106, v83, k103, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %13
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %13
        uint64_t v109 = (uint64_t) v21;
        TASSIGN(v108, v109);
        // pto: %76
        int64_t v110 = (int64_t) ((uint64_t) k103 + (uint64_t) v20);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v108, v78, v25, v110);
        // pto: %14
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %14
        uint64_t v112 = (uint64_t) v25;
        TASSIGN(v111, v112);
        TEXTRACT(v111, v83, v110, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %15
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %15
        uint64_t v114 = (uint64_t) v25;
        TASSIGN(v113, v114);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v113, v113, v104, v106);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %16
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %16
        uint64_t v116 = (uint64_t) v25;
        TASSIGN(v115, v116);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v115, v115, v108, v111);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %17
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %17
    uint64_t v118 = (uint64_t) v27;
    TASSIGN(v117, v118);
    // pto: %79
    pto::Shape<1, 1, 1, 64, 256> v119 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %79
    pto::Stride<327680, 327680, 327680, 5120, 1> v120 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %79
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + v10, v119, v120);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v117, v121);
    // pto: %18
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
    // pto: %18
    uint64_t v123 = (uint64_t) v26;
    TASSIGN(v122, v123);
    // pto: %80
    int64_t v124 = (int64_t) ((uint64_t) v6 + (uint64_t) v12);
    // pto: %81
    int64_t v125 = v124 < v25 ? v25 : v124;
    // pto: %83
    pto::Shape<1, 1, 1, 256, 256> v126 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %83
    pto::Stride<262144, 262144, 262144, 1024, 1> v127 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %83
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v4 + ((v25 + v125 * v11) + v42), v126, v127);
    TLOAD(v122, v128);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j129 = v25; j129 < v16; j129 += v15) {
      // pto: %19
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %19
      uint64_t v131 = (uint64_t) v24;
      TASSIGN(v130, v131);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v130, v117, v25, j129);
      // pto: %20
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %20
      uint64_t v133 = (uint64_t) v23;
      TASSIGN(v132, v133);
      TEXTRACT(v132, v122, j129, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %21
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %21
      uint64_t v135 = (uint64_t) v25;
      TASSIGN(v134, v135);
      // pto: %85
      int64_t v136 = (int64_t) ((uint64_t) j129 + (uint64_t) v20);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v134, v117, v25, v136);
      // pto: %22
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %22
      uint64_t v138 = (uint64_t) v25;
      TASSIGN(v137, v138);
      TEXTRACT(v137, v122, v136, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %23
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %23
      uint64_t v140 = (uint64_t) v25;
      TASSIGN(v139, v140);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v139, v139, v130, v132);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %24
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %24
      uint64_t v142 = (uint64_t) v25;
      TASSIGN(v141, v142);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v141, v141, v134, v137);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %k_acc_inline375__rv_v2
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %k_acc_inline375__rv_v2
    uint64_t v144 = (uint64_t) v25;
    TASSIGN(v143, v144);
    // pto: %k_proj_tile_inline265__iter_v1_pview
    pto::Shape<1, 1, 1, 64, 256> v145 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %k_proj_tile_inline265__iter_v1_pview
    pto::Stride<65536, 65536, 65536, 1024, 1> v146 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %k_proj_tile_inline265__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v147 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v1 + (v25 + v42), v145, v146);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v147, v143);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    // pto: %tile_a_v1_inline368__tile
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %tile_a_v1_inline368__tile
    uint64_t v149 = (uint64_t) v27;
    TASSIGN(v148, v149);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    TLOAD(v148, v38);
    // pto: %tile_wv_inline372__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
    // pto: %tile_wv_inline372__tile
    uint64_t v151 = (uint64_t) v26;
    TASSIGN(v150, v151);
    // pto: %wv__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v152 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wv__ssa_v0_pview
    pto::Stride<262144, 262144, 262144, 1024, 1> v153 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %wv__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v154 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v5 + ((v25 + v41 * v11) + v42), v152, v153);
    TLOAD(v150, v154);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    // pto: %v_acc_inline373__tile_l0_init
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %v_acc_inline373__tile_l0_init
    uint64_t v156 = (uint64_t) v25;
    TASSIGN(v155, v156);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j157 = v25; j157 < v16; j157 += v15) {
      // pto: %v_acc_inline373__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %v_acc_inline373__tile_l0_a
      uint64_t v159 = (uint64_t) v24;
      TASSIGN(v158, v159);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v158, v148, v25, j157);
      // pto: %v_acc_inline373__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %v_acc_inline373__tile_l0_b
      uint64_t v161 = (uint64_t) v23;
      TASSIGN(v160, v161);
      TEXTRACT(v160, v150, j157, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %25
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %25
      uint64_t v163 = (uint64_t) v25;
      TASSIGN(v162, v163);
      // pto: %91
      int64_t v164 = (int64_t) ((uint64_t) j157 + (uint64_t) v20);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v162, v148, v25, v164);
      // pto: %26
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %26
      uint64_t v166 = (uint64_t) v25;
      TASSIGN(v165, v166);
      TEXTRACT(v165, v150, v164, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %93
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j157 == v25) {
        // pto: %v_acc_inline373__tile_l0_c_first
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %v_acc_inline373__tile_l0_c_first
        uint64_t v168 = (uint64_t) v25;
        TASSIGN(v167, v168);
        pipe_barrier(PIPE_M);
        TMATMUL(v167, v158, v160);
      } else {
        // pto: %v_acc_inline373__tile_l0_c_acc
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %v_acc_inline373__tile_l0_c_acc
        uint64_t v170 = (uint64_t) v25;
        TASSIGN(v169, v170);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v169, v169, v158, v160);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %27
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %27
      uint64_t v172 = (uint64_t) v25;
      TASSIGN(v171, v172);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v171, v171, v162, v165);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    for (int64_t j173 = v19; j173 < v14; j173 += v13) {
      // pto: %94
      int64_t v174 = (int64_t) ((uint64_t) j173 * (uint64_t) v16);
      // pto: %96
      int64_t v175 = (int64_t) ((uint64_t) v174 + (uint64_t) v16);
      // pto: %28
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %28
      uint64_t v177 = (uint64_t) v25;
      TASSIGN(v176, v177);
      // pto: %98
      pto::Shape<1, 1, 1, 64, 256> v178 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %98
      pto::Stride<327680, 327680, 327680, 5120, 1> v179 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %97, %98
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v180 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + (v25 + (v174 < v25 ? v25 : v174)), v178, v179);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v176, v180);
      // pto: %tile_wv_i_inline374__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %tile_wv_i_inline374__tile
      uint64_t v182 = (uint64_t) v26;
      TASSIGN(v181, v182);
      // pto: %99
      int64_t v183 = (int64_t) ((uint64_t) v6 + (uint64_t) v174);
      // pto: %102
      pto::Shape<1, 1, 1, 256, 256> v184 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %102
      pto::Stride<262144, 262144, 262144, 1024, 1> v185 = pto::Stride<262144, 262144, 262144, 1024, 1>();
      // pto: %100, %102
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v186 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v5 + ((v25 + (v183 < v25 ? v25 : v183) * v11) + v42), v184, v185);
      TLOAD(v181, v186);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %29
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %29
      uint64_t v188 = (uint64_t) v23;
      TASSIGN(v187, v188);
      // pto: %104
      pto::Shape<1, 1, 1, 64, 256> v189 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %104
      pto::Stride<327680, 327680, 327680, 5120, 1> v190 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %103, %104
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v191 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v3 + (v25 + (v175 < v25 ? v25 : v175)), v189, v190);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v187, v191);
      // pto: %30
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %30
      uint64_t v193 = (uint64_t) v27;
      TASSIGN(v192, v193);
      // pto: %105
      int64_t v194 = (int64_t) ((uint64_t) v6 + (uint64_t) v175);
      // pto: %108
      pto::Shape<1, 1, 1, 256, 256> v195 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %108
      pto::Stride<262144, 262144, 262144, 1024, 1> v196 = pto::Stride<262144, 262144, 262144, 1024, 1>();
      // pto: %106, %108
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v197 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v5 + ((v25 + (v194 < v25 ? v25 : v194) * v11) + v42), v195, v196);
      TLOAD(v192, v197);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t k198 = v25; k198 < v16; k198 += v15) {
        // pto: %31
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %31
        uint64_t v200 = (uint64_t) v24;
        TASSIGN(v199, v200);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v199, v176, v25, k198);
        // pto: %32
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %32
        uint64_t v202 = (uint64_t) v23;
        TASSIGN(v201, v202);
        TEXTRACT(v201, v181, k198, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %33
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %33
        uint64_t v204 = (uint64_t) v25;
        TASSIGN(v203, v204);
        // pto: %110
        int64_t v205 = (int64_t) ((uint64_t) k198 + (uint64_t) v20);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        TEXTRACT(v203, v176, v25, v205);
        // pto: %34
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %34
        uint64_t v207 = (uint64_t) v25;
        TASSIGN(v206, v207);
        TEXTRACT(v206, v181, v205, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %35
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %35
        uint64_t v209 = (uint64_t) v25;
        TASSIGN(v208, v209);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v208, v208, v199, v201);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        // pto: %36
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %36
        uint64_t v211 = (uint64_t) v25;
        TASSIGN(v210, v211);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v210, v210, v203, v206);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t k212 = v25; k212 < v16; k212 += v15) {
        // pto: %37
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %37
        uint64_t v214 = (uint64_t) v22;
        TASSIGN(v213, v214);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v213, v187, v25, k212);
        // pto: %38
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %38
        uint64_t v216 = (uint64_t) v23;
        TASSIGN(v215, v216);
        TEXTRACT(v215, v192, k212, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %39
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
        // pto: %39
        uint64_t v218 = (uint64_t) v21;
        TASSIGN(v217, v218);
        // pto: %113
        int64_t v219 = (int64_t) ((uint64_t) k212 + (uint64_t) v20);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        TEXTRACT(v217, v187, v25, v219);
        // pto: %40
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %40
        uint64_t v221 = (uint64_t) v25;
        TASSIGN(v220, v221);
        TEXTRACT(v220, v192, v219, v25);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %41
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %41
        uint64_t v223 = (uint64_t) v25;
        TASSIGN(v222, v223);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v222, v222, v213, v215);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        // pto: %42
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
        // pto: %42
        uint64_t v225 = (uint64_t) v25;
        TASSIGN(v224, v225);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v224, v224, v217, v220);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    }
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %43
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %43
    uint64_t v227 = (uint64_t) v27;
    TASSIGN(v226, v227);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v226, v121);
    // pto: %44
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v16);
    // pto: %44
    uint64_t v229 = (uint64_t) v26;
    TASSIGN(v228, v229);
    // pto: %120
    pto::Shape<1, 1, 1, 256, 256> v230 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %120
    pto::Stride<262144, 262144, 262144, 1024, 1> v231 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %120
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v232 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v5 + ((v25 + v125 * v11) + v42), v230, v231);
    TLOAD(v228, v232);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j233 = v25; j233 < v16; j233 += v15) {
      // pto: %45
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %45
      uint64_t v235 = (uint64_t) v24;
      TASSIGN(v234, v235);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v234, v226, v25, j233);
      // pto: %46
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %46
      uint64_t v237 = (uint64_t) v23;
      TASSIGN(v236, v237);
      TEXTRACT(v236, v228, j233, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %47
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %47
      uint64_t v239 = (uint64_t) v25;
      TASSIGN(v238, v239);
      // pto: %122
      int64_t v240 = (int64_t) ((uint64_t) j233 + (uint64_t) v20);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v238, v226, v25, v240);
      // pto: %48
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %48
      uint64_t v242 = (uint64_t) v25;
      TASSIGN(v241, v242);
      TEXTRACT(v241, v228, v240, v25);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %49
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %49
      uint64_t v244 = (uint64_t) v25;
      TASSIGN(v243, v244);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v243, v243, v234, v236);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %50
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
      // pto: %50
      uint64_t v246 = (uint64_t) v25;
      TASSIGN(v245, v246);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v245, v245, v238, v241);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %v_acc_inline373__rv_v2
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v16);
    // pto: %v_acc_inline373__rv_v2
    uint64_t v248 = (uint64_t) v25;
    TASSIGN(v247, v248);
    // pto: %v_proj_tile_inline319__iter_v1_pview
    pto::Shape<1, 1, 1, 64, 256> v249 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %v_proj_tile_inline319__iter_v1_pview
    pto::Stride<65536, 65536, 65536, 1024, 1> v250 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %v_proj_tile_inline319__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v251 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v2 + (v25 + v42), v249, v250);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    TSTORE(v251, v247);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}