#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void token_embed(__gm__ int32_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5) {
  const int64_t v6 = 256;
  const int64_t v7 = 5120;
  const int64_t v8 = 1;
  const int64_t v9 = 8;
  const int64_t v10 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  // pto: %flat_offset_mul, %token_id_inline1089__tile
  int32_t v11 = (v1)[(int64_t) ((uint64_t) v4 * (uint64_t) v9)];
  // pto: %0
  int64_t v12 = (int64_t) v11;
  for (int64_t i13 = v10; i13 < v7; i13 += v6) {
    // pto: %hidden_chunk_inline1087__tile
    Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v14 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v8, v6);
    // pto: %hidden_chunk_inline1087__tile
    uint64_t v15 = (uint64_t) v10;
    TASSIGN(v14, v15);
    // pto: %2
    int64_t v16 = i13 < v10 ? v10 : i13;
    // pto: %embed_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 256> v17 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %embed_weight__ssa_v0_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v18 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %1, %embed_weight__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v19 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + ((v10 + (v12 < v10 ? v10 : v12) * v7) + v16), v17, v18);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v14, v19);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %next_hidden__iter_v3_pview
    pto::Shape<1, 1, 1, 1, 256> v20 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %next_hidden__iter_v3_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v21 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %3, %next_hidden__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v22 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v2 + ((v10 + (v4 < v10 ? v10 : v4) * v7) + v16), v20, v21);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v22, v14);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}