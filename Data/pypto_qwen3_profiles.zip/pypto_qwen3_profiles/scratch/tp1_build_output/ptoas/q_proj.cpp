#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void q_proj(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int32_t v5, int32_t v6) {
  const int64_t v7 = 5120;
  const int64_t v8 = 768;
  const int64_t v9 = 64;
  const int64_t v10 = 128;
  const int64_t v11 = 256;
  const int64_t v12 = 2;
  const int64_t v13 = 1024;
  const int64_t v14 = 512;
  const int64_t v15 = 5;
  const int64_t v16 = 1;
  const int64_t v17 = 16;
  const int64_t v18 = 2048;
  const int64_t v19 = 8192;
  const int64_t v20 = 32768;
  const int64_t v21 = 6144;
  const int64_t v22 = 4096;
  const int64_t v23 = 0;
  const int64_t v24 = 147456;
  const int64_t v25 = 16384;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %q_acc_inline1290__tile_l0_c_phi
  Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v26 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
  // pto: %q_acc_inline1290__tile_l0_c_phi
  uint64_t v27 = (uint64_t) v23;
  TASSIGN(v26, v27);
  // pto: %q_blk_inline1255__tile
  int64_t v28 = (int64_t) v5;
  // pto: %29, %31
  int64_t v29 = (int64_t) ((uint64_t) (v28 % v15) * (uint64_t) v13);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i30 = v23; i30 < v12; i30 += v16) {
    // pto: %28, %30, %33, %32
    int64_t v31 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) (v28 / v15) * (uint64_t) v14)) + (uint64_t) ((int64_t) ((uint64_t) i30 * (uint64_t) v11)));
    // pto: %t__tile
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %t__tile
    uint64_t v33 = (uint64_t) v25;
    TASSIGN(v32, v33);
    // pto: %normed__iter_v4_pview
    pto::Shape<1, 1, 1, 16, 256> v34 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %normed__iter_v4_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v35 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %34, %normed__iter_v4_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v36 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v29 < v23 ? v23 : v29)), v34, v35);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v32, v36);
    // pto: %0
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %0
    uint64_t v38 = (uint64_t) v24;
    TASSIGN(v37, v38);
    // pto: %35
    int64_t v39 = (int64_t) ((uint64_t) v4 + (uint64_t) v29);
    // pto: %37
    int64_t v40 = v31 < v23 ? v23 : v31;
    // pto: %wq__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v41 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wq__ssa_v0_pview
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v42 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %36, %wq__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v43 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v39 < v23 ? v23 : v39) * v7) + v40), v41, v42);
    TLOAD(v37, v43);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %q_acc_inline1290__tile_l0_init
    Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %q_acc_inline1290__tile_l0_init
    uint64_t v45 = (uint64_t) v23;
    TASSIGN(v44, v45);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j46 = v23; j46 < v11; j46 += v10) {
      // pto: %q_acc_inline1290__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %q_acc_inline1290__tile_l0_a
      uint64_t v48 = (uint64_t) v22;
      TASSIGN(v47, v48);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v47, v32, v23, j46);
      // pto: %q_acc_inline1290__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %q_acc_inline1290__tile_l0_b
      uint64_t v50 = (uint64_t) v23;
      TASSIGN(v49, v50);
      TEXTRACT(v49, v37, j46, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %1
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %1
      uint64_t v52 = (uint64_t) v21;
      TASSIGN(v51, v52);
      // pto: %38
      int64_t v53 = (int64_t) ((uint64_t) j46 + (uint64_t) v9);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v51, v32, v23, v53);
      // pto: %2
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %2
      uint64_t v55 = (uint64_t) v20;
      TASSIGN(v54, v55);
      TEXTRACT(v54, v37, v53, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %40
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j46 == v23) {
        // pto: %q_acc_inline1290__tile_l0_c_first
        Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
        // pto: %q_acc_inline1290__tile_l0_c_first
        uint64_t v57 = (uint64_t) v23;
        TASSIGN(v56, v57);
        pipe_barrier(PIPE_M);
        TMATMUL(v56, v47, v49);
      } else {
        // pto: %q_acc_inline1290__tile_l0_c_acc
        Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
        // pto: %q_acc_inline1290__tile_l0_c_acc
        uint64_t v59 = (uint64_t) v23;
        TASSIGN(v58, v59);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v58, v58, v47, v49);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %3
      uint64_t v61 = (uint64_t) v23;
      TASSIGN(v60, v61);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v60, v60, v51, v54);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %41
    int64_t v62 = (int64_t) ((uint64_t) v29 + (uint64_t) v11);
    // pto: %42
    int64_t v63 = (int64_t) ((uint64_t) v29 + (uint64_t) v14);
    // pto: %4
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %4
    uint64_t v65 = (uint64_t) v23;
    TASSIGN(v64, v65);
    // pto: %44
    pto::Shape<1, 1, 1, 16, 256> v66 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %44
    pto::Stride<81920, 81920, 81920, 5120, 1> v67 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %43, %44
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v68 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v62 < v23 ? v23 : v62)), v66, v67);
    TLOAD(v64, v68);
    // pto: %5
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %5
    uint64_t v70 = (uint64_t) v24;
    TASSIGN(v69, v70);
    // pto: %45
    int64_t v71 = (int64_t) ((uint64_t) v4 + (uint64_t) v62);
    // pto: %48
    pto::Shape<1, 1, 1, 256, 256> v72 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %48
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v73 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %46, %48
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v74 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v71 < v23 ? v23 : v71) * v7) + v40), v72, v73);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v69, v74);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %6
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %6
    uint64_t v76 = (uint64_t) v19;
    TASSIGN(v75, v76);
    // pto: %50
    pto::Shape<1, 1, 1, 16, 256> v77 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %50
    pto::Stride<81920, 81920, 81920, 5120, 1> v78 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %49, %50
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v63 < v23 ? v23 : v63)), v77, v78);
    TLOAD(v75, v79);
    // pto: %7
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %7
    uint64_t v81 = (uint64_t) v25;
    TASSIGN(v80, v81);
    // pto: %51
    int64_t v82 = (int64_t) ((uint64_t) v4 + (uint64_t) v63);
    // pto: %54
    pto::Shape<1, 1, 1, 256, 256> v83 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %54
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v84 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %52, %54
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v85 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v82 < v23 ? v23 : v82) * v7) + v40), v83, v84);
    TLOAD(v80, v85);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j86 = v23; j86 < v11; j86 += v10) {
      // pto: %8
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %8
      uint64_t v88 = (uint64_t) v22;
      TASSIGN(v87, v88);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TEXTRACT(v87, v64, v23, j86);
      // pto: %9
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %9
      uint64_t v90 = (uint64_t) v23;
      TASSIGN(v89, v90);
      TEXTRACT(v89, v69, j86, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %10
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %10
      uint64_t v92 = (uint64_t) v21;
      TASSIGN(v91, v92);
      // pto: %56
      int64_t v93 = (int64_t) ((uint64_t) j86 + (uint64_t) v9);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TEXTRACT(v91, v64, v23, v93);
      // pto: %11
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %11
      uint64_t v95 = (uint64_t) v20;
      TASSIGN(v94, v95);
      TEXTRACT(v94, v69, v93, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      // pto: %12
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %12
      uint64_t v97 = (uint64_t) v23;
      TASSIGN(v96, v97);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v96, v96, v87, v89);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      // pto: %13
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %13
      uint64_t v99 = (uint64_t) v23;
      TASSIGN(v98, v99);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v98, v98, v91, v94);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    for (int64_t j100 = v23; j100 < v11; j100 += v10) {
      // pto: %14
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %14
      uint64_t v102 = (uint64_t) v23;
      TASSIGN(v101, v102);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      TEXTRACT(v101, v75, v23, j100);
      // pto: %15
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %15
      uint64_t v104 = (uint64_t) v23;
      TASSIGN(v103, v104);
      TEXTRACT(v103, v80, j100, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      // pto: %16
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %16
      uint64_t v106 = (uint64_t) v18;
      TASSIGN(v105, v106);
      // pto: %59
      int64_t v107 = (int64_t) ((uint64_t) j100 + (uint64_t) v9);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v105, v75, v23, v107);
      // pto: %17
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %17
      uint64_t v109 = (uint64_t) v20;
      TASSIGN(v108, v109);
      TEXTRACT(v108, v80, v107, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      // pto: %18
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %18
      uint64_t v111 = (uint64_t) v23;
      TASSIGN(v110, v111);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v110, v110, v101, v103);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      // pto: %19
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %19
      uint64_t v113 = (uint64_t) v23;
      TASSIGN(v112, v113);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v112, v112, v105, v108);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %61
    int64_t v114 = (int64_t) ((uint64_t) v29 + (uint64_t) v8);
    // pto: %20
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %20
    uint64_t v116 = (uint64_t) v25;
    TASSIGN(v115, v116);
    // pto: %63
    pto::Shape<1, 1, 1, 16, 256> v117 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %63
    pto::Stride<81920, 81920, 81920, 5120, 1> v118 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %62, %63
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v114 < v23 ? v23 : v114)), v117, v118);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v115, v119);
    // pto: %21
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %21
    uint64_t v121 = (uint64_t) v24;
    TASSIGN(v120, v121);
    // pto: %64
    int64_t v122 = (int64_t) ((uint64_t) v4 + (uint64_t) v114);
    // pto: %67
    pto::Shape<1, 1, 1, 256, 256> v123 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %67
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v124 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %65, %67
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v125 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v122 < v23 ? v23 : v122) * v7) + v40), v123, v124);
    TLOAD(v120, v125);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j126 = v23; j126 < v11; j126 += v10) {
      // pto: %22
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %22
      uint64_t v128 = (uint64_t) v22;
      TASSIGN(v127, v128);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v127, v115, v23, j126);
      // pto: %23
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %23
      uint64_t v130 = (uint64_t) v23;
      TASSIGN(v129, v130);
      TEXTRACT(v129, v120, j126, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %24
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v9);
      // pto: %24
      uint64_t v132 = (uint64_t) v21;
      TASSIGN(v131, v132);
      // pto: %69
      int64_t v133 = (int64_t) ((uint64_t) j126 + (uint64_t) v9);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v131, v115, v23, v133);
      // pto: %25
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v9, v11);
      // pto: %25
      uint64_t v135 = (uint64_t) v20;
      TASSIGN(v134, v135);
      TEXTRACT(v134, v120, v133, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %26
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %26
      uint64_t v137 = (uint64_t) v23;
      TASSIGN(v136, v137);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v136, v136, v127, v129);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %27
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
      // pto: %27
      uint64_t v139 = (uint64_t) v23;
      TASSIGN(v138, v139);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v138, v138, v131, v134);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %q_acc_inline1290__rv_v2
    Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v11);
    // pto: %q_acc_inline1290__rv_v2
    uint64_t v141 = (uint64_t) v23;
    TASSIGN(v140, v141);
    // pto: %q_proj_inline1340__iter_v4_pview
    pto::Shape<1, 1, 1, 16, 256> v142 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %q_proj_inline1340__iter_v4_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v143 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %q_proj_inline1340__iter_v4_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v144 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v23 + v40), v142, v143);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE<Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v144, v140);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}