# Kernel and Orchestration Configuration

from pathlib import Path

from simpler.task_interface import ArgDirection as _D

_ROOT_DIR = Path(__file__).parent

# Runtime configuration for tensormap_and_ringbuffer.
# AICPU thread count 0 selects the runtime's architecture default (a2a3: 4; a5: 5).
RUNTIME_CONFIG = {
	"runtime": "tensormap_and_ringbuffer",
	"aicpu_thread_num": 0,
}

ORCHESTRATION = {
	"source": str(_ROOT_DIR / "orchestration" / "decode_fwd.cpp"),
	"function_name": "aicpu_orchestration_entry",
	"signature": [_D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.OUT, _D.IN, _D.IN, _D.OUT, _D.OUT],
}

KERNELS = [
	{"func_id": 0, "name": "token_embed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "token_embed.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.OUT, _D.IN]},
	{"func_id": 1, "name": "paged_attention_tiling_cce", "source": '/mnt/workspace/inductor/pypto-lib/models/qwen3_14b/kernels/paged_attention_cce/tiling/entry.cpp', "core_type": "aiv", "external": True, "extra_include_dirs": ['/home/developer/Ascend/cann-9.1.0/aarch64-linux/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/aicpu_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/impl'], "signature": [_D.IN, _D.INOUT]},
	{"func_id": 2, "name": "copy_hidden", "source": str(_ROOT_DIR / "kernels" / "aiv" / "copy_hidden.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 3, "name": "x_gamma0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "x_gamma0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 4, "name": "attn_out_seed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "attn_out_seed.cpp"), "core_type": "aiv", "signature": [_D.INOUT]},
	{"func_id": 5, "name": "rms_recip", "source": str(_ROOT_DIR / "kernels" / "aiv" / "rms_recip.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.INOUT]},
	{"func_id": 6, "name": "q_seed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "q_seed.cpp"), "core_type": "aiv", "signature": [_D.INOUT]},
	{"func_id": 7, "name": "q_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "q_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 8, "name": "kv_seed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "kv_seed.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT]},
	{"func_id": 9, "name": "mlp_out_seed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "mlp_out_seed.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.INOUT]},
	{"func_id": 10, "name": "k_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "k_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 11, "name": "v_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "v_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 12, "name": "paged_attention_rope_cce_aic", "source": '/mnt/workspace/inductor/pypto-lib/models/qwen3_14b/kernels/paged_attention_cce/attention_rope/entry.cpp', "core_type": "aic", "external": True, "extra_include_dirs": ['/home/developer/Ascend/cann-9.1.0/aarch64-linux/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/aicpu_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/impl', '/mnt/workspace/inductor/pto/pto-isa/include'], "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN]},
	{"func_id": 13, "name": "paged_attention_rope_cce_aiv", "source": '/mnt/workspace/inductor/pypto-lib/models/qwen3_14b/kernels/paged_attention_cce/attention_rope/entry.cpp', "core_type": "aiv", "external": True, "extra_include_dirs": ['/home/developer/Ascend/cann-9.1.0/aarch64-linux/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/impl/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/adv_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/aicpu_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/c_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/basic_api/reg_compute', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/simt_api', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/asc/include/utils', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/interface', '/home/developer/Ascend/cann-9.1.0/aarch64-linux/tikcpp/tikcfw/impl', '/mnt/workspace/inductor/pto/pto-isa/include'], "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN]},
	{"func_id": 14, "name": "out_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "out_proj.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 15, "name": "out_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "out_proj_0.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 16, "name": "residual_rms_cast", "source": str(_ROOT_DIR / "kernels" / "aiv" / "residual_rms_cast.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 17, "name": "residual_rms_cast_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "residual_rms_cast_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 18, "name": "residual_rms_cast_1", "source": str(_ROOT_DIR / "kernels" / "aiv" / "residual_rms_cast_1.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 19, "name": "residual_rms_cast_2", "source": str(_ROOT_DIR / "kernels" / "aiv" / "residual_rms_cast_2.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 20, "name": "residual_rms_cast_3", "source": str(_ROOT_DIR / "kernels" / "aiv" / "residual_rms_cast_3.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 21, "name": "post_rms_reduce", "source": str(_ROOT_DIR / "kernels" / "aiv" / "post_rms_reduce.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 22, "name": "gate_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 23, "name": "up_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 24, "name": "gate_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj_0.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 25, "name": "up_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj_0.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 26, "name": "gate_proj_1", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj_1.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 27, "name": "up_proj_1", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj_1.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 28, "name": "gate_proj_2", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj_2.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 29, "name": "up_proj_2", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj_2.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 30, "name": "gate_proj_3", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj_3.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 31, "name": "up_proj_3", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj_3.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 32, "name": "gate_proj_4", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_proj_4.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 33, "name": "up_proj_4", "source": str(_ROOT_DIR / "kernels" / "aic" / "up_proj_4.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 34, "name": "silu", "source": str(_ROOT_DIR / "kernels" / "aiv" / "silu.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.INOUT, _D.IN, _D.IN]},
	{"func_id": 35, "name": "down_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "down_proj.cpp"), "core_type": "aic", "signature": [_D.IN, _D.IN, _D.INOUT]},
	{"func_id": 36, "name": "dcr_xgamma", "source": str(_ROOT_DIR / "kernels" / "aiv" / "dcr_xgamma.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.IN, _D.INOUT, _D.IN, _D.INOUT]},
	{"func_id": 37, "name": "final_rmsnorm", "source": str(_ROOT_DIR / "kernels" / "aiv" / "final_rmsnorm.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.INOUT, _D.IN]},
	{"func_id": 38, "name": "lm_head", "source": str(_ROOT_DIR / "kernels" / "aic" / "lm_head.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 39, "name": "greedy_sample", "source": str(_ROOT_DIR / "kernels" / "aiv" / "greedy_sample.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.OUT]},
]
