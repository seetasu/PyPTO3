#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void x_gamma0(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, int32_t v4, int32_t v5) {
  SaturationMode v6 = SaturationMode::OFF;
  RoundMode v7 = RoundMode::CAST_ROUND;
  const int64_t v8 = 256;
  const int64_t v9 = 2;
  const int64_t v10 = 4;
  const int64_t v11 = 1024;
  const int64_t v12 = 1;
  const int64_t v13 = 16;
  const int64_t v14 = 33792;
  const int64_t v15 = 17408;
  const int64_t v16 = 16384;
  const int64_t v17 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %t__tmp_v7, %4
  int64_t v18 = (int64_t) ((uint64_t) ((int64_t) v4) * (uint64_t) v11);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t i19 = v17; i19 < v10; i19 += v9) {
    // pto: %5
    int64_t v20 = (int64_t) ((uint64_t) i19 * (uint64_t) v8);
    // pto: %6
    int64_t v21 = (int64_t) ((uint64_t) v18 + (uint64_t) v20);
    // pto: %9, %8
    int64_t v22 = (int64_t) ((uint64_t) v18 + (uint64_t) ((int64_t) ((uint64_t) v20 + (uint64_t) v8)));
    // pto: %x_chunk__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %x_chunk__tile
    uint64_t v24 = (uint64_t) v17;
    TASSIGN(v23, v24);
    // pto: %10
    int64_t v25 = v21 < v17 ? v17 : v21;
    // pto: %cur__rv_v2_pview
    pto::Shape<1, 1, 1, 16, 256> v26 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %cur__rv_v2_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v27 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %cur__rv_v2_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v28 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v17 + v25), v26, v27);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v23, v28);
    // pto: %gamma__tile
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v8);
    // pto: %gamma__tile
    uint64_t v30 = (uint64_t) v16;
    TASSIGN(v29, v30);
    // pto: %input_rms_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 256> v31 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %input_rms_weight__ssa_v0_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v32 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %input_rms_weight__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + (v17 + v25), v31, v32);
    TLOAD(v29, v33);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %0
    uint64_t v35 = (uint64_t) v15;
    TASSIGN(v34, v35);
    // pto: %12
    int64_t v36 = v22 < v17 ? v17 : v22;
    // pto: %13
    pto::Shape<1, 1, 1, 16, 256> v37 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %13
    pto::Stride<81920, 81920, 81920, 5120, 1> v38 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %13
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v17 + v36), v37, v38);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v34, v39);
    // pto: %1
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v8);
    // pto: %1
    uint64_t v41 = (uint64_t) v14;
    TASSIGN(v40, v41);
    // pto: %15
    pto::Shape<1, 1, 1, 1, 256> v42 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %15
    pto::Stride<5120, 5120, 5120, 5120, 1> v43 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %15
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + (v17 + v36), v42, v43);
    TLOAD(v40, v44);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %xg__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %xg__tile
    uint64_t v46 = (uint64_t) v17;
    TASSIGN(v45, v46);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCOLEXPANDMUL(v45, v23, v29);
    // pto: %t__tile
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %t__tile
    uint64_t v48 = (uint64_t) v17;
    TASSIGN(v47, v48);
    pipe_barrier(PIPE_V);
    TCVT(v47, v45, v7, v6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 256> v49 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %normed__iter_v1_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v50 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %normed__iter_v1_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v51 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v17 + v25), v49, v50);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v51, v47);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %2
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %2
    uint64_t v53 = (uint64_t) v15;
    TASSIGN(v52, v53);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPANDMUL(v52, v34, v40);
    // pto: %3
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v8);
    // pto: %3
    uint64_t v55 = (uint64_t) v15;
    TASSIGN(v54, v55);
    pipe_barrier(PIPE_V);
    TCVT(v54, v52, v7, v6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %normed__tile_pview
    pto::Shape<1, 1, 1, 16, 256> v56 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %normed__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v57 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %normed__tile_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v17 + v36), v56, v57);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v58, v54);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}