#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_seed(__gm__ float* v1, __gm__ float* v2) {
  const float v3 = 0.0f;
  const int64_t v4 = 1024;
  const int64_t v5 = 16;
  const int64_t v6 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v7 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v4);
  // pto: %t__tile
  uint64_t v8 = (uint64_t) v6;
  TASSIGN(v7, v8);
  TEXPANDS(v7, v3);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %k_proj_inline1154__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1024> v9 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %k_proj_inline1154__ssa_v0_pview
  pto::Stride<16384, 16384, 16384, 1024, 1> v10 = pto::Stride<16384, 16384, 16384, 1024, 1>();
  // pto: %k_proj_inline1154__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v11 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v1, v9, v10);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v11, v7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %0
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v12 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v4);
  // pto: %0
  uint64_t v13 = (uint64_t) v6;
  TASSIGN(v12, v13);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v12, v3);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %v_proj_inline1249__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1024> v14 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %v_proj_inline1249__ssa_v0_pview
  pto::Stride<16384, 16384, 16384, 1024, 1> v15 = pto::Stride<16384, 16384, 16384, 1024, 1>();
  // pto: %v_proj_inline1249__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v16 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v2, v14, v15);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v16, v12);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}