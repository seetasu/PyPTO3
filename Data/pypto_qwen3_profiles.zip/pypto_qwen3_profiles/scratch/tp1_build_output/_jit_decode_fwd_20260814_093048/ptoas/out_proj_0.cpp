#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void out_proj_0(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  const int64_t v8 = 5120;
  const int64_t v9 = 960;
  const int64_t v10 = 2;
  const int64_t v11 = 15;
  const int64_t v12 = 32;
  const int64_t v13 = 64;
  const int64_t v14 = 512;
  const int64_t v15 = 5;
  const int64_t v16 = 1;
  const int64_t v17 = 16;
  const int64_t v18 = 1024;
  const int64_t v19 = 32768;
  const int64_t v20 = 3072;
  const int64_t v21 = 2048;
  const int64_t v22 = 0;
  const int64_t v23 = 69632;
  const int64_t v24 = 4096;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %21, %t__tile
  int64_t v25 = (int64_t) ((uint64_t) v4 + (uint64_t) ((int64_t) v6));
  // pto: %22, %24
  int64_t v26 = (int64_t) ((uint64_t) (v25 / v15) * (uint64_t) v14);
  // pto: %23, %25
  int64_t v27 = (int64_t) ((uint64_t) (v25 % v15) * (uint64_t) v18);
  // pto: %out_a0_inline1192__tile
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v28 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
  // pto: %out_a0_inline1192__tile
  uint64_t v29 = (uint64_t) v24;
  TASSIGN(v28, v29);
  // pto: %attn_out_inline1226__ssa_v5_pview
  pto::Shape<1, 1, 1, 16, 64> v30 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %attn_out_inline1226__ssa_v5_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v31 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %26, %attn_out_inline1226__ssa_v5_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v32 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v22 + (v27 < v22 ? v22 : v27)), v30, v31);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v28, v32);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %out_w0_inline1173__tile
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %out_w0_inline1173__tile
  uint64_t v34 = (uint64_t) v23;
  TASSIGN(v33, v34);
  // pto: %27
  int64_t v35 = (int64_t) ((uint64_t) v5 + (uint64_t) v27);
  // pto: %29
  int64_t v36 = v26 < v22 ? v22 : v26;
  // pto: %wo__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 512> v37 = pto::Shape<1, 1, 1, 64, 512>();
  // pto: %wo__ssa_v0_pview
  pto::Stride<327680, 327680, 327680, 5120, 1> v38 = pto::Stride<327680, 327680, 327680, 5120, 1>();
  // pto: %28, %wo__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v39 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v22 + (v35 < v22 ? v22 : v35) * v8) + v36), v37, v38);
  TLOAD(v33, v39);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %out_c_acc_inline1240__tile_l0_init
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %out_c_acc_inline1240__tile_l0_init
  uint64_t v41 = (uint64_t) v22;
  TASSIGN(v40, v41);
  // pto: %out_c_acc_inline1240__tile_l0_a
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
  // pto: %out_c_acc_inline1240__tile_l0_a
  uint64_t v43 = (uint64_t) v21;
  TASSIGN(v42, v43);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  TEXTRACT(v42, v28, v22, v22);
  // pto: %out_c_acc_inline1240__tile_l0_b
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
  // pto: %out_c_acc_inline1240__tile_l0_b
  uint64_t v45 = (uint64_t) v22;
  TASSIGN(v44, v45);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  TEXTRACT(v44, v33, v22, v22);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
  // pto: %0
  uint64_t v47 = (uint64_t) v20;
  TASSIGN(v46, v47);
  TEXTRACT(v46, v28, v22, v12);
  // pto: %1
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
  // pto: %1
  uint64_t v49 = (uint64_t) v19;
  TASSIGN(v48, v49);
  TEXTRACT(v48, v33, v12, v22);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %out_c_acc_inline1240__tile_l0_c_first
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %out_c_acc_inline1240__tile_l0_c_first
  uint64_t v51 = (uint64_t) v22;
  TASSIGN(v50, v51);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v50, v42, v44);
  // pto: %out_c_acc_inline1240__tile_l0_c_acc
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %out_c_acc_inline1240__tile_l0_c_acc
  uint64_t v53 = (uint64_t) v22;
  TASSIGN(v52, v53);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v52, v52, v46, v48);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  // pto: %out_c_acc_v1_inline1176__ssa_v0
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %out_c_acc_v1_inline1176__ssa_v0
  uint64_t v55 = (uint64_t) v22;
  TASSIGN(v54, v55);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i56 = v16; i56 < v11; i56 += v10) {
    // pto: %30
    int64_t v57 = (int64_t) ((uint64_t) i56 * (uint64_t) v13);
    // pto: %32
    int64_t v58 = (int64_t) ((uint64_t) v57 + (uint64_t) v13);
    // pto: %out_a_k_inline1184__tile
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
    // pto: %out_a_k_inline1184__tile
    uint64_t v60 = (uint64_t) v22;
    TASSIGN(v59, v60);
    // pto: %33
    int64_t v61 = (int64_t) ((uint64_t) v27 + (uint64_t) v57);
    // pto: %35
    pto::Shape<1, 1, 1, 16, 64> v62 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %35
    pto::Stride<81920, 81920, 81920, 5120, 1> v63 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %34, %35
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v64 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v22 + (v61 < v22 ? v22 : v61)), v62, v63);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v59, v64);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %out_w_k_inline1234__tile
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %out_w_k_inline1234__tile
    uint64_t v66 = (uint64_t) v23;
    TASSIGN(v65, v66);
    // pto: %37
    int64_t v67 = (int64_t) ((uint64_t) v35 + (uint64_t) v57);
    // pto: %40
    pto::Shape<1, 1, 1, 64, 512> v68 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %40
    pto::Stride<327680, 327680, 327680, 5120, 1> v69 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %38, %40
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v22 + (v67 < v22 ? v22 : v67) * v8) + v36), v68, v69);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v65, v70);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %2
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
    // pto: %2
    uint64_t v72 = (uint64_t) v21;
    TASSIGN(v71, v72);
    // pto: %41
    int64_t v73 = (int64_t) ((uint64_t) v27 + (uint64_t) v58);
    // pto: %43
    pto::Shape<1, 1, 1, 16, 64> v74 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %43
    pto::Stride<81920, 81920, 81920, 5120, 1> v75 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %42, %43
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v76 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v22 + (v73 < v22 ? v22 : v73)), v74, v75);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    TLOAD(v71, v76);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    // pto: %3
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %3
    uint64_t v78 = (uint64_t) v24;
    TASSIGN(v77, v78);
    // pto: %45
    int64_t v79 = (int64_t) ((uint64_t) v35 + (uint64_t) v58);
    // pto: %48
    pto::Shape<1, 1, 1, 64, 512> v80 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %48
    pto::Stride<327680, 327680, 327680, 5120, 1> v81 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %46, %48
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v22 + (v79 < v22 ? v22 : v79) * v8) + v36), v80, v81);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v77, v82);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
    // pto: %out_c_acc_v1_inline1176__tile_l0_a
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
    // pto: %out_c_acc_v1_inline1176__tile_l0_a
    uint64_t v84 = (uint64_t) v21;
    TASSIGN(v83, v84);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    TEXTRACT(v83, v59, v22, v22);
    // pto: %out_c_acc_v1_inline1176__tile_l0_b
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
    // pto: %out_c_acc_v1_inline1176__tile_l0_b
    uint64_t v86 = (uint64_t) v22;
    TASSIGN(v85, v86);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v85, v65, v22, v22);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %4
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
    // pto: %4
    uint64_t v88 = (uint64_t) v20;
    TASSIGN(v87, v88);
    TEXTRACT(v87, v59, v22, v12);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %5
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
    // pto: %5
    uint64_t v90 = (uint64_t) v19;
    TASSIGN(v89, v90);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    TEXTRACT(v89, v65, v12, v22);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    // pto: %out_c_acc_v1_inline1176__tile_l0_c_acc
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %out_c_acc_v1_inline1176__tile_l0_c_acc
    uint64_t v92 = (uint64_t) v22;
    TASSIGN(v91, v92);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v91, v91, v83, v85);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %6
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %6
    uint64_t v94 = (uint64_t) v22;
    TASSIGN(v93, v94);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v93, v93, v87, v89);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    // pto: %7
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
    // pto: %7
    uint64_t v96 = (uint64_t) v22;
    TASSIGN(v95, v96);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    TEXTRACT(v95, v71, v22, v22);
    // pto: %8
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
    // pto: %8
    uint64_t v98 = (uint64_t) v22;
    TASSIGN(v97, v98);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
    TEXTRACT(v97, v77, v22, v22);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
    // pto: %9
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
    // pto: %9
    uint64_t v100 = (uint64_t) v18;
    TASSIGN(v99, v100);
    TEXTRACT(v99, v71, v22, v12);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    // pto: %10
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
    // pto: %10
    uint64_t v102 = (uint64_t) v19;
    TASSIGN(v101, v102);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    TEXTRACT(v101, v77, v12, v22);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
    // pto: %11
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %11
    uint64_t v104 = (uint64_t) v22;
    TASSIGN(v103, v104);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v103, v103, v95, v97);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %12
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %12
    uint64_t v106 = (uint64_t) v22;
    TASSIGN(v105, v106);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
    TMATMUL_ACC(v105, v105, v99, v101);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %13
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
  // pto: %13
  uint64_t v108 = (uint64_t) v24;
  TASSIGN(v107, v108);
  // pto: %49
  int64_t v109 = (int64_t) ((uint64_t) v27 + (uint64_t) v9);
  // pto: %51
  pto::Shape<1, 1, 1, 16, 64> v110 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %51
  pto::Stride<81920, 81920, 81920, 5120, 1> v111 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %50, %51
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v112 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v22 + (v109 < v22 ? v22 : v109)), v110, v111);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  TLOAD(v107, v112);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
  // pto: %14
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %14
  uint64_t v114 = (uint64_t) v23;
  TASSIGN(v113, v114);
  // pto: %53
  int64_t v115 = (int64_t) ((uint64_t) v35 + (uint64_t) v9);
  // pto: %56
  pto::Shape<1, 1, 1, 64, 512> v116 = pto::Shape<1, 1, 1, 64, 512>();
  // pto: %56
  pto::Stride<327680, 327680, 327680, 5120, 1> v117 = pto::Stride<327680, 327680, 327680, 5120, 1>();
  // pto: %54, %56
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v118 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v22 + (v115 < v22 ? v22 : v115) * v8) + v36), v116, v117);
  TLOAD(v113, v118);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
  // pto: %15
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
  // pto: %15
  uint64_t v120 = (uint64_t) v21;
  TASSIGN(v119, v120);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
  TEXTRACT(v119, v107, v22, v22);
  // pto: %16
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
  // pto: %16
  uint64_t v122 = (uint64_t) v22;
  TASSIGN(v121, v122);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  TEXTRACT(v121, v113, v22, v22);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
  // pto: %17
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v12);
  // pto: %17
  uint64_t v124 = (uint64_t) v20;
  TASSIGN(v123, v124);
  TEXTRACT(v123, v107, v22, v12);
  // pto: %18
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v12, v14);
  // pto: %18
  uint64_t v126 = (uint64_t) v19;
  TASSIGN(v125, v126);
  TEXTRACT(v125, v113, v12, v22);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
  // pto: %19
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %19
  uint64_t v128 = (uint64_t) v22;
  TASSIGN(v127, v128);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_M);
  TMATMUL_ACC(v127, v127, v119, v121);
  // pto: %20
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %20
  uint64_t v130 = (uint64_t) v22;
  TASSIGN(v129, v130);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
  TMATMUL_ACC(v129, v129, v123, v125);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %out_c_acc_v1_inline1176__rv_v2
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %out_c_acc_v1_inline1176__rv_v2
  uint64_t v132 = (uint64_t) v22;
  TASSIGN(v131, v132);
  // pto: %attn_proj_fp32_inline1210__rv_v5_pview
  pto::Shape<1, 1, 1, 16, 512> v133 = pto::Shape<1, 1, 1, 16, 512>();
  // pto: %attn_proj_fp32_inline1210__rv_v5_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v134 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %attn_proj_fp32_inline1210__rv_v5_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v135 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v3 + (v22 + v36), v133, v134);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE<Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v135, v131);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}