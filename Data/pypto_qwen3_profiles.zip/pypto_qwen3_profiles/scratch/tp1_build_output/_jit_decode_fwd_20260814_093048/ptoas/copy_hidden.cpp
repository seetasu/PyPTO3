#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void copy_hidden(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int64_t v6) {
  SaturationMode v7 = SaturationMode::OFF;
  RoundMode v8 = RoundMode::CAST_ROUND;
  const int64_t v9 = 256;
  const int64_t v10 = 20;
  const int64_t v11 = 1;
  const int64_t v12 = 5120;
  const int64_t v13 = 16;
  const int64_t v14 = 0;
  const int64_t v15 = 8192;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %next_hidden_v1__ssa_v0_view
  int64_t v16 = v6 * v12;
  // pto: %next_hidden_v1__ssa_v0_view
  int64_t v17 = v11 * v16;
  // pto: %next_hidden_v1__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v18 = pto::Shape<1, 1, 1, -1, -1>(v11, v11, v11, v6, v12);
  // pto: %next_hidden_v1__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v19 = pto::Stride<-1, -1, -1, -1, -1>(v11 * v17, v17, v16, v12, v11);
  // pto: %next_hidden_v1__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v20 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v18, v19);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i21 = v14; i21 < v10; i21 += v11) {
    // pto: %2
    int64_t v22 = (int64_t) ((uint64_t) i21 * (uint64_t) v9);
    // pto: %t__tile
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v9);
    // pto: %t__tile
    uint64_t v24 = (uint64_t) v15;
    TASSIGN(v23, v24);
    // pto: %3
    int64_t v25 = (int64_t) ((uint64_t) v3 + (uint64_t) v4);
    // pto: %5
    int64_t v26 = v22 < v14 ? v14 : v22;
    // pto: %next_hidden_v1__ssa_v0_pview
    __gm__ bfloat16_t* v27 = PTOAS__GLOBAL_TENSOR_DATA(v20);
    // pto: %next_hidden_v1__ssa_v0_pview
    int64_t v28 = v5 * v12;
    // pto: %next_hidden_v1__ssa_v0_pview
    int64_t v29 = v11 * v28;
    // pto: %next_hidden_v1__ssa_v0_pview
    pto::Shape<1, 1, 1, -1, 256> v30 = pto::Shape<1, 1, 1, -1, 256>(v11, v11, v11, v5, v9);
    // pto: %next_hidden_v1__ssa_v0_pview
    pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v11 * v29, v29, v28, v12, v11);
    // pto: %4, %next_hidden_v1__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v27 + ((v14 + (v25 < v14 ? v14 : v25) * v12) + v26 * v11), v30, v31);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v23, v32);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v33 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v13, v9);
    // pto: %0
    uint64_t v34 = (uint64_t) v14;
    TASSIGN(v33, v34);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TFILLPAD(v33, v23);
    // pto: %1
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v35 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v13, v9);
    // pto: %1
    uint64_t v36 = (uint64_t) v15;
    TASSIGN(v35, v36);
    pipe_barrier(PIPE_V);
    TCVT(v35, v33, v8, v7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %cur__iter_v3_pview
    pto::Shape<1, 1, 1, 16, 256> v37 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %cur__iter_v3_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v38 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %6, %cur__iter_v3_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + ((v14 + (v4 < v14 ? v14 : v4) * v12) + v26), v37, v38);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v39, v35);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}