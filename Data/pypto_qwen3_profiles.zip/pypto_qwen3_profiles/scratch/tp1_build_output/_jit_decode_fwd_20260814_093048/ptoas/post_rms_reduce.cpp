#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void post_rms_reduce(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3) {
  const float v4 = 9.99999997E-7f;
  const float v5 = 1.95312503E-4f;
  const int64_t v6 = 256;
  const int64_t v7 = 2;
  const int64_t v8 = 20;
  const float v9 = 0.0f;
  const int64_t v10 = 1;
  const int64_t v11 = 16;
  const int64_t v12 = 64;
  const int64_t v13 = 0;
  const int64_t v14 = 49344;
  const int64_t v15 = 32960;
  const int64_t v16 = 16576;
  const int64_t v17 = 192;
  const int64_t v18 = 128;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %sq_sum_inline1325__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
  // pto: %sq_sum_inline1325__tile
  uint64_t v20 = (uint64_t) v18;
  TASSIGN(v19, v20);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TEXPANDS(v19, v9);
  for (int64_t i21 = v13; i21 < v8; i21 += v7) {
    // pto: %14
    int64_t v22 = (int64_t) ((uint64_t) i21 * (uint64_t) v6);
    // pto: %16
    int64_t v23 = (int64_t) ((uint64_t) v22 + (uint64_t) v6);
    // pto: %attn_chunk_inline1362__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v24 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %attn_chunk_inline1362__tile
    uint64_t v25 = (uint64_t) v17;
    TASSIGN(v24, v25);
    // pto: %17
    int64_t v26 = v22 < v13 ? v13 : v22;
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    pto::Shape<1, 1, 1, 16, 256> v27 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v28 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v29 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v13 + v26), v27, v28);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v24, v29);
    // pto: %hidden_chunk_inline1313__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %hidden_chunk_inline1313__tile
    uint64_t v31 = (uint64_t) v16;
    TASSIGN(v30, v31);
    // pto: %cur__iter_v6_pview
    pto::Shape<1, 1, 1, 16, 256> v32 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %cur__iter_v6_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v33 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %cur__iter_v6_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v34 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v13 + v26), v32, v33);
    TLOAD(v30, v34);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %0
    uint64_t v36 = (uint64_t) v15;
    TASSIGN(v35, v36);
    // pto: %19
    int64_t v37 = v23 < v13 ? v13 : v23;
    // pto: %20
    pto::Shape<1, 1, 1, 16, 256> v38 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %20
    pto::Stride<81920, 81920, 81920, 5120, 1> v39 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %20
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v13 + v37), v38, v39);
    TLOAD(v35, v40);
    // pto: %1
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %1
    uint64_t v42 = (uint64_t) v14;
    TASSIGN(v41, v42);
    // pto: %22
    pto::Shape<1, 1, 1, 16, 256> v43 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %22
    pto::Stride<81920, 81920, 81920, 5120, 1> v44 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %22
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v13 + v37), v43, v44);
    TLOAD(v41, v45);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %resid_chunk_inline1356__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %resid_chunk_inline1356__tile
    uint64_t v47 = (uint64_t) v17;
    TASSIGN(v46, v47);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TADD(v46, v24, v30);
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %t__tile
    uint64_t v49 = (uint64_t) v17;
    TASSIGN(v48, v49);
    pipe_barrier(PIPE_V);
    TMUL(v48, v46, v46);
    // pto: %tmp_tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %tmp_tile
    uint64_t v51 = (uint64_t) v16;
    TASSIGN(v50, v51);
    // pto: %2
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v10);
    // pto: %2
    uint64_t v53 = (uint64_t) v13;
    TASSIGN(v52, v53);
    pipe_barrier(PIPE_V);
    TROWSUM(v52, v48, v50);
    // pto: %3
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
    // pto: %3
    uint64_t v55 = (uint64_t) v13;
    TASSIGN(v54, v55);
    // pto: %4
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
    // pto: %4
    uint64_t v57 = (uint64_t) v17;
    TASSIGN(v56, v57);
    pipe_barrier(PIPE_V);
    TADD(v56, v19, v54);
    // pto: %5
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %5
    uint64_t v59 = (uint64_t) v15;
    TASSIGN(v58, v59);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TADD(v58, v35, v41);
    // pto: %6
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %6
    uint64_t v61 = (uint64_t) v15;
    TASSIGN(v60, v61);
    pipe_barrier(PIPE_V);
    TMUL(v60, v58, v58);
    // pto: %7
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v6);
    // pto: %7
    uint64_t v63 = (uint64_t) v14;
    TASSIGN(v62, v63);
    // pto: %8
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v10);
    // pto: %8
    uint64_t v65 = (uint64_t) v12;
    TASSIGN(v64, v65);
    pipe_barrier(PIPE_V);
    TROWSUM(v64, v60, v62);
    // pto: %9
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
    // pto: %9
    uint64_t v67 = (uint64_t) v12;
    TASSIGN(v66, v67);
    // pto: %10
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
    // pto: %10
    uint64_t v69 = (uint64_t) v18;
    TASSIGN(v68, v69);
    pipe_barrier(PIPE_V);
    TADD(v68, v56, v66);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  // pto: %11
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
  // pto: %11
  uint64_t v71 = (uint64_t) v17;
  TASSIGN(v70, v71);
  pipe_barrier(PIPE_V);
  TMULS(v70, v19, v5);
  // pto: %12
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
  // pto: %12
  uint64_t v73 = (uint64_t) v17;
  TASSIGN(v72, v73);
  pipe_barrier(PIPE_V);
  TADDS(v72, v70, v4);
  // pto: %13
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
  // pto: %13
  uint64_t v75 = (uint64_t) v17;
  TASSIGN(v74, v75);
  pipe_barrier(PIPE_V);
  TSQRT(v74, v72);
  // pto: %post_inv_rms_inline1328__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v11);
  // pto: %post_inv_rms_inline1328__tile
  uint64_t v77 = (uint64_t) v16;
  TASSIGN(v76, v77);
  pipe_barrier(PIPE_V);
  TRECIP(v76, v74);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %post_inv_rms_col_inline1146__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v10);
  // pto: %post_inv_rms_col_inline1146__tile
  uint64_t v79 = (uint64_t) v16;
  TASSIGN(v78, v79);
  // pto: %inv_rms_tile_inline1353__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1> v80 = pto::Shape<1, 1, 1, 16, 1>();
  // pto: %inv_rms_tile_inline1353__ssa_v0_pview
  pto::Stride<16, 16, 16, 1, 16> v81 = pto::Stride<16, 16, 16, 1, 16>();
  // pto: %inv_rms_tile_inline1353__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN>(v3, v80, v81);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v82, v78);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}