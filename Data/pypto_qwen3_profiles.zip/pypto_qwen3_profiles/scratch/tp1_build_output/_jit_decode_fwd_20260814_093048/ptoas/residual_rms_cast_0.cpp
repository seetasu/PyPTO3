#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void residual_rms_cast_0(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, int64_t v6, int64_t v7) {
  SaturationMode v8 = SaturationMode::OFF;
  RoundMode v9 = RoundMode::CAST_ROUND;
  const int64_t v10 = 5120;
  const int64_t v11 = 256;
  const int64_t v12 = 2;
  const int64_t v13 = 4;
  const int64_t v14 = 1;
  const int64_t v15 = 16;
  const int64_t v16 = 0;
  const int64_t v17 = 51200;
  const int64_t v18 = 34816;
  const int64_t v19 = 33792;
  const int64_t v20 = 17408;
  const int64_t v21 = 1024;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  for (int64_t i22 = v16; i22 < v13; i22 += v12) {
    // pto: %7
    int64_t v23 = (int64_t) ((uint64_t) i22 * (uint64_t) v11);
    // pto: %8
    int64_t v24 = (int64_t) ((uint64_t) v6 + (uint64_t) v23);
    // pto: %11, %10
    int64_t v25 = (int64_t) ((uint64_t) v6 + (uint64_t) ((int64_t) ((uint64_t) v23 + (uint64_t) v11)));
    // pto: %attn_chunk_inline1362__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v26 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %attn_chunk_inline1362__tile
    uint64_t v27 = (uint64_t) v21;
    TASSIGN(v26, v27);
    // pto: %12
    int64_t v28 = v24 < v16 ? v16 : v24;
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    pto::Shape<1, 1, 1, 16, 256> v29 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v30 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %attn_proj_fp32_inline1210__ssa_v7_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v3 + (v16 + v28), v29, v30);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v26, v31);
    // pto: %hidden_chunk_inline1313__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %hidden_chunk_inline1313__tile
    uint64_t v33 = (uint64_t) v20;
    TASSIGN(v32, v33);
    // pto: %cur__iter_v6_pview
    pto::Shape<1, 1, 1, 16, 256> v34 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %cur__iter_v6_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v35 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %cur__iter_v6_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v36 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v4 + (v16 + v28), v34, v35);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v32, v36);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %post_gamma_inline1319__tile
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %post_gamma_inline1319__tile
    uint64_t v38 = (uint64_t) v19;
    TASSIGN(v37, v38);
    // pto: %14
    int64_t v39 = v7 < v16 ? v16 : v7;
    // pto: %post_rms_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 256> v40 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %post_rms_weight__ssa_v0_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v41 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %post_rms_weight__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v42 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v5 + ((v16 + v39 * v10) + v28), v40, v41);
    TLOAD(v37, v42);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %0
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %0
    uint64_t v44 = (uint64_t) v18;
    TASSIGN(v43, v44);
    // pto: %16
    int64_t v45 = v25 < v16 ? v16 : v25;
    // pto: %17
    pto::Shape<1, 1, 1, 16, 256> v46 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %17
    pto::Stride<81920, 81920, 81920, 5120, 1> v47 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %17
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v3 + (v16 + v45), v46, v47);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v43, v48);
    // pto: %1
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %1
    uint64_t v50 = (uint64_t) v17;
    TASSIGN(v49, v50);
    // pto: %19
    pto::Shape<1, 1, 1, 16, 256> v51 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %19
    pto::Stride<81920, 81920, 81920, 5120, 1> v52 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %19
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v4 + (v16 + v45), v51, v52);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v49, v53);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %2
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %2
    uint64_t v55 = (uint64_t) v16;
    TASSIGN(v54, v55);
    // pto: %22
    pto::Shape<1, 1, 1, 1, 256> v56 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %22
    pto::Stride<5120, 5120, 5120, 5120, 1> v57 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %22
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v58 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v5 + ((v16 + v39 * v10) + v45), v56, v57);
    TLOAD(v54, v58);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %resid_fp32_inline1318__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %resid_fp32_inline1318__tile
    uint64_t v60 = (uint64_t) v21;
    TASSIGN(v59, v60);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TADD(v59, v26, v32);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %t__tile
    uint64_t v62 = (uint64_t) v20;
    TASSIGN(v61, v62);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPANDMUL(v61, v59, v37);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %3
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %3
    uint64_t v64 = (uint64_t) v20;
    TASSIGN(v63, v64);
    pipe_barrier(PIPE_V);
    TCVT(v63, v61, v9, v8);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %post_norm_partial_inline1153__iter_v4_pview
    pto::Shape<1, 1, 1, 16, 256> v65 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %post_norm_partial_inline1153__iter_v4_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v66 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %post_norm_partial_inline1153__iter_v4_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v67 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v28), v65, v66);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v67, v59);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %mlp_norm_in_inline1150__iter_v4_pview
    pto::Shape<1, 1, 1, 16, 256> v68 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %mlp_norm_in_inline1150__iter_v4_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v69 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %mlp_norm_in_inline1150__iter_v4_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v16 + v28), v68, v69);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v70, v63);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %4
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %4
    uint64_t v72 = (uint64_t) v18;
    TASSIGN(v71, v72);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TADD(v71, v43, v49);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %5
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %5
    uint64_t v74 = (uint64_t) v17;
    TASSIGN(v73, v74);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPANDMUL(v73, v71, v54);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %6
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %6
    uint64_t v76 = (uint64_t) v17;
    TASSIGN(v75, v76);
    pipe_barrier(PIPE_V);
    TCVT(v75, v73, v9, v8);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %post_norm_partial_inline1153__tile_pview
    pto::Shape<1, 1, 1, 16, 256> v77 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %post_norm_partial_inline1153__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v78 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %post_norm_partial_inline1153__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v79 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v45), v77, v78);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v79, v71);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %mlp_norm_in_inline1150__tile_pview
    pto::Shape<1, 1, 1, 16, 256> v80 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %mlp_norm_in_inline1150__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v81 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %mlp_norm_in_inline1150__tile_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v16 + v45), v80, v81);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v82, v75);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}