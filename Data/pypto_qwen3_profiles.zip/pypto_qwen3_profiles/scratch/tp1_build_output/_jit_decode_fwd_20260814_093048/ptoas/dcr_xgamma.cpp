#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void dcr_xgamma(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ bfloat16_t* v5, int64_t v6, int32_t v7, int32_t v8) {
  SaturationMode v9 = SaturationMode::OFF;
  RoundMode v10 = RoundMode::CAST_ROUND;
  const int64_t v11 = 5120;
  const int64_t v12 = 1024;
  const int64_t v13 = 1;
  const int64_t v14 = 16;
  const int64_t v15 = 65536;
  const int64_t v16 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %n_out_inline1393__ssa_v1, %2
  int64_t v17 = (int64_t) ((uint64_t) ((int64_t) v7) * (uint64_t) v12);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v18 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %t__tile
  uint64_t v19 = (uint64_t) v16;
  TASSIGN(v18, v19);
  // pto: %3
  int64_t v20 = v17 < v16 ? v16 : v17;
  // pto: %down_acc_all_inline1291__rv_v5_pview
  pto::Shape<1, 1, 1, 16, 1024> v21 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %down_acc_all_inline1291__rv_v5_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v22 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %down_acc_all_inline1291__rv_v5_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v23 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v16 + v20), v21, v22);
  TLOAD(v18, v23);
  // pto: %0
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v24 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %0
  uint64_t v25 = (uint64_t) v15;
  TASSIGN(v24, v25);
  // pto: %post_norm_partial_inline1153__rv_v14_pview
  pto::Shape<1, 1, 1, 16, 1024> v26 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %post_norm_partial_inline1153__rv_v14_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v27 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %post_norm_partial_inline1153__rv_v14_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v28 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v20), v26, v27);
  TLOAD(v24, v28);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %out_chunk_inline1097__tile
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %out_chunk_inline1097__tile
  uint64_t v30 = (uint64_t) v16;
  TASSIGN(v29, v30);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TADD(v29, v18, v24);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %layer_next_hidden__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1024> v31 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %layer_next_hidden__ssa_v0_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v32 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %layer_next_hidden__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v3 + (v16 + v20), v31, v32);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v33, v29);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %gamma_next_inline1104__tile
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %gamma_next_inline1104__tile
  uint64_t v35 = (uint64_t) v15;
  TASSIGN(v34, v35);
  // pto: %input_rms_weight__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1024> v36 = pto::Shape<1, 1, 1, 1, 1024>();
  // pto: %input_rms_weight__ssa_v0_pview
  pto::Stride<5120, 5120, 5120, 5120, 1> v37 = pto::Stride<5120, 5120, 5120, 5120, 1>();
  // pto: %6, %input_rms_weight__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v4 + ((v16 + (v6 < v16 ? v16 : v6) * v11) + v20), v36, v37);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v34, v38);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %xg_inline1096__tile
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %xg_inline1096__tile
  uint64_t v40 = (uint64_t) v16;
  TASSIGN(v39, v40);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TCOLEXPANDMUL(v39, v29, v34);
  // pto: %1
  Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %1
  uint64_t v42 = (uint64_t) v16;
  TASSIGN(v41, v42);
  pipe_barrier(PIPE_V);
  TCVT(v41, v39, v10, v9);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %next_normed__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1024> v43 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %next_normed__ssa_v0_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v44 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %next_normed__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v45 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v5 + (v16 + v20), v43, v44);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v45, v41);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}