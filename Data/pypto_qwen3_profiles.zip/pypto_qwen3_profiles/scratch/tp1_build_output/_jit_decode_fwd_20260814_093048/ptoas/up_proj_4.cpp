#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void up_proj_4(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6) {
  const int64_t v7 = 17408;
  const int64_t v8 = 960;
  const int64_t v9 = 2;
  const int64_t v10 = 15;
  const int64_t v11 = 32;
  const int64_t v12 = 64;
  const int64_t v13 = 1;
  const int64_t v14 = 16;
  const int64_t v15 = 512;
  const int64_t v16 = 2048;
  const int64_t v17 = 32768;
  const int64_t v18 = 1536;
  const int64_t v19 = 1024;
  const int64_t v20 = 0;
  const int64_t v21 = 135168;
  const int64_t v22 = 4096;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c_acc_v1_inline1174__tile_l0_c_phi
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
  // pto: %c_acc_v1_inline1174__tile_l0_c_phi
  uint64_t v24 = (uint64_t) v20;
  TASSIGN(v23, v24);
  // pto: %a0_v1_inline1376__tile
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %a0_v1_inline1376__tile
  uint64_t v26 = (uint64_t) v22;
  TASSIGN(v25, v26);
  // pto: %mlp_norm_in_inline1150__rv_v14_pview
  pto::Shape<1, 1, 1, 16, 64> v27 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %mlp_norm_in_inline1150__rv_v14_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v28 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %25, %mlp_norm_in_inline1150__rv_v14_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v29 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v4 < v20 ? v20 : v4)), v27, v28);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  TLOAD(v25, v29);
  // pto: %w0_v1_inline1327__tile
  Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v19);
  // pto: %w0_v1_inline1327__tile
  uint64_t v31 = (uint64_t) v21;
  TASSIGN(v30, v31);
  // pto: %26
  int64_t v32 = (int64_t) ((uint64_t) v5 + (uint64_t) v4);
  // pto: %28
  int64_t v33 = v6 < v20 ? v20 : v6;
  // pto: %w_up__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 1024> v34 = pto::Shape<1, 1, 1, 64, 1024>();
  // pto: %w_up__ssa_v0_pview
  pto::Stride<1114112, 1114112, 1114112, 17408, 1> v35 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
  // pto: %27, %w_up__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v36 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v20 + (v32 < v20 ? v20 : v32) * v7) + v33), v34, v35);
  TLOAD(v30, v36);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %c_acc_v1_inline1174__tile_l0_init
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
  // pto: %c_acc_v1_inline1174__tile_l0_init
  uint64_t v38 = (uint64_t) v20;
  TASSIGN(v37, v38);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t i39 = v20; i39 < v12; i39 += v11) {
    // pto: %c_acc_v1_inline1174__tile_l0_a
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %c_acc_v1_inline1174__tile_l0_a
    uint64_t v41 = (uint64_t) v19;
    TASSIGN(v40, v41);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    pipe_barrier(PIPE_MTE1);
    TEXTRACT(v40, v25, v20, i39);
    // pto: %c_acc_v1_inline1174__tile_l0_b
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %c_acc_v1_inline1174__tile_l0_b
    uint64_t v43 = (uint64_t) v20;
    TASSIGN(v42, v43);
    TEXTRACT(v42, v30, i39, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %0
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %0
    uint64_t v45 = (uint64_t) v18;
    TASSIGN(v44, v45);
    // pto: %29
    int64_t v46 = (int64_t) ((uint64_t) i39 + (uint64_t) v14);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v44, v25, v20, v46);
    // pto: %1
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %1
    uint64_t v48 = (uint64_t) v17;
    TASSIGN(v47, v48);
    TEXTRACT(v47, v30, v46, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %31
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (i39 == v20) {
      // pto: %c_acc_v1_inline1174__tile_l0_c_first
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %c_acc_v1_inline1174__tile_l0_c_first
      uint64_t v50 = (uint64_t) v20;
      TASSIGN(v49, v50);
      pipe_barrier(PIPE_M);
      TMATMUL(v49, v40, v42);
    } else {
      // pto: %c_acc_v1_inline1174__tile_l0_c_acc
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %c_acc_v1_inline1174__tile_l0_c_acc
      uint64_t v52 = (uint64_t) v20;
      TASSIGN(v51, v52);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v51, v51, v40, v42);
    }
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %2
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %2
    uint64_t v54 = (uint64_t) v20;
    TASSIGN(v53, v54);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v53, v53, v44, v47);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  for (int64_t i55 = v13; i55 < v10; i55 += v9) {
    // pto: %32
    int64_t v56 = (int64_t) ((uint64_t) i55 * (uint64_t) v12);
    // pto: %34
    int64_t v57 = (int64_t) ((uint64_t) v56 + (uint64_t) v12);
    // pto: %a_k_inline1311__tile
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v12);
    // pto: %a_k_inline1311__tile
    uint64_t v59 = (uint64_t) v20;
    TASSIGN(v58, v59);
    // pto: %35
    int64_t v60 = (int64_t) ((uint64_t) v4 + (uint64_t) v56);
    // pto: %37
    pto::Shape<1, 1, 1, 16, 64> v61 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %37
    pto::Stride<81920, 81920, 81920, 5120, 1> v62 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %36, %37
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v63 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v60 < v20 ? v20 : v60)), v61, v62);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v58, v63);
    // pto: %w_k_inline1288__tile
    Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v19);
    // pto: %w_k_inline1288__tile
    uint64_t v65 = (uint64_t) v21;
    TASSIGN(v64, v65);
    // pto: %39
    int64_t v66 = (int64_t) ((uint64_t) v32 + (uint64_t) v56);
    // pto: %42
    pto::Shape<1, 1, 1, 64, 1024> v67 = pto::Shape<1, 1, 1, 64, 1024>();
    // pto: %42
    pto::Stride<1114112, 1114112, 1114112, 17408, 1> v68 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
    // pto: %40, %42
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v20 + (v66 < v20 ? v20 : v66) * v7) + v33), v67, v68);
    TLOAD(v64, v69);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %3
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v12);
    // pto: %3
    uint64_t v71 = (uint64_t) v16;
    TASSIGN(v70, v71);
    // pto: %43
    int64_t v72 = (int64_t) ((uint64_t) v4 + (uint64_t) v57);
    // pto: %45
    pto::Shape<1, 1, 1, 16, 64> v73 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %45
    pto::Stride<81920, 81920, 81920, 5120, 1> v74 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %44, %45
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v75 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v72 < v20 ? v20 : v72)), v73, v74);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v70, v75);
    // pto: %4
    Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v19);
    // pto: %4
    uint64_t v77 = (uint64_t) v22;
    TASSIGN(v76, v77);
    // pto: %47
    int64_t v78 = (int64_t) ((uint64_t) v32 + (uint64_t) v57);
    // pto: %50
    pto::Shape<1, 1, 1, 64, 1024> v79 = pto::Shape<1, 1, 1, 64, 1024>();
    // pto: %50
    pto::Stride<1114112, 1114112, 1114112, 17408, 1> v80 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
    // pto: %48, %50
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v81 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v20 + (v78 < v20 ? v20 : v78) * v7) + v33), v79, v80);
    TLOAD(v76, v81);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j82 = v20; j82 < v12; j82 += v11) {
      // pto: %5
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %5
      uint64_t v84 = (uint64_t) v19;
      TASSIGN(v83, v84);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TEXTRACT(v83, v58, v20, j82);
      // pto: %6
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %6
      uint64_t v86 = (uint64_t) v20;
      TASSIGN(v85, v86);
      TEXTRACT(v85, v64, j82, v20);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %7
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %7
      uint64_t v88 = (uint64_t) v18;
      TASSIGN(v87, v88);
      // pto: %52
      int64_t v89 = (int64_t) ((uint64_t) j82 + (uint64_t) v14);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TEXTRACT(v87, v58, v20, v89);
      // pto: %8
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %8
      uint64_t v91 = (uint64_t) v17;
      TASSIGN(v90, v91);
      TEXTRACT(v90, v64, v89, v20);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      // pto: %9
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %9
      uint64_t v93 = (uint64_t) v20;
      TASSIGN(v92, v93);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v92, v92, v83, v85);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      // pto: %10
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %10
      uint64_t v95 = (uint64_t) v20;
      TASSIGN(v94, v95);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v94, v94, v87, v90);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    for (int64_t j96 = v20; j96 < v12; j96 += v11) {
      // pto: %11
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %11
      uint64_t v98 = (uint64_t) v20;
      TASSIGN(v97, v98);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      TEXTRACT(v97, v70, v20, j96);
      // pto: %12
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %12
      uint64_t v100 = (uint64_t) v20;
      TASSIGN(v99, v100);
      TEXTRACT(v99, v76, j96, v20);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      // pto: %13
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %13
      uint64_t v102 = (uint64_t) v15;
      TASSIGN(v101, v102);
      // pto: %55
      int64_t v103 = (int64_t) ((uint64_t) j96 + (uint64_t) v14);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TEXTRACT(v101, v70, v20, v103);
      // pto: %14
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %14
      uint64_t v105 = (uint64_t) v17;
      TASSIGN(v104, v105);
      TEXTRACT(v104, v76, v103, v20);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      // pto: %15
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %15
      uint64_t v107 = (uint64_t) v20;
      TASSIGN(v106, v107);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v106, v106, v97, v99);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      // pto: %16
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
      // pto: %16
      uint64_t v109 = (uint64_t) v20;
      TASSIGN(v108, v109);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v108, v108, v101, v104);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %17
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v12);
  // pto: %17
  uint64_t v111 = (uint64_t) v22;
  TASSIGN(v110, v111);
  // pto: %57
  int64_t v112 = (int64_t) ((uint64_t) v4 + (uint64_t) v8);
  // pto: %59
  pto::Shape<1, 1, 1, 16, 64> v113 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %59
  pto::Stride<81920, 81920, 81920, 5120, 1> v114 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %58, %59
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v112 < v20 ? v20 : v112)), v113, v114);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  TLOAD(v110, v115);
  // pto: %18
  Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v19);
  // pto: %18
  uint64_t v117 = (uint64_t) v21;
  TASSIGN(v116, v117);
  // pto: %61
  int64_t v118 = (int64_t) ((uint64_t) v32 + (uint64_t) v8);
  // pto: %64
  pto::Shape<1, 1, 1, 64, 1024> v119 = pto::Shape<1, 1, 1, 64, 1024>();
  // pto: %64
  pto::Stride<1114112, 1114112, 1114112, 17408, 1> v120 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
  // pto: %62, %64
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v20 + (v118 < v20 ? v20 : v118) * v7) + v33), v119, v120);
  TLOAD(v116, v121);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t i122 = v20; i122 < v12; i122 += v11) {
    // pto: %19
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %19
    uint64_t v124 = (uint64_t) v19;
    TASSIGN(v123, v124);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TEXTRACT(v123, v110, v20, i122);
    // pto: %20
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %20
    uint64_t v126 = (uint64_t) v20;
    TASSIGN(v125, v126);
    TEXTRACT(v125, v116, i122, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
    // pto: %21
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %21
    uint64_t v128 = (uint64_t) v18;
    TASSIGN(v127, v128);
    // pto: %66
    int64_t v129 = (int64_t) ((uint64_t) i122 + (uint64_t) v14);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v127, v110, v20, v129);
    // pto: %22
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %22
    uint64_t v131 = (uint64_t) v17;
    TASSIGN(v130, v131);
    TEXTRACT(v130, v116, v129, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
    // pto: %23
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %23
    uint64_t v133 = (uint64_t) v20;
    TASSIGN(v132, v133);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v132, v132, v123, v125);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %24
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
    // pto: %24
    uint64_t v135 = (uint64_t) v20;
    TASSIGN(v134, v135);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
    TMATMUL_ACC(v134, v134, v127, v130);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %c_acc_v1_inline1174__rv_v2
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v19);
  // pto: %c_acc_v1_inline1174__rv_v2
  uint64_t v137 = (uint64_t) v20;
  TASSIGN(v136, v137);
  // pto: %up_acc_all_inline1247__iter_v11_pview
  pto::Shape<1, 1, 1, 16, 1024> v138 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %up_acc_all_inline1247__iter_v11_pview
  pto::Stride<278528, 278528, 278528, 17408, 1> v139 = pto::Stride<278528, 278528, 278528, 17408, 1>();
  // pto: %up_acc_all_inline1247__iter_v11_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v20 + v33), v138, v139);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE<Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v140, v136);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}