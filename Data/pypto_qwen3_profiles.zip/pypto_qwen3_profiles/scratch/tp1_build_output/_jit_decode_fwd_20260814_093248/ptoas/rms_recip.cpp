#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rms_recip(__gm__ float* v1, __gm__ float* v2) {
  const float v3 = 9.99999997E-7f;
  const float v4 = 1.95312503E-4f;
  const int64_t v5 = 768;
  const int64_t v6 = 512;
  const int64_t v7 = 256;
  const int64_t v8 = 4;
  const int64_t v9 = 20;
  const float v10 = 0.0f;
  const int64_t v11 = 1;
  const int64_t v12 = 16;
  const int64_t v13 = 49344;
  const int64_t v14 = 32960;
  const int64_t v15 = 32832;
  const int64_t v16 = 16448;
  const int64_t v17 = 16384;
  const int64_t v18 = 0;
  const int64_t v19 = 131328;
  const int64_t v20 = 114944;
  const int64_t v21 = 98560;
  const int64_t v22 = 82176;
  const int64_t v23 = 65792;
  const int64_t v24 = 49408;
  const int64_t v25 = 32896;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %partial_sq_inline1162__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v26 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %partial_sq_inline1162__tile
  uint64_t v27 = (uint64_t) v25;
  TASSIGN(v26, v27);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  TEXPANDS(v26, v10);
  for (int64_t i28 = v18; i28 < v9; i28 += v8) {
    // pto: %24
    int64_t v29 = (int64_t) ((uint64_t) i28 * (uint64_t) v7);
    // pto: %26
    int64_t v30 = (int64_t) ((uint64_t) v29 + (uint64_t) v7);
    // pto: %28
    int64_t v31 = (int64_t) ((uint64_t) v29 + (uint64_t) v6);
    // pto: %30
    int64_t v32 = (int64_t) ((uint64_t) v29 + (uint64_t) v5);
    // pto: %x_chunk_inline1255__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %x_chunk_inline1255__tile
    uint64_t v34 = (uint64_t) v24;
    TASSIGN(v33, v34);
    // pto: %cur__iter_v6_pview
    pto::Shape<1, 1, 1, 16, 256> v35 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %cur__iter_v6_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v36 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %31, %cur__iter_v6_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v37 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v18 + (v29 < v18 ? v18 : v29)), v35, v36);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v33, v37);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %0
    uint64_t v39 = (uint64_t) v23;
    TASSIGN(v38, v39);
    // pto: %33
    pto::Shape<1, 1, 1, 16, 256> v40 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %33
    pto::Stride<81920, 81920, 81920, 5120, 1> v41 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %32, %33
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v42 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v18 + (v30 < v18 ? v18 : v30)), v40, v41);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v38, v42);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %1
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %1
    uint64_t v44 = (uint64_t) v22;
    TASSIGN(v43, v44);
    // pto: %35
    pto::Shape<1, 1, 1, 16, 256> v45 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %35
    pto::Stride<81920, 81920, 81920, 5120, 1> v46 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %34, %35
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v18 + (v31 < v18 ? v18 : v31)), v45, v46);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v43, v47);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %2
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %2
    uint64_t v49 = (uint64_t) v21;
    TASSIGN(v48, v49);
    // pto: %37
    pto::Shape<1, 1, 1, 16, 256> v50 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %37
    pto::Stride<81920, 81920, 81920, 5120, 1> v51 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %36, %37
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v52 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v18 + (v32 < v18 ? v18 : v32)), v50, v51);
    TLOAD(v48, v52);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %t__tile
    uint64_t v54 = (uint64_t) v24;
    TASSIGN(v53, v54);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TMUL(v53, v33, v33);
    // pto: %tmp_tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %tmp_tile
    uint64_t v56 = (uint64_t) v20;
    TASSIGN(v55, v56);
    // pto: %3
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %3
    uint64_t v58 = (uint64_t) v19;
    TASSIGN(v57, v58);
    pipe_barrier(PIPE_V);
    TROWSUM(v57, v53, v55);
    // pto: %4
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %4
    uint64_t v60 = (uint64_t) v19;
    TASSIGN(v59, v60);
    // pto: %5
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %5
    uint64_t v62 = (uint64_t) v24;
    TASSIGN(v61, v62);
    pipe_barrier(PIPE_V);
    TADD(v61, v26, v59);
    // pto: %6
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %6
    uint64_t v64 = (uint64_t) v23;
    TASSIGN(v63, v64);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TMUL(v63, v38, v38);
    // pto: %7
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %7
    uint64_t v66 = (uint64_t) v18;
    TASSIGN(v65, v66);
    // pto: %8
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %8
    uint64_t v68 = (uint64_t) v17;
    TASSIGN(v67, v68);
    pipe_barrier(PIPE_V);
    TROWSUM(v67, v63, v65);
    // pto: %9
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %9
    uint64_t v70 = (uint64_t) v17;
    TASSIGN(v69, v70);
    // pto: %10
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %10
    uint64_t v72 = (uint64_t) v23;
    TASSIGN(v71, v72);
    pipe_barrier(PIPE_V);
    TADD(v71, v61, v69);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %11
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %11
    uint64_t v74 = (uint64_t) v22;
    TASSIGN(v73, v74);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TMUL(v73, v43, v43);
    // pto: %12
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %12
    uint64_t v76 = (uint64_t) v16;
    TASSIGN(v75, v76);
    // pto: %13
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %13
    uint64_t v78 = (uint64_t) v15;
    TASSIGN(v77, v78);
    pipe_barrier(PIPE_V);
    TROWSUM(v77, v73, v75);
    // pto: %14
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %14
    uint64_t v80 = (uint64_t) v15;
    TASSIGN(v79, v80);
    // pto: %15
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %15
    uint64_t v82 = (uint64_t) v22;
    TASSIGN(v81, v82);
    pipe_barrier(PIPE_V);
    TADD(v81, v71, v79);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %16
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %16
    uint64_t v84 = (uint64_t) v21;
    TASSIGN(v83, v84);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TMUL(v83, v48, v48);
    // pto: %17
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v7);
    // pto: %17
    uint64_t v86 = (uint64_t) v14;
    TASSIGN(v85, v86);
    // pto: %18
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %18
    uint64_t v88 = (uint64_t) v13;
    TASSIGN(v87, v88);
    pipe_barrier(PIPE_V);
    TROWSUM(v87, v83, v85);
    // pto: %19
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %19
    uint64_t v90 = (uint64_t) v13;
    TASSIGN(v89, v90);
    // pto: %20
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %20
    uint64_t v92 = (uint64_t) v25;
    TASSIGN(v91, v92);
    pipe_barrier(PIPE_V);
    TADD(v91, v81, v89);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  }
  // pto: %21
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %21
  uint64_t v94 = (uint64_t) v24;
  TASSIGN(v93, v94);
  pipe_barrier(PIPE_V);
  TMULS(v93, v26, v4);
  // pto: %22
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %22
  uint64_t v96 = (uint64_t) v24;
  TASSIGN(v95, v96);
  pipe_barrier(PIPE_V);
  TADDS(v95, v93, v3);
  // pto: %variance_inline1271__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
  // pto: %variance_inline1271__tile
  uint64_t v98 = (uint64_t) v24;
  TASSIGN(v97, v98);
  // pto: %t__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %t__rm_a0_tmp_v0
  uint64_t v100 = (uint64_t) v24;
  TASSIGN(v99, v100);
  // pto: %t__row_major_tmp_v1
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %t__row_major_tmp_v1
  uint64_t v102 = (uint64_t) v24;
  TASSIGN(v101, v102);
  pipe_barrier(PIPE_V);
  TSQRT(v101, v99);
  // pto: %23
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
  // pto: %23
  uint64_t v104 = (uint64_t) v24;
  TASSIGN(v103, v104);
  // pto: %inv_rms_inline1305__rm_a0_tmp_v2
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %inv_rms_inline1305__rm_a0_tmp_v2
  uint64_t v106 = (uint64_t) v24;
  TASSIGN(v105, v106);
  // pto: %inv_rms_inline1305__row_major_tmp_v3
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %inv_rms_inline1305__row_major_tmp_v3
  uint64_t v108 = (uint64_t) v23;
  TASSIGN(v107, v108);
  pipe_barrier(PIPE_V);
  TRECIP(v107, v105);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %inv_rms_inline1305__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
  // pto: %inv_rms_inline1305__tile
  uint64_t v110 = (uint64_t) v23;
  TASSIGN(v109, v110);
  // pto: %inv_rms_states_inline1228__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1> v111 = pto::Shape<1, 1, 1, 16, 1>();
  // pto: %inv_rms_states_inline1228__ssa_v0_pview
  pto::Stride<16, 16, 16, 1, 16> v112 = pto::Stride<16, 16, 16, 1, 16>();
  // pto: %inv_rms_states_inline1228__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN> v113 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN>(v2, v111, v112);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v113, v109);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}