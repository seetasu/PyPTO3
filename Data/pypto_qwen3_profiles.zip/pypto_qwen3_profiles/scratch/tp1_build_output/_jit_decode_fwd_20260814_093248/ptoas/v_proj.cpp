#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void v_proj(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int32_t v5, int32_t v6) {
  const int64_t v7 = 768;
  const int64_t v8 = 64;
  const int64_t v9 = 128;
  const int64_t v10 = 256;
  const int64_t v11 = 2;
  const int64_t v12 = 512;
  const int64_t v13 = 5;
  const int64_t v14 = 1;
  const int64_t v15 = 1024;
  const int64_t v16 = 16;
  const int64_t v17 = 2048;
  const int64_t v18 = 8192;
  const int64_t v19 = 32768;
  const int64_t v20 = 6144;
  const int64_t v21 = 4096;
  const int64_t v22 = 0;
  const int64_t v23 = 147456;
  const int64_t v24 = 16384;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %v_acc_inline1231__tile_l0_c_phi
  Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
  // pto: %v_acc_inline1231__tile_l0_c_phi
  uint64_t v26 = (uint64_t) v22;
  TASSIGN(v25, v26);
  // pto: %v_blk_inline1244__tile
  int64_t v27 = (int64_t) v5;
  // pto: %29, %31
  int64_t v28 = (int64_t) ((uint64_t) (v27 % v13) * (uint64_t) v15);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i29 = v22; i29 < v11; i29 += v14) {
    // pto: %28, %30, %33, %32
    int64_t v30 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) (v27 / v13) * (uint64_t) v12)) + (uint64_t) ((int64_t) ((uint64_t) i29 * (uint64_t) v10)));
    // pto: %t__tile
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %t__tile
    uint64_t v32 = (uint64_t) v24;
    TASSIGN(v31, v32);
    // pto: %normed__iter_v4_pview
    pto::Shape<1, 1, 1, 16, 256> v33 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %normed__iter_v4_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v34 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %34, %normed__iter_v4_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v35 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v28 < v22 ? v22 : v28)), v33, v34);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v31, v35);
    // pto: %0
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %0
    uint64_t v37 = (uint64_t) v23;
    TASSIGN(v36, v37);
    // pto: %35
    int64_t v38 = (int64_t) ((uint64_t) v4 + (uint64_t) v28);
    // pto: %37
    int64_t v39 = v30 < v22 ? v22 : v30;
    // pto: %wv__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v40 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wv__ssa_v0_pview
    pto::Stride<262144, 262144, 262144, 1024, 1> v41 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %36, %wv__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v42 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v3 + ((v22 + (v38 < v22 ? v22 : v38) * v15) + v39), v40, v41);
    TLOAD(v36, v42);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %v_acc_inline1231__tile_l0_init
    Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %v_acc_inline1231__tile_l0_init
    uint64_t v44 = (uint64_t) v22;
    TASSIGN(v43, v44);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j45 = v22; j45 < v10; j45 += v9) {
      // pto: %v_acc_inline1231__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %v_acc_inline1231__tile_l0_a
      uint64_t v47 = (uint64_t) v21;
      TASSIGN(v46, v47);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v46, v31, v22, j45);
      // pto: %v_acc_inline1231__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %v_acc_inline1231__tile_l0_b
      uint64_t v49 = (uint64_t) v22;
      TASSIGN(v48, v49);
      TEXTRACT(v48, v36, j45, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %1
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %1
      uint64_t v51 = (uint64_t) v20;
      TASSIGN(v50, v51);
      // pto: %38
      int64_t v52 = (int64_t) ((uint64_t) j45 + (uint64_t) v8);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v50, v31, v22, v52);
      // pto: %2
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %2
      uint64_t v54 = (uint64_t) v19;
      TASSIGN(v53, v54);
      TEXTRACT(v53, v36, v52, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %40
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j45 == v22) {
        // pto: %v_acc_inline1231__tile_l0_c_first
        Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
        // pto: %v_acc_inline1231__tile_l0_c_first
        uint64_t v56 = (uint64_t) v22;
        TASSIGN(v55, v56);
        pipe_barrier(PIPE_M);
        TMATMUL(v55, v46, v48);
      } else {
        // pto: %v_acc_inline1231__tile_l0_c_acc
        Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
        // pto: %v_acc_inline1231__tile_l0_c_acc
        uint64_t v58 = (uint64_t) v22;
        TASSIGN(v57, v58);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v57, v57, v46, v48);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %3
      uint64_t v60 = (uint64_t) v22;
      TASSIGN(v59, v60);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v59, v59, v50, v53);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %41
    int64_t v61 = (int64_t) ((uint64_t) v28 + (uint64_t) v10);
    // pto: %42
    int64_t v62 = (int64_t) ((uint64_t) v28 + (uint64_t) v12);
    // pto: %4
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %4
    uint64_t v64 = (uint64_t) v22;
    TASSIGN(v63, v64);
    // pto: %44
    pto::Shape<1, 1, 1, 16, 256> v65 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %44
    pto::Stride<81920, 81920, 81920, 5120, 1> v66 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %43, %44
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v67 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v61 < v22 ? v22 : v61)), v65, v66);
    TLOAD(v63, v67);
    // pto: %5
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %5
    uint64_t v69 = (uint64_t) v23;
    TASSIGN(v68, v69);
    // pto: %45
    int64_t v70 = (int64_t) ((uint64_t) v4 + (uint64_t) v61);
    // pto: %48
    pto::Shape<1, 1, 1, 256, 256> v71 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %48
    pto::Stride<262144, 262144, 262144, 1024, 1> v72 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %46, %48
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v3 + ((v22 + (v70 < v22 ? v22 : v70) * v15) + v39), v71, v72);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v68, v73);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %6
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %6
    uint64_t v75 = (uint64_t) v18;
    TASSIGN(v74, v75);
    // pto: %50
    pto::Shape<1, 1, 1, 16, 256> v76 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %50
    pto::Stride<81920, 81920, 81920, 5120, 1> v77 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %49, %50
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v78 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v62 < v22 ? v22 : v62)), v76, v77);
    TLOAD(v74, v78);
    // pto: %7
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %7
    uint64_t v80 = (uint64_t) v24;
    TASSIGN(v79, v80);
    // pto: %51
    int64_t v81 = (int64_t) ((uint64_t) v4 + (uint64_t) v62);
    // pto: %54
    pto::Shape<1, 1, 1, 256, 256> v82 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %54
    pto::Stride<262144, 262144, 262144, 1024, 1> v83 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %52, %54
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v84 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v3 + ((v22 + (v81 < v22 ? v22 : v81) * v15) + v39), v82, v83);
    TLOAD(v79, v84);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j85 = v22; j85 < v10; j85 += v9) {
      // pto: %8
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %8
      uint64_t v87 = (uint64_t) v21;
      TASSIGN(v86, v87);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TEXTRACT(v86, v63, v22, j85);
      // pto: %9
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %9
      uint64_t v89 = (uint64_t) v22;
      TASSIGN(v88, v89);
      TEXTRACT(v88, v68, j85, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %10
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %10
      uint64_t v91 = (uint64_t) v20;
      TASSIGN(v90, v91);
      // pto: %56
      int64_t v92 = (int64_t) ((uint64_t) j85 + (uint64_t) v8);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TEXTRACT(v90, v63, v22, v92);
      // pto: %11
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %11
      uint64_t v94 = (uint64_t) v19;
      TASSIGN(v93, v94);
      TEXTRACT(v93, v68, v92, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      // pto: %12
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %12
      uint64_t v96 = (uint64_t) v22;
      TASSIGN(v95, v96);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v95, v95, v86, v88);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      // pto: %13
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %13
      uint64_t v98 = (uint64_t) v22;
      TASSIGN(v97, v98);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v97, v97, v90, v93);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    for (int64_t j99 = v22; j99 < v10; j99 += v9) {
      // pto: %14
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %14
      uint64_t v101 = (uint64_t) v22;
      TASSIGN(v100, v101);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      TEXTRACT(v100, v74, v22, j99);
      // pto: %15
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %15
      uint64_t v103 = (uint64_t) v22;
      TASSIGN(v102, v103);
      TEXTRACT(v102, v79, j99, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      // pto: %16
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %16
      uint64_t v105 = (uint64_t) v17;
      TASSIGN(v104, v105);
      // pto: %59
      int64_t v106 = (int64_t) ((uint64_t) j99 + (uint64_t) v8);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v104, v74, v22, v106);
      // pto: %17
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %17
      uint64_t v108 = (uint64_t) v19;
      TASSIGN(v107, v108);
      TEXTRACT(v107, v79, v106, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      // pto: %18
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %18
      uint64_t v110 = (uint64_t) v22;
      TASSIGN(v109, v110);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v109, v109, v100, v102);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      // pto: %19
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %19
      uint64_t v112 = (uint64_t) v22;
      TASSIGN(v111, v112);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v111, v111, v104, v107);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %61
    int64_t v113 = (int64_t) ((uint64_t) v28 + (uint64_t) v7);
    // pto: %20
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %20
    uint64_t v115 = (uint64_t) v24;
    TASSIGN(v114, v115);
    // pto: %63
    pto::Shape<1, 1, 1, 16, 256> v116 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %63
    pto::Stride<81920, 81920, 81920, 5120, 1> v117 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %62, %63
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v118 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + (v22 + (v113 < v22 ? v22 : v113)), v116, v117);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v114, v118);
    // pto: %21
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %21
    uint64_t v120 = (uint64_t) v23;
    TASSIGN(v119, v120);
    // pto: %64
    int64_t v121 = (int64_t) ((uint64_t) v4 + (uint64_t) v113);
    // pto: %67
    pto::Shape<1, 1, 1, 256, 256> v122 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %67
    pto::Stride<262144, 262144, 262144, 1024, 1> v123 = pto::Stride<262144, 262144, 262144, 1024, 1>();
    // pto: %65, %67
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND> v124 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<262144, 262144, 262144, 1024, 1>, pto::Layout::ND>(v3 + ((v22 + (v121 < v22 ? v22 : v121) * v15) + v39), v122, v123);
    TLOAD(v119, v124);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j125 = v22; j125 < v10; j125 += v9) {
      // pto: %22
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %22
      uint64_t v127 = (uint64_t) v21;
      TASSIGN(v126, v127);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v126, v114, v22, j125);
      // pto: %23
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %23
      uint64_t v129 = (uint64_t) v22;
      TASSIGN(v128, v129);
      TEXTRACT(v128, v119, j125, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %24
      Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Left, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v8);
      // pto: %24
      uint64_t v131 = (uint64_t) v20;
      TASSIGN(v130, v131);
      // pto: %69
      int64_t v132 = (int64_t) ((uint64_t) j125 + (uint64_t) v8);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v130, v114, v22, v132);
      // pto: %25
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v8, v10);
      // pto: %25
      uint64_t v134 = (uint64_t) v19;
      TASSIGN(v133, v134);
      TEXTRACT(v133, v119, v132, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %26
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %26
      uint64_t v136 = (uint64_t) v22;
      TASSIGN(v135, v136);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v135, v135, v126, v128);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %27
      Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
      // pto: %27
      uint64_t v138 = (uint64_t) v22;
      TASSIGN(v137, v138);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v137, v137, v130, v133);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %v_acc_inline1231__rv_v2
    Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v10);
    // pto: %v_acc_inline1231__rv_v2
    uint64_t v140 = (uint64_t) v22;
    TASSIGN(v139, v140);
    // pto: %v_proj_inline1253__iter_v2_pview
    pto::Shape<1, 1, 1, 16, 256> v141 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %v_proj_inline1253__iter_v2_pview
    pto::Stride<16384, 16384, 16384, 1024, 1> v142 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %v_proj_inline1253__iter_v2_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v1 + (v22 + v39), v141, v142);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE<Tile<TileType::Acc, float, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v143, v139);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}