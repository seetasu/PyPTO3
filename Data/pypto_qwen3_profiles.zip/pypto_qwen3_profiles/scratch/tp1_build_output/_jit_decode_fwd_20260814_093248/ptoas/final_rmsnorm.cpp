#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void final_rmsnorm(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4) {
  SaturationMode v5 = SaturationMode::OFF;
  RoundMode v6 = RoundMode::CAST_ROUND;
  const int64_t v7 = 5120;
  const float v8 = 9.99999997E-7f;
  const float v9 = 1.95312503E-4f;
  const int64_t v10 = 128;
  const int64_t v11 = 40;
  const float v12 = 0.0f;
  const int64_t v13 = 1;
  const int64_t v14 = 16;
  const int64_t v15 = 16448;
  const int64_t v16 = 8256;
  const int64_t v17 = 64;
  const int64_t v18 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %sq_sum_inline1428__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %sq_sum_inline1428__tile
  uint64_t v20 = (uint64_t) v18;
  TASSIGN(v19, v20);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  TEXPANDS(v19, v12);
  for (int64_t i21 = v18; i21 < v11; i21 += v13) {
    // pto: %8
    int64_t v22 = (int64_t) ((uint64_t) i21 * (uint64_t) v10);
    // pto: %final_sq_chunk_inline1426__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_sq_chunk_inline1426__tile
    uint64_t v24 = (uint64_t) v17;
    TASSIGN(v23, v24);
    // pto: %cur__rv_v7_pview
    pto::Shape<1, 1, 1, 16, 128> v25 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %cur__rv_v7_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v26 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %9, %cur__rv_v7_pview, %10
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v27 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + ((v18 + (v4 < v18 ? v18 : v4) * v7) + (v22 < v18 ? v18 : v22)), v25, v26);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v23, v27);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v28 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile
    uint64_t v29 = (uint64_t) v17;
    TASSIGN(v28, v29);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TMUL(v28, v23, v23);
    // pto: %tmp_tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %tmp_tile
    uint64_t v31 = (uint64_t) v16;
    TASSIGN(v30, v31);
    // pto: %0
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
    // pto: %0
    uint64_t v33 = (uint64_t) v15;
    TASSIGN(v32, v33);
    pipe_barrier(PIPE_V);
    TROWSUM(v32, v28, v30);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %1
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %1
    uint64_t v35 = (uint64_t) v15;
    TASSIGN(v34, v35);
    // pto: %2
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %2
    uint64_t v37 = (uint64_t) v18;
    TASSIGN(v36, v37);
    pipe_barrier(PIPE_V);
    TADD(v36, v19, v34);
  }
  // pto: %3
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %3
  uint64_t v39 = (uint64_t) v17;
  TASSIGN(v38, v39);
  pipe_barrier(PIPE_V);
  TMULS(v38, v19, v9);
  // pto: %4
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %4
  uint64_t v41 = (uint64_t) v17;
  TASSIGN(v40, v41);
  pipe_barrier(PIPE_V);
  TADDS(v40, v38, v8);
  // pto: %5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %5
  uint64_t v43 = (uint64_t) v18;
  TASSIGN(v42, v43);
  pipe_barrier(PIPE_V);
  TRSQRT(v42, v40);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  // pto: %inv_rms_final_inline1433__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %inv_rms_final_inline1433__tile
  uint64_t v45 = (uint64_t) v18;
  TASSIGN(v44, v45);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  for (int64_t i46 = v18; i46 < v11; i46 += v13) {
    // pto: %11
    int64_t v47 = (int64_t) ((uint64_t) i46 * (uint64_t) v10);
    // pto: %final_hidden_chunk_inline1438__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_hidden_chunk_inline1438__tile
    uint64_t v49 = (uint64_t) v17;
    TASSIGN(v48, v49);
    // pto: %12
    int64_t v50 = v4 < v18 ? v18 : v4;
    // pto: %13
    int64_t v51 = v47 < v18 ? v18 : v47;
    // pto: %14
    pto::Shape<1, 1, 1, 16, 128> v52 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %14
    pto::Stride<81920, 81920, 81920, 5120, 1> v53 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %14
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v54 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + ((v18 + v50 * v7) + v51), v52, v53);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v48, v54);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %final_gamma_inline1430__tile
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %final_gamma_inline1430__tile
    uint64_t v56 = (uint64_t) v16;
    TASSIGN(v55, v56);
    // pto: %final_norm_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 128> v57 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %final_norm_weight__ssa_v0_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v58 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %final_norm_weight__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + (v18 + v51), v57, v58);
    TLOAD(v55, v59);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %6
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %6
    uint64_t v61 = (uint64_t) v17;
    TASSIGN(v60, v61);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v60, v48, v44);
    // pto: %final_normed_chunk_inline1424__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_normed_chunk_inline1424__tile
    uint64_t v63 = (uint64_t) v17;
    TASSIGN(v62, v63);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPANDMUL(v62, v60, v55);
    // pto: %7
    Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %7
    uint64_t v65 = (uint64_t) v17;
    TASSIGN(v64, v65);
    pipe_barrier(PIPE_V);
    TCVT(v64, v62, v6, v5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %final_normed_inline1422__iter_v3_pview
    pto::Shape<1, 1, 1, 16, 128> v66 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %final_normed_inline1422__iter_v3_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v67 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %final_normed_inline1422__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v68 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + ((v18 + v50 * v7) + v51), v66, v67);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v68, v64);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}