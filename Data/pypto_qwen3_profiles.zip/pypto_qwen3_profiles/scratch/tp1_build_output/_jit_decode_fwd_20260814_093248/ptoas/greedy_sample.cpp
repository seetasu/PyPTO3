#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void greedy_sample(__gm__ float* v1, __gm__ int32_t* v2, int64_t v3, int64_t v4) {
  const int64_t v5 = 152064;
  const int32_t v6 = 0;
  const int64_t v7 = 512;
  const int64_t v8 = 8;
  const int64_t v9 = 1;
  const int64_t v10 = 8192;
  const int64_t v11 = 10240;
  const int64_t v12 = 6144;
  const int64_t v13 = 4096;
  const float v14 = -3.40282306E+38f;
  const int64_t v15 = 0;
  const int64_t v16 = 297;
  const int64_t v17 = 296;
  const int64_t v18 = 1024;
  const int64_t v19 = 384;
  const int32_t v20 = 64;
  const int32_t v21 = 256;
  const int64_t v22 = 32;
  const int64_t v23 = 16;
  const int64_t v24 = 511;
  const int32_t v25 = 512;
  const int32_t v26 = 296;
  const int32_t v27 = 151936;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_ui32
  uint32_t v28 = (uint32_t) v6;
  // pto: %sorted_pairs_inline1443__phi_v2
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v29 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v18);
  // pto: %sorted_pairs_inline1443__phi_v2
  uint64_t v30 = (uint64_t) v11;
  TASSIGN(v29, v30);
  // pto: %idx_init_inline1457__tile
  Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v7);
  // pto: %idx_init_inline1457__tile
  uint64_t v32 = (uint64_t) v13;
  TASSIGN(v31, v32);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  TCI<Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, uint32_t, 0>(v31, v28);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  set_flag(PIPE_S, PIPE_V, EVENT_ID3);
  // pto: %chunk_vals_inline1456__tile
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v7);
  // pto: %chunk_vals_inline1456__tile
  uint64_t v34 = (uint64_t) v12;
  TASSIGN(v33, v34);
  // pto: %t__tile
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v7);
  // pto: %t__tile
  uint64_t v36 = (uint64_t) v11;
  TASSIGN(v35, v36);
  TEXPANDS(v35, v14);
  // pto: %assemble_view
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v37;
  // pto: %assemble_view
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = v37;
  // pto: %assemble_view
  uint64_t v39 = (uint64_t) v12;
  TASSIGN(v38, v39);
  pipe_barrier(PIPE_V);
  TMOV(v38, v35);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  for (int64_t i40 = v15; i40 < v16; i40 += v9) {
    // pto: %7
    int64_t v41 = (int64_t) ((uint64_t) i40 * (uint64_t) v7);
    // pto: %local_scores_inline1448__tile
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v7);
    // pto: %local_scores_inline1448__tile
    uint64_t v43 = (uint64_t) v15;
    TASSIGN(v42, v43);
    // pto: %out__rv_v2_pview
    pto::Shape<1, 1, 1, 1, 512> v44 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %out__rv_v2_pview
    pto::Stride<152064, 152064, 152064, 152064, 1> v45 = pto::Stride<152064, 152064, 152064, 152064, 1>();
    // pto: %8, %out__rv_v2_pview, %9
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<152064, 152064, 152064, 152064, 1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<152064, 152064, 152064, 152064, 1>, pto::Layout::ND>(v1 + ((v15 + (v3 < v15 ? v15 : v3) * v5) + (v41 < v15 ? v15 : v41)), v44, v45);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    TLOAD(v42, v46);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %10
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    if (i40 == v17) {
      v42.SetValidShape(v9, v19);
      // pto: %local_scores_padded_inline1444__tile
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v47 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v7);
      // pto: %local_scores_padded_inline1444__tile
      uint64_t v48 = (uint64_t) v10;
      TASSIGN(v47, v48);
      TFILLPAD(v47, v42);
      // pto: %sorted_pairs_inline1443__tile
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v49 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v18);
      // pto: %sorted_pairs_inline1443__tile
      uint64_t v50 = (uint64_t) v11;
      TASSIGN(v49, v50);
      pipe_barrier(PIPE_V);
      TSORT32(v49, v47, v31);
    } else {
      // pto: %1
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v18);
      // pto: %1
      uint64_t v52 = (uint64_t) v11;
      TASSIGN(v51, v52);
      pipe_barrier(PIPE_V);
      TSORT32(v51, v42, v31);
    }
    // pto: %2
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v53 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v18);
    // pto: %2
    uint64_t v54 = (uint64_t) v15;
    TASSIGN(v53, v54);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TMRGSORT(v53, v29, v20);
    // pto: %3
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v55 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v18);
    // pto: %3
    uint64_t v56 = (uint64_t) v11;
    TASSIGN(v55, v56);
    pipe_barrier(PIPE_V);
    TMRGSORT(v55, v53, v21);
    // pto: %top_pairs_inline1442__tile
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v57 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v22);
    // pto: %top_pairs_inline1442__tile
    uint64_t v58 = (uint64_t) v11;
    TASSIGN(v57, v58);
    // pto: %slice_view
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v59;
    // pto: %slice_view
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v60 = v59;
    // pto: %slice_view
    uint64_t v61 = (uint64_t) v11;
    TASSIGN(v60, v61);
    // pto: %top_vals_inline1440__tile
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v62 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v23);
    // pto: %top_vals_inline1440__tile
    uint64_t v63 = (uint64_t) v15;
    TASSIGN(v62, v63);
    pipe_barrier(PIPE_V);
    TGATHER<Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v62, v60);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %best_val_inline1459__tile
    float v64 = v62.GetValue(v15);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    v33.SetValue(i40, v64);
  }
  set_flag(PIPE_S, PIPE_V, EVENT_ID2);
  // pto: %chunk_sorted_inline1455__tile
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v18);
  // pto: %chunk_sorted_inline1455__tile
  uint64_t v66 = (uint64_t) v11;
  TASSIGN(v65, v66);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
  TSORT32(v65, v33, v31);
  // pto: %chunk_sorted_v1_inline1460__tile
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v18);
  // pto: %chunk_sorted_v1_inline1460__tile
  uint64_t v68 = (uint64_t) v15;
  TASSIGN(v67, v68);
  pipe_barrier(PIPE_V);
  TMRGSORT(v67, v65, v20);
  // pto: %chunk_sorted_v2_inline1465__tile
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v18);
  // pto: %chunk_sorted_v2_inline1465__tile
  uint64_t v70 = (uint64_t) v11;
  TASSIGN(v69, v70);
  pipe_barrier(PIPE_V);
  TMRGSORT(v69, v67, v21);
  // pto: %chunk_top_pairs_inline1461__tile
  Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v22);
  // pto: %chunk_top_pairs_inline1461__tile
  uint64_t v72 = (uint64_t) v11;
  TASSIGN(v71, v72);
  // pto: %11
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73;
  // pto: %11
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = v73;
  // pto: %11
  uint64_t v75 = (uint64_t) v11;
  TASSIGN(v74, v75);
  // pto: %chunk_top_vals_inline1463__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v23);
  // pto: %chunk_top_vals_inline1463__tile
  uint64_t v77 = (uint64_t) v15;
  TASSIGN(v76, v77);
  pipe_barrier(PIPE_V);
  TGATHER<Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P0101>(v76, v74);
  set_flag(PIPE_V, PIPE_S, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
  // pto: %12
  float v78 = v76.GetValue(v15);
  set_flag(PIPE_S, PIPE_V, EVENT_ID4);
  set_flag(PIPE_S, PIPE_V, EVENT_ID6);
  // pto: %chunk_i32_inline1464__rv_v2
  int32_t v79;
  v79 = v6;
  for (int64_t i80 = v15; i80 < v16; i80 += v9) {
    // pto: %chunk_i32_inline1464__rv_v2
    int32_t v81 = v79;
    // pto: %14
    int64_t v82 = (int64_t) ((uint64_t) v17 - (uint64_t) i80);
    // pto: %val_inline1468__tile
    float v83 = v33.GetValue(v82);
    // pto: %17
    bool v84 = v83 != v83 || v78 != v78;
    // pto: %17
    // pto: %chunk_i32_inline1464__phi_v4
    int32_t v85;
    if ((v83 == v83 && v78 == v78) && v83 == v78) {
      // pto: %18
      v85 = (int32_t) v82;
    } else {
      v85 = v81;
    }
    // pto: %chunk_i32_inline1464__phi_v4
    int32_t v86 = v85;
    v79 = v86;
  }
  // pto: %chunk_i32_inline1464__rv_v2
  int32_t v87 = v79;
  // pto: %21
  int32_t v88 = (int32_t) ((uint32_t) v87 * (uint32_t) v25);
  // pto: %22
  int64_t v89 = (int64_t) v88;
  // pto: %winning_logits_inline1470__tile
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v7);
  // pto: %winning_logits_inline1470__tile
  uint64_t v91 = (uint64_t) v11;
  TASSIGN(v90, v91);
  // pto: %24
  int64_t v92 = v3 < v15 ? v15 : v3;
  // pto: %26
  pto::Shape<1, 1, 1, 1, 512> v93 = pto::Shape<1, 1, 1, 1, 512>();
  // pto: %26
  pto::Stride<152064, 152064, 152064, 152064, 1> v94 = pto::Stride<152064, 152064, 152064, 152064, 1>();
  // pto: %26, %25
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<152064, 152064, 152064, 152064, 1>, pto::Layout::ND> v95 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<152064, 152064, 152064, 152064, 1>, pto::Layout::ND>(v1 + ((v15 + v92 * v5) + (v89 < v15 ? v15 : v89)), v93, v94);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v90, v95);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  // pto: %28
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
  // pto: %local_token_inline1469__phi_v9
  int32_t v96;
  if (v87 == v26) {
    v90.SetValidShape(v9, v19);
    // pto: %winning_logits_padded_inline1441__tile
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v97 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v9, v7);
    // pto: %winning_logits_padded_inline1441__tile
    uint64_t v98 = (uint64_t) v15;
    TASSIGN(v97, v98);
    TFILLPAD(v97, v90);
    set_flag(PIPE_V, PIPE_S, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
    // pto: %local_token_inline1469__rv_v2
    int32_t v99;
    v99 = v6;
    for (int64_t i100 = v15; i100 < v7; i100 += v9) {
      // pto: %local_token_inline1469__rv_v2
      int32_t v101 = v99;
      // pto: %29
      int64_t v102 = (int64_t) ((uint64_t) v24 - (uint64_t) i100);
      // pto: %30
      float v103 = v97.GetValue(v102);
      // pto: %34
      bool v104 = v103 != v103 || v78 != v78;
      // pto: %34
      // pto: %local_token_inline1469__phi_v4
      int32_t v105;
      if ((v103 == v103 && v78 == v78) && v103 == v78) {
        // pto: %35
        v105 = (int32_t) v102;
      } else {
        v105 = v101;
      }
      // pto: %local_token_inline1469__phi_v4
      int32_t v106 = v105;
      v99 = v106;
    }
    // pto: %local_token_inline1469__rv_v2
    int32_t v107 = v99;
    v96 = v107;
  } else {
    // pto: %local_token_inline1469__rv_v6
    int32_t v108;
    v108 = v6;
    for (int64_t i109 = v15; i109 < v7; i109 += v9) {
      // pto: %local_token_inline1469__rv_v6
      int32_t v110 = v108;
      // pto: %36
      int64_t v111 = (int64_t) ((uint64_t) v24 - (uint64_t) i109);
      // pto: %37
      float v112 = v90.GetValue(v111);
      // pto: %41
      bool v113 = v112 != v112 || v78 != v78;
      // pto: %41
      // pto: %local_token_inline1469__phi_v8
      int32_t v114;
      if ((v112 == v112 && v78 == v78) && v112 == v78) {
        // pto: %42
        v114 = (int32_t) v111;
      } else {
        v114 = v110;
      }
      // pto: %local_token_inline1469__phi_v8
      int32_t v115 = v114;
      v108 = v115;
    }
    // pto: %local_token_inline1469__rv_v6
    int32_t v116 = v108;
    v96 = v116;
  }
  // pto: %local_token_inline1469__phi_v9
  int32_t v117 = v96;
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID5);
  // pto: %43
  int32_t v118 = (int32_t) ((uint32_t) v88 + (uint32_t) v117);
  // pto: %45, %token_id_inline1454__phi_v2
  int32_t v119 = v118 >= v27 ? v6 : v118;
  // pto: %token_out_inline1453__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v8);
  // pto: %token_out_inline1453__tile
  uint64_t v121 = (uint64_t) v11;
  TASSIGN(v120, v121);
  // pto: %4
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v8);
  // pto: %4
  uint64_t v123 = (uint64_t) v15;
  TASSIGN(v122, v123);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
  TEXPANDS(v122, v6);
  // pto: %47
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124;
  // pto: %47
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = v124;
  // pto: %47
  uint64_t v126 = (uint64_t) v11;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  TMOV(v125, v122);
  set_flag(PIPE_V, PIPE_S, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
  v120.SetValue(v15, v119);
  set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
  // pto: %sampled_ids_out__iter_v1_pview
  pto::Shape<1, 1, 1, 1, 8> v127 = pto::Shape<1, 1, 1, 1, 8>();
  // pto: %sampled_ids_out__iter_v1_pview
  pto::Stride<8, 8, 8, 8, 1> v128 = pto::Stride<8, 8, 8, 8, 1>();
  // pto: %sampled_ids_out__iter_v1_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v129 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v2 + (v15 + v92 * v8), v127, v128);
  wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
  TSTORE(v129, v120);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}