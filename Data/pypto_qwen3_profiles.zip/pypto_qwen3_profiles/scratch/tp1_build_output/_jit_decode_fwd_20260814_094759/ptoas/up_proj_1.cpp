#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void up_proj_1(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  const int64_t v8 = 17408;
  const int64_t v9 = 960;
  const int64_t v10 = 2;
  const int64_t v11 = 15;
  const int64_t v12 = 32;
  const int64_t v13 = 64;
  const int64_t v14 = 1;
  const int64_t v15 = 16;
  const int64_t v16 = 512;
  const int64_t v17 = 2048;
  const int64_t v18 = 32768;
  const int64_t v19 = 1536;
  const int64_t v20 = 1024;
  const int64_t v21 = 0;
  const int64_t v22 = 135168;
  const int64_t v23 = 4096;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %spmd_up_c_acc_inline1369__tile_l0_c_phi
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v24 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
  // pto: %spmd_up_c_acc_inline1369__tile_l0_c_phi
  uint64_t v25 = (uint64_t) v21;
  TASSIGN(v24, v25);
  // pto: %spmd_up_n_out_inline1190__tile, %25
  int64_t v26 = (int64_t) ((uint64_t) ((int64_t) v6) * (uint64_t) v20);
  // pto: %spmd_up_a0_inline1216__tile
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v27 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
  // pto: %spmd_up_a0_inline1216__tile
  uint64_t v28 = (uint64_t) v23;
  TASSIGN(v27, v28);
  // pto: %mlp_norm_in_inline1163__rv_v14_pview
  pto::Shape<1, 1, 1, 16, 64> v29 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %mlp_norm_in_inline1163__rv_v14_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v30 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %26, %mlp_norm_in_inline1163__rv_v14_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v31 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v21 + (v4 < v21 ? v21 : v4)), v29, v30);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  TLOAD(v27, v31);
  // pto: %spmd_up_w0_inline1363__tile
  Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
  // pto: %spmd_up_w0_inline1363__tile
  uint64_t v33 = (uint64_t) v22;
  TASSIGN(v32, v33);
  // pto: %27
  int64_t v34 = (int64_t) ((uint64_t) v5 + (uint64_t) v4);
  // pto: %29
  int64_t v35 = v26 < v21 ? v21 : v26;
  // pto: %w_up__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 1024> v36 = pto::Shape<1, 1, 1, 64, 1024>();
  // pto: %w_up__ssa_v0_pview
  pto::Stride<1114112, 1114112, 1114112, 17408, 1> v37 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
  // pto: %28, %w_up__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v38 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v21 + (v34 < v21 ? v21 : v34) * v8) + v35), v36, v37);
  TLOAD(v32, v38);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %spmd_up_c_acc_inline1369__tile_l0_init
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
  // pto: %spmd_up_c_acc_inline1369__tile_l0_init
  uint64_t v40 = (uint64_t) v21;
  TASSIGN(v39, v40);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t i41 = v21; i41 < v13; i41 += v12) {
    // pto: %spmd_up_c_acc_inline1369__tile_l0_a
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
    // pto: %spmd_up_c_acc_inline1369__tile_l0_a
    uint64_t v43 = (uint64_t) v20;
    TASSIGN(v42, v43);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    pipe_barrier(PIPE_MTE1);
    TEXTRACT(v42, v27, v21, i41);
    // pto: %spmd_up_c_acc_inline1369__tile_l0_b
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %spmd_up_c_acc_inline1369__tile_l0_b
    uint64_t v45 = (uint64_t) v21;
    TASSIGN(v44, v45);
    TEXTRACT(v44, v32, i41, v21);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %0
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
    // pto: %0
    uint64_t v47 = (uint64_t) v19;
    TASSIGN(v46, v47);
    // pto: %30
    int64_t v48 = (int64_t) ((uint64_t) i41 + (uint64_t) v15);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v46, v27, v21, v48);
    // pto: %1
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %1
    uint64_t v50 = (uint64_t) v18;
    TASSIGN(v49, v50);
    TEXTRACT(v49, v32, v48, v21);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %32
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (i41 == v21) {
      // pto: %spmd_up_c_acc_inline1369__tile_l0_c_first
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %spmd_up_c_acc_inline1369__tile_l0_c_first
      uint64_t v52 = (uint64_t) v21;
      TASSIGN(v51, v52);
      pipe_barrier(PIPE_M);
      TMATMUL(v51, v42, v44);
    } else {
      // pto: %spmd_up_c_acc_inline1369__tile_l0_c_acc
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %spmd_up_c_acc_inline1369__tile_l0_c_acc
      uint64_t v54 = (uint64_t) v21;
      TASSIGN(v53, v54);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v53, v53, v42, v44);
    }
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %2
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %2
    uint64_t v56 = (uint64_t) v21;
    TASSIGN(v55, v56);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v55, v55, v46, v49);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  for (int64_t i57 = v14; i57 < v11; i57 += v10) {
    // pto: %33
    int64_t v58 = (int64_t) ((uint64_t) i57 * (uint64_t) v13);
    // pto: %35
    int64_t v59 = (int64_t) ((uint64_t) v58 + (uint64_t) v13);
    // pto: %spmd_up_a_k_inline1324__tile
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
    // pto: %spmd_up_a_k_inline1324__tile
    uint64_t v61 = (uint64_t) v21;
    TASSIGN(v60, v61);
    // pto: %36
    int64_t v62 = (int64_t) ((uint64_t) v4 + (uint64_t) v58);
    // pto: %38
    pto::Shape<1, 1, 1, 16, 64> v63 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %38
    pto::Stride<81920, 81920, 81920, 5120, 1> v64 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %37, %38
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v21 + (v62 < v21 ? v21 : v62)), v63, v64);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v60, v65);
    // pto: %spmd_up_w_k_inline1389__tile
    Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
    // pto: %spmd_up_w_k_inline1389__tile
    uint64_t v67 = (uint64_t) v22;
    TASSIGN(v66, v67);
    // pto: %40
    int64_t v68 = (int64_t) ((uint64_t) v34 + (uint64_t) v58);
    // pto: %43
    pto::Shape<1, 1, 1, 64, 1024> v69 = pto::Shape<1, 1, 1, 64, 1024>();
    // pto: %43
    pto::Stride<1114112, 1114112, 1114112, 17408, 1> v70 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
    // pto: %41, %43
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v71 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v21 + (v68 < v21 ? v21 : v68) * v8) + v35), v69, v70);
    TLOAD(v66, v71);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %3
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
    // pto: %3
    uint64_t v73 = (uint64_t) v17;
    TASSIGN(v72, v73);
    // pto: %44
    int64_t v74 = (int64_t) ((uint64_t) v4 + (uint64_t) v59);
    // pto: %46
    pto::Shape<1, 1, 1, 16, 64> v75 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %46
    pto::Stride<81920, 81920, 81920, 5120, 1> v76 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %45, %46
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v77 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v21 + (v74 < v21 ? v21 : v74)), v75, v76);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v72, v77);
    // pto: %4
    Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
    // pto: %4
    uint64_t v79 = (uint64_t) v23;
    TASSIGN(v78, v79);
    // pto: %48
    int64_t v80 = (int64_t) ((uint64_t) v34 + (uint64_t) v59);
    // pto: %51
    pto::Shape<1, 1, 1, 64, 1024> v81 = pto::Shape<1, 1, 1, 64, 1024>();
    // pto: %51
    pto::Stride<1114112, 1114112, 1114112, 17408, 1> v82 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
    // pto: %49, %51
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v83 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v21 + (v80 < v21 ? v21 : v80) * v8) + v35), v81, v82);
    TLOAD(v78, v83);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j84 = v21; j84 < v13; j84 += v12) {
      // pto: %5
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
      // pto: %5
      uint64_t v86 = (uint64_t) v20;
      TASSIGN(v85, v86);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TEXTRACT(v85, v60, v21, j84);
      // pto: %6
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %6
      uint64_t v88 = (uint64_t) v21;
      TASSIGN(v87, v88);
      TEXTRACT(v87, v66, j84, v21);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %7
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
      // pto: %7
      uint64_t v90 = (uint64_t) v19;
      TASSIGN(v89, v90);
      // pto: %53
      int64_t v91 = (int64_t) ((uint64_t) j84 + (uint64_t) v15);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TEXTRACT(v89, v60, v21, v91);
      // pto: %8
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %8
      uint64_t v93 = (uint64_t) v18;
      TASSIGN(v92, v93);
      TEXTRACT(v92, v66, v91, v21);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      // pto: %9
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %9
      uint64_t v95 = (uint64_t) v21;
      TASSIGN(v94, v95);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v94, v94, v85, v87);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      // pto: %10
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %10
      uint64_t v97 = (uint64_t) v21;
      TASSIGN(v96, v97);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v96, v96, v89, v92);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    for (int64_t j98 = v21; j98 < v13; j98 += v12) {
      // pto: %11
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
      // pto: %11
      uint64_t v100 = (uint64_t) v21;
      TASSIGN(v99, v100);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      TEXTRACT(v99, v72, v21, j98);
      // pto: %12
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %12
      uint64_t v102 = (uint64_t) v21;
      TASSIGN(v101, v102);
      TEXTRACT(v101, v78, j98, v21);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      // pto: %13
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
      // pto: %13
      uint64_t v104 = (uint64_t) v16;
      TASSIGN(v103, v104);
      // pto: %56
      int64_t v105 = (int64_t) ((uint64_t) j98 + (uint64_t) v15);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TEXTRACT(v103, v72, v21, v105);
      // pto: %14
      Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %14
      uint64_t v107 = (uint64_t) v18;
      TASSIGN(v106, v107);
      TEXTRACT(v106, v78, v105, v21);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      // pto: %15
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %15
      uint64_t v109 = (uint64_t) v21;
      TASSIGN(v108, v109);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v108, v108, v99, v101);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      // pto: %16
      Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
      // pto: %16
      uint64_t v111 = (uint64_t) v21;
      TASSIGN(v110, v111);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v110, v110, v103, v106);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %17
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
  // pto: %17
  uint64_t v113 = (uint64_t) v23;
  TASSIGN(v112, v113);
  // pto: %58
  int64_t v114 = (int64_t) ((uint64_t) v4 + (uint64_t) v9);
  // pto: %60
  pto::Shape<1, 1, 1, 16, 64> v115 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %60
  pto::Stride<81920, 81920, 81920, 5120, 1> v116 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %59, %60
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v117 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v21 + (v114 < v21 ? v21 : v114)), v115, v116);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  TLOAD(v112, v117);
  // pto: %18
  Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Mat, bfloat16_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
  // pto: %18
  uint64_t v119 = (uint64_t) v22;
  TASSIGN(v118, v119);
  // pto: %62
  int64_t v120 = (int64_t) ((uint64_t) v34 + (uint64_t) v9);
  // pto: %65
  pto::Shape<1, 1, 1, 64, 1024> v121 = pto::Shape<1, 1, 1, 64, 1024>();
  // pto: %65
  pto::Stride<1114112, 1114112, 1114112, 17408, 1> v122 = pto::Stride<1114112, 1114112, 1114112, 17408, 1>();
  // pto: %63, %65
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<1114112, 1114112, 1114112, 17408, 1>, pto::Layout::ND>(v2 + ((v21 + (v120 < v21 ? v21 : v120) * v8) + v35), v121, v122);
  TLOAD(v118, v123);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t i124 = v21; i124 < v13; i124 += v12) {
    // pto: %19
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
    // pto: %19
    uint64_t v126 = (uint64_t) v20;
    TASSIGN(v125, v126);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TEXTRACT(v125, v112, v21, i124);
    // pto: %20
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %20
    uint64_t v128 = (uint64_t) v21;
    TASSIGN(v127, v128);
    TEXTRACT(v127, v118, i124, v21);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
    // pto: %21
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v15);
    // pto: %21
    uint64_t v130 = (uint64_t) v19;
    TASSIGN(v129, v130);
    // pto: %67
    int64_t v131 = (int64_t) ((uint64_t) i124 + (uint64_t) v15);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v129, v112, v21, v131);
    // pto: %22
    Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Right, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %22
    uint64_t v133 = (uint64_t) v18;
    TASSIGN(v132, v133);
    TEXTRACT(v132, v118, v131, v21);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
    // pto: %23
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %23
    uint64_t v135 = (uint64_t) v21;
    TASSIGN(v134, v135);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v134, v134, v125, v127);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %24
    Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
    // pto: %24
    uint64_t v137 = (uint64_t) v21;
    TASSIGN(v136, v137);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
    TMATMUL_ACC(v136, v136, v129, v132);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %spmd_up_c_acc_inline1369__rv_v10
  Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v20);
  // pto: %spmd_up_c_acc_inline1369__rv_v10
  uint64_t v139 = (uint64_t) v21;
  TASSIGN(v138, v139);
  // pto: %up_acc_all_inline1295__ssa_v5_pview
  pto::Shape<1, 1, 1, 16, 1024> v140 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %up_acc_all_inline1295__ssa_v5_pview
  pto::Stride<278528, 278528, 278528, 17408, 1> v141 = pto::Stride<278528, 278528, 278528, 17408, 1>();
  // pto: %up_acc_all_inline1295__ssa_v5_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v142 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v21 + v35), v140, v141);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE<Tile<TileType::Acc, float, 16, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v142, v138);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}