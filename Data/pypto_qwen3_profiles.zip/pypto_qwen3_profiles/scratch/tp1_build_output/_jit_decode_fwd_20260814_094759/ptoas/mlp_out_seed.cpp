#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mlp_out_seed(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4) {
  unsigned v5 = 16384;
  unsigned v6 = 4096;
  const int64_t v7 = 512;
  const int64_t v8 = 10;
  const float v9 = 0.0f;
  const int64_t v10 = 1024;
  const int64_t v11 = 2;
  const int64_t v12 = 4;
  const int64_t v13 = 16;
  const int64_t v14 = 65536;
  const int64_t v15 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t i16 = v15; i16 < v12; i16 += v11) {
    // pto: %9
    int64_t v17 = (int64_t) ((uint64_t) i16 * (uint64_t) v10);
    // pto: %11
    int64_t v18 = (int64_t) ((uint64_t) v17 + (uint64_t) v10);
    // pto: %zero_inline1181__tile
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %zero_inline1181__tile
    uint64_t v20 = (uint64_t) v15;
    TASSIGN(v19, v20);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v19, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %down_acc_all_inline1247__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 1024> v21 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %down_acc_all_inline1247__iter_v1_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v22 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %12, %down_acc_all_inline1247__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v23 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v15 + (v17 < v15 ? v15 : v17)), v21, v22);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v23, v19);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %0
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v24 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %0
    uint64_t v25 = (uint64_t) v14;
    TASSIGN(v24, v25);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v24, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %down_acc_all_inline1247__tile_pview
    pto::Shape<1, 1, 1, 16, 1024> v26 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %down_acc_all_inline1247__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v27 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %14, %down_acc_all_inline1247__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v28 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v15 + (v18 < v15 ? v15 : v18)), v26, v27);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v28, v24);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  // pto: %1
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
  // pto: %1
  uint64_t v30 = (uint64_t) v15;
  TASSIGN(v29, v30);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  TEXPANDS(v29, v9);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  // pto: %down_acc_all_inline1247__rv_v2_main_pview
  pto::Shape<1, 1, 1, 16, 1024> v31 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %down_acc_all_inline1247__rv_v2_main_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v32 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %down_acc_all_inline1247__rv_v2_main_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + v6, v31, v32);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v33, v29);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  for (int64_t i34 = v15; i34 < v13; i34 += v11) {
    // pto: %16
    int64_t v35 = (int64_t) ((uint64_t) i34 * (uint64_t) v10);
    // pto: %18
    int64_t v36 = (int64_t) ((uint64_t) v35 + (uint64_t) v10);
    // pto: %2
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %2
    uint64_t v38 = (uint64_t) v15;
    TASSIGN(v37, v38);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    TEXPANDS(v37, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %gate_acc_all_inline1287__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 1024> v39 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %gate_acc_all_inline1287__iter_v1_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v40 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %19, %gate_acc_all_inline1287__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v2 + (v15 + (v35 < v15 ? v15 : v35)), v39, v40);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v41, v37);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    // pto: %3
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %3
    uint64_t v43 = (uint64_t) v14;
    TASSIGN(v42, v43);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    TEXPANDS(v42, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %gate_acc_all_inline1287__tile_pview
    pto::Shape<1, 1, 1, 16, 1024> v44 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %gate_acc_all_inline1287__tile_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v45 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %21, %gate_acc_all_inline1287__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v2 + (v15 + (v36 < v15 ? v15 : v36)), v44, v45);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v46, v42);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  // pto: %4
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
  // pto: %4
  uint64_t v48 = (uint64_t) v15;
  TASSIGN(v47, v48);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  TEXPANDS(v47, v9);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
  // pto: %gate_acc_all_inline1287__rv_v2_main_pview
  pto::Shape<1, 1, 1, 16, 1024> v49 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %gate_acc_all_inline1287__rv_v2_main_pview
  pto::Stride<278528, 278528, 278528, 17408, 1> v50 = pto::Stride<278528, 278528, 278528, 17408, 1>();
  // pto: %gate_acc_all_inline1287__rv_v2_main_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v2 + v5, v49, v50);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v51, v47);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t i52 = v15; i52 < v13; i52 += v11) {
    // pto: %23
    int64_t v53 = (int64_t) ((uint64_t) i52 * (uint64_t) v10);
    // pto: %25
    int64_t v54 = (int64_t) ((uint64_t) v53 + (uint64_t) v10);
    // pto: %5
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %5
    uint64_t v56 = (uint64_t) v15;
    TASSIGN(v55, v56);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v55, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %up_acc_all_inline1295__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 1024> v57 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %up_acc_all_inline1295__iter_v1_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v58 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %26, %up_acc_all_inline1295__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v15 + (v53 < v15 ? v15 : v53)), v57, v58);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v59, v55);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %6
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %6
    uint64_t v61 = (uint64_t) v14;
    TASSIGN(v60, v61);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v60, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    // pto: %up_acc_all_inline1295__tile_pview
    pto::Shape<1, 1, 1, 16, 1024> v62 = pto::Shape<1, 1, 1, 16, 1024>();
    // pto: %up_acc_all_inline1295__tile_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v63 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %28, %up_acc_all_inline1295__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v15 + (v54 < v15 ? v15 : v54)), v62, v63);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v64, v60);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %7
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
  // pto: %7
  uint64_t v66 = (uint64_t) v15;
  TASSIGN(v65, v66);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v65, v9);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %up_acc_all_inline1295__rv_v2_main_pview
  pto::Shape<1, 1, 1, 16, 1024> v67 = pto::Shape<1, 1, 1, 16, 1024>();
  // pto: %up_acc_all_inline1295__rv_v2_main_pview
  pto::Stride<278528, 278528, 278528, 17408, 1> v68 = pto::Stride<278528, 278528, 278528, 17408, 1>();
  // pto: %up_acc_all_inline1295__rv_v2_main_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v69 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1024>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + v5, v67, v68);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v69, v65);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t i70 = v15; i70 < v8; i70 += v11) {
    // pto: %30
    int64_t v71 = (int64_t) ((uint64_t) i70 * (uint64_t) v7);
    // pto: %32
    int64_t v72 = (int64_t) ((uint64_t) v71 + (uint64_t) v7);
    // pto: %out_zero_inline1197__tile
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v7);
    // pto: %out_zero_inline1197__tile
    uint64_t v74 = (uint64_t) v15;
    TASSIGN(v73, v74);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v73, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %attn_proj_fp32_inline1290__iter_v1_pview
    pto::Shape<1, 1, 1, 16, 512> v75 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %attn_proj_fp32_inline1290__iter_v1_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v76 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %33, %attn_proj_fp32_inline1290__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v77 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v4 + (v15 + (v71 < v15 ? v15 : v71)), v75, v76);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v77, v73);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %8
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v7);
    // pto: %8
    uint64_t v79 = (uint64_t) v14;
    TASSIGN(v78, v79);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v78, v9);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %attn_proj_fp32_inline1290__tile_pview
    pto::Shape<1, 1, 1, 16, 512> v80 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %attn_proj_fp32_inline1290__tile_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v81 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %35, %attn_proj_fp32_inline1290__tile_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v4 + (v15 + (v72 < v15 ? v15 : v72)), v80, v81);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v82, v78);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}