#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void silu(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, __gm__ float* v4, int64_t v5) {
  SaturationMode v6 = SaturationMode::OFF;
  RoundMode v7 = RoundMode::CAST_ROUND;
  const float v8 = 1.0f;
  const int64_t v9 = 256;
  const int64_t v10 = 2;
  const int64_t v11 = 4;
  const int64_t v12 = 1;
  const int64_t v13 = 16;
  const int64_t v14 = 49152;
  const int64_t v15 = 32768;
  const int64_t v16 = 16384;
  const int64_t v17 = 0;
  const int64_t v18 = 114752;
  const int64_t v19 = 98368;
  const int64_t v20 = 81984;
  const int64_t v21 = 65600;
  const int64_t v22 = 65536;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %inv_rms_chunk_inline1235__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %inv_rms_chunk_inline1235__tile
  uint64_t v24 = (uint64_t) v22;
  TASSIGN(v23, v24);
  // pto: %inv_rms_tile_inline1182__ssa_v1_pview
  pto::Shape<1, 1, 1, 16, 1> v25 = pto::Shape<1, 1, 1, 16, 1>();
  // pto: %inv_rms_tile_inline1182__ssa_v1_pview
  pto::Stride<16, 16, 16, 1, 16> v26 = pto::Stride<16, 16, 16, 1, 16>();
  // pto: %inv_rms_tile_inline1182__ssa_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN> v27 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 16>, pto::Layout::DN>(v1, v25, v26);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v23, v27);
  for (int64_t i28 = v17; i28 < v11; i28 += v10) {
    // pto: %15
    int64_t v29 = (int64_t) ((uint64_t) i28 * (uint64_t) v9);
    // pto: %16
    int64_t v30 = (int64_t) ((uint64_t) v5 + (uint64_t) v29);
    // pto: %19, %18
    int64_t v31 = (int64_t) ((uint64_t) v5 + (uint64_t) ((int64_t) ((uint64_t) v29 + (uint64_t) v9)));
    // pto: %gate_chunk_inline1398__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %gate_chunk_inline1398__tile
    uint64_t v33 = (uint64_t) v21;
    TASSIGN(v32, v33);
    // pto: %20
    int64_t v34 = v30 < v17 ? v17 : v30;
    // pto: %gate_acc_all_inline1287__rv_v10_pview
    pto::Shape<1, 1, 1, 16, 256> v35 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %gate_acc_all_inline1287__rv_v10_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v36 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %gate_acc_all_inline1287__rv_v10_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v37 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v17 + v34), v35, v36);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v32, v37);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %up_chunk_inline1267__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %up_chunk_inline1267__tile
    uint64_t v39 = (uint64_t) v20;
    TASSIGN(v38, v39);
    // pto: %up_acc_all_inline1295__rv_v10_pview
    pto::Shape<1, 1, 1, 16, 256> v40 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %up_acc_all_inline1295__rv_v10_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v41 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %up_acc_all_inline1295__rv_v10_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v42 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v4 + (v17 + v34), v40, v41);
    TLOAD(v38, v42);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %0
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %0
    uint64_t v44 = (uint64_t) v19;
    TASSIGN(v43, v44);
    // pto: %22
    int64_t v45 = v31 < v17 ? v17 : v31;
    // pto: %23
    pto::Shape<1, 1, 1, 16, 256> v46 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %23
    pto::Stride<278528, 278528, 278528, 17408, 1> v47 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %23
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v3 + (v17 + v45), v46, v47);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v43, v48);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %1
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %1
    uint64_t v50 = (uint64_t) v18;
    TASSIGN(v49, v50);
    // pto: %25
    pto::Shape<1, 1, 1, 16, 256> v51 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %25
    pto::Stride<278528, 278528, 278528, 17408, 1> v52 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %25
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v4 + (v17 + v45), v51, v52);
    TLOAD(v49, v53);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %scaled_gate_inline1207__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %scaled_gate_inline1207__tile
    uint64_t v55 = (uint64_t) v21;
    TASSIGN(v54, v55);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDMUL(v54, v32, v23);
    // pto: %scaled_up_inline1146__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %scaled_up_inline1146__tile
    uint64_t v57 = (uint64_t) v20;
    TASSIGN(v56, v57);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v56, v38, v23);
    // pto: %t__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %t__tile
    uint64_t v59 = (uint64_t) v17;
    TASSIGN(v58, v59);
    pipe_barrier(PIPE_V);
    TNEG(v58, v54);
    // pto: %2
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %2
    uint64_t v61 = (uint64_t) v17;
    TASSIGN(v60, v61);
    pipe_barrier(PIPE_V);
    TEXP(v60, v58);
    // pto: %3
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %3
    uint64_t v63 = (uint64_t) v17;
    TASSIGN(v62, v63);
    pipe_barrier(PIPE_V);
    TADDS(v62, v60, v8);
    // pto: %sigmoid_inline1399__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %sigmoid_inline1399__tile
    uint64_t v65 = (uint64_t) v16;
    TASSIGN(v64, v65);
    pipe_barrier(PIPE_V);
    TRECIP(v64, v62);
    // pto: %4
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %4
    uint64_t v67 = (uint64_t) v21;
    TASSIGN(v66, v67);
    pipe_barrier(PIPE_V);
    TMUL(v66, v54, v64);
    // pto: %mlp_chunk_inline1405__tile
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %mlp_chunk_inline1405__tile
    uint64_t v69 = (uint64_t) v21;
    TASSIGN(v68, v69);
    pipe_barrier(PIPE_V);
    TMUL(v68, v66, v56);
    // pto: %5
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %5
    uint64_t v71 = (uint64_t) v21;
    TASSIGN(v70, v71);
    pipe_barrier(PIPE_V);
    TCVT(v70, v68, v7, v6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %mlp_tile_inline1162__iter_v3_pview
    pto::Shape<1, 1, 1, 16, 256> v72 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %mlp_tile_inline1162__iter_v3_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v73 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %mlp_tile_inline1162__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v74 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v2 + (v17 + v34), v72, v73);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v74, v70);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %6
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %6
    uint64_t v76 = (uint64_t) v19;
    TASSIGN(v75, v76);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TROWEXPANDMUL(v75, v43, v23);
    // pto: %7
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %7
    uint64_t v78 = (uint64_t) v18;
    TASSIGN(v77, v78);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TROWEXPANDMUL(v77, v49, v23);
    // pto: %8
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %8
    uint64_t v80 = (uint64_t) v15;
    TASSIGN(v79, v80);
    pipe_barrier(PIPE_V);
    TNEG(v79, v75);
    // pto: %9
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %9
    uint64_t v82 = (uint64_t) v15;
    TASSIGN(v81, v82);
    pipe_barrier(PIPE_V);
    TEXP(v81, v79);
    // pto: %10
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %10
    uint64_t v84 = (uint64_t) v15;
    TASSIGN(v83, v84);
    pipe_barrier(PIPE_V);
    TADDS(v83, v81, v8);
    // pto: %11
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %11
    uint64_t v86 = (uint64_t) v14;
    TASSIGN(v85, v86);
    pipe_barrier(PIPE_V);
    TRECIP(v85, v83);
    // pto: %12
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %12
    uint64_t v88 = (uint64_t) v19;
    TASSIGN(v87, v88);
    pipe_barrier(PIPE_V);
    TMUL(v87, v75, v85);
    // pto: %13
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %13
    uint64_t v90 = (uint64_t) v19;
    TASSIGN(v89, v90);
    pipe_barrier(PIPE_V);
    TMUL(v89, v87, v77);
    // pto: %14
    Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v9);
    // pto: %14
    uint64_t v92 = (uint64_t) v19;
    TASSIGN(v91, v92);
    pipe_barrier(PIPE_V);
    TCVT(v91, v89, v7, v6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %mlp_tile_inline1162__tile_pview
    pto::Shape<1, 1, 1, 16, 256> v93 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %mlp_tile_inline1162__tile_pview
    pto::Stride<278528, 278528, 278528, 17408, 1> v94 = pto::Stride<278528, 278528, 278528, 17408, 1>();
    // pto: %mlp_tile_inline1162__tile_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND> v95 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<278528, 278528, 278528, 17408, 1>, pto::Layout::ND>(v2 + (v17 + v45), v93, v94);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v95, v91);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}