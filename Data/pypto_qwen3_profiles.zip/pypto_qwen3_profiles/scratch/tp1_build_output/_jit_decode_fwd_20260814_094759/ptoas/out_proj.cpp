#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void out_proj(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6) {
  const int64_t v7 = 5120;
  const int64_t v8 = 960;
  const int64_t v9 = 2;
  const int64_t v10 = 15;
  const int64_t v11 = 32;
  const int64_t v12 = 512;
  const int64_t v13 = 64;
  const int64_t v14 = 1;
  const int64_t v15 = 16;
  const int64_t v16 = 1024;
  const int64_t v17 = 32768;
  const int64_t v18 = 3072;
  const int64_t v19 = 2048;
  const int64_t v20 = 0;
  const int64_t v21 = 69632;
  const int64_t v22 = 4096;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %out_a0_inline1372__tile
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
  // pto: %out_a0_inline1372__tile
  uint64_t v24 = (uint64_t) v22;
  TASSIGN(v23, v24);
  // pto: %attn_out_inline1274__ssa_v5_pview
  pto::Shape<1, 1, 1, 16, 64> v25 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %attn_out_inline1274__ssa_v5_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v26 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %24, %attn_out_inline1274__ssa_v5_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v27 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v4 < v20 ? v20 : v4)), v25, v26);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v23, v27);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %out_w0_inline1170__tile
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v28 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %out_w0_inline1170__tile
  uint64_t v29 = (uint64_t) v21;
  TASSIGN(v28, v29);
  // pto: %25
  int64_t v30 = (int64_t) ((uint64_t) v5 + (uint64_t) v4);
  // pto: %27
  int64_t v31 = v6 < v20 ? v20 : v6;
  // pto: %wo__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 512> v32 = pto::Shape<1, 1, 1, 64, 512>();
  // pto: %wo__ssa_v0_pview
  pto::Stride<327680, 327680, 327680, 5120, 1> v33 = pto::Stride<327680, 327680, 327680, 5120, 1>();
  // pto: %26, %wo__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v34 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v20 + (v30 < v20 ? v20 : v30) * v7) + v31), v32, v33);
  TLOAD(v28, v34);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %out_c_acc_inline1158__tile_l0_init
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %out_c_acc_inline1158__tile_l0_init
  uint64_t v36 = (uint64_t) v20;
  TASSIGN(v35, v36);
  // pto: %out_c_acc_inline1158__tile_l0_a
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
  // pto: %out_c_acc_inline1158__tile_l0_a
  uint64_t v38 = (uint64_t) v19;
  TASSIGN(v37, v38);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  TEXTRACT(v37, v23, v20, v20);
  // pto: %out_c_acc_inline1158__tile_l0_b
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %out_c_acc_inline1158__tile_l0_b
  uint64_t v40 = (uint64_t) v20;
  TASSIGN(v39, v40);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  TEXTRACT(v39, v28, v20, v20);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
  // pto: %0
  uint64_t v42 = (uint64_t) v18;
  TASSIGN(v41, v42);
  TEXTRACT(v41, v23, v20, v11);
  // pto: %1
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %1
  uint64_t v44 = (uint64_t) v17;
  TASSIGN(v43, v44);
  TEXTRACT(v43, v28, v11, v20);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %out_c_acc_inline1158__tile_l0_c_first
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %out_c_acc_inline1158__tile_l0_c_first
  uint64_t v46 = (uint64_t) v20;
  TASSIGN(v45, v46);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v45, v37, v39);
  // pto: %out_c_acc_inline1158__tile_l0_c_acc
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %out_c_acc_inline1158__tile_l0_c_acc
  uint64_t v48 = (uint64_t) v20;
  TASSIGN(v47, v48);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v47, v47, v41, v43);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i49 = v14; i49 < v10; i49 += v9) {
    // pto: %28
    int64_t v50 = (int64_t) ((uint64_t) i49 * (uint64_t) v13);
    // pto: %30
    int64_t v51 = (int64_t) ((uint64_t) v50 + (uint64_t) v13);
    // pto: %out_a_k_inline1161__tile
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
    // pto: %out_a_k_inline1161__tile
    uint64_t v53 = (uint64_t) v20;
    TASSIGN(v52, v53);
    // pto: %31
    int64_t v54 = (int64_t) ((uint64_t) v4 + (uint64_t) v50);
    // pto: %33
    pto::Shape<1, 1, 1, 16, 64> v55 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %33
    pto::Stride<81920, 81920, 81920, 5120, 1> v56 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %32, %33
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v54 < v20 ? v20 : v54)), v55, v56);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v52, v57);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %out_w_k_inline1149__tile
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v12);
    // pto: %out_w_k_inline1149__tile
    uint64_t v59 = (uint64_t) v21;
    TASSIGN(v58, v59);
    // pto: %35
    int64_t v60 = (int64_t) ((uint64_t) v30 + (uint64_t) v50);
    // pto: %38
    pto::Shape<1, 1, 1, 64, 512> v61 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %38
    pto::Stride<327680, 327680, 327680, 5120, 1> v62 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %36, %38
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v63 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v20 + (v60 < v20 ? v20 : v60) * v7) + v31), v61, v62);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v58, v63);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %2
    Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
    // pto: %2
    uint64_t v65 = (uint64_t) v19;
    TASSIGN(v64, v65);
    // pto: %39
    int64_t v66 = (int64_t) ((uint64_t) v4 + (uint64_t) v51);
    // pto: %41
    pto::Shape<1, 1, 1, 16, 64> v67 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %41
    pto::Stride<81920, 81920, 81920, 5120, 1> v68 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %40, %41
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v66 < v20 ? v20 : v66)), v67, v68);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    TLOAD(v64, v69);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    // pto: %3
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v12);
    // pto: %3
    uint64_t v71 = (uint64_t) v22;
    TASSIGN(v70, v71);
    // pto: %43
    int64_t v72 = (int64_t) ((uint64_t) v30 + (uint64_t) v51);
    // pto: %46
    pto::Shape<1, 1, 1, 64, 512> v73 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %46
    pto::Stride<327680, 327680, 327680, 5120, 1> v74 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %44, %46
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v75 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v20 + (v72 < v20 ? v20 : v72) * v7) + v31), v73, v74);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v70, v75);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
    // pto: %4
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %4
    uint64_t v77 = (uint64_t) v19;
    TASSIGN(v76, v77);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    TEXTRACT(v76, v52, v20, v20);
    // pto: %5
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %5
    uint64_t v79 = (uint64_t) v20;
    TASSIGN(v78, v79);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TEXTRACT(v78, v58, v20, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %6
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %6
    uint64_t v81 = (uint64_t) v18;
    TASSIGN(v80, v81);
    TEXTRACT(v80, v52, v20, v11);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %7
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %7
    uint64_t v83 = (uint64_t) v17;
    TASSIGN(v82, v83);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    TEXTRACT(v82, v58, v11, v20);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    // pto: %8
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
    // pto: %8
    uint64_t v85 = (uint64_t) v20;
    TASSIGN(v84, v85);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v84, v84, v76, v78);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %9
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
    // pto: %9
    uint64_t v87 = (uint64_t) v20;
    TASSIGN(v86, v87);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v86, v86, v80, v82);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    // pto: %10
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %10
    uint64_t v89 = (uint64_t) v20;
    TASSIGN(v88, v89);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    TEXTRACT(v88, v64, v20, v20);
    // pto: %11
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %11
    uint64_t v91 = (uint64_t) v20;
    TASSIGN(v90, v91);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
    TEXTRACT(v90, v70, v20, v20);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
    // pto: %12
    Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %12
    uint64_t v93 = (uint64_t) v16;
    TASSIGN(v92, v93);
    TEXTRACT(v92, v64, v20, v11);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    // pto: %13
    Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
    // pto: %13
    uint64_t v95 = (uint64_t) v17;
    TASSIGN(v94, v95);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    TEXTRACT(v94, v70, v11, v20);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
    // pto: %14
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
    // pto: %14
    uint64_t v97 = (uint64_t) v20;
    TASSIGN(v96, v97);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v96, v96, v88, v90);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %15
    Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
    // pto: %15
    uint64_t v99 = (uint64_t) v20;
    TASSIGN(v98, v99);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
    TMATMUL_ACC(v98, v98, v92, v94);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %16
  Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Mat, bfloat16_t, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v13);
  // pto: %16
  uint64_t v101 = (uint64_t) v22;
  TASSIGN(v100, v101);
  // pto: %47
  int64_t v102 = (int64_t) ((uint64_t) v4 + (uint64_t) v8);
  // pto: %49
  pto::Shape<1, 1, 1, 16, 64> v103 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %49
  pto::Stride<81920, 81920, 81920, 5120, 1> v104 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %48, %49
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v105 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + (v20 + (v102 < v20 ? v20 : v102)), v103, v104);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  TLOAD(v100, v105);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
  // pto: %17
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %17
  uint64_t v107 = (uint64_t) v21;
  TASSIGN(v106, v107);
  // pto: %51
  int64_t v108 = (int64_t) ((uint64_t) v30 + (uint64_t) v8);
  // pto: %54
  pto::Shape<1, 1, 1, 64, 512> v109 = pto::Shape<1, 1, 1, 64, 512>();
  // pto: %54
  pto::Stride<327680, 327680, 327680, 5120, 1> v110 = pto::Stride<327680, 327680, 327680, 5120, 1>();
  // pto: %52, %54
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v111 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + ((v20 + (v108 < v20 ? v20 : v108) * v7) + v31), v109, v110);
  TLOAD(v106, v111);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
  // pto: %18
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
  // pto: %18
  uint64_t v113 = (uint64_t) v19;
  TASSIGN(v112, v113);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
  TEXTRACT(v112, v100, v20, v20);
  // pto: %19
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %19
  uint64_t v115 = (uint64_t) v20;
  TASSIGN(v114, v115);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  TEXTRACT(v114, v106, v20, v20);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
  // pto: %20
  Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Left, bfloat16_t, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v11);
  // pto: %20
  uint64_t v117 = (uint64_t) v18;
  TASSIGN(v116, v117);
  TEXTRACT(v116, v100, v20, v11);
  // pto: %21
  Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v12);
  // pto: %21
  uint64_t v119 = (uint64_t) v17;
  TASSIGN(v118, v119);
  TEXTRACT(v118, v106, v11, v20);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
  // pto: %22
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %22
  uint64_t v121 = (uint64_t) v20;
  TASSIGN(v120, v121);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_M);
  TMATMUL_ACC(v120, v120, v112, v114);
  // pto: %23
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %23
  uint64_t v123 = (uint64_t) v20;
  TASSIGN(v122, v123);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
  TMATMUL_ACC(v122, v122, v116, v118);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %out_c_acc_inline1158__rv_v2
  Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v15, v12);
  // pto: %out_c_acc_inline1158__rv_v2
  uint64_t v125 = (uint64_t) v20;
  TASSIGN(v124, v125);
  // pto: %attn_proj_fp32_inline1290__iter_v4_pview
  pto::Shape<1, 1, 1, 16, 512> v126 = pto::Shape<1, 1, 1, 16, 512>();
  // pto: %attn_proj_fp32_inline1290__iter_v4_pview
  pto::Stride<81920, 81920, 81920, 5120, 1> v127 = pto::Stride<81920, 81920, 81920, 5120, 1>();
  // pto: %attn_proj_fp32_inline1290__iter_v4_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v128 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v3 + (v20 + v31), v126, v127);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE<Tile<TileType::Acc, float, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v128, v124);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}