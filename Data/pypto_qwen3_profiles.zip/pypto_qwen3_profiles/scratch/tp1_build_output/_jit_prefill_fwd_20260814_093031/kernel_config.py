# Kernel and Orchestration Configuration

from pathlib import Path

from simpler.task_interface import ArgDirection as _D

_ROOT_DIR = Path(__file__).parent

# Runtime configuration for tensormap_and_ringbuffer.
# AICPU thread count 0 selects the runtime's architecture default (a2a3: 4; a5: 5).
RUNTIME_CONFIG = {
	"runtime": "tensormap_and_ringbuffer",
	"aicpu_thread_num": 0,
}

ORCHESTRATION = {
	"source": str(_ROOT_DIR / "orchestration" / "prefill_fwd.cpp"),
	"function_name": "aicpu_orchestration_entry",
	"signature": [_D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.OUT],
}

KERNELS = [
	{"func_id": 0, "name": "token_embed_single", "source": str(_ROOT_DIR / "kernels" / "aiv" / "token_embed_single.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 1, "name": "rmsnorm", "source": str(_ROOT_DIR / "kernels" / "aiv" / "rmsnorm.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 2, "name": "q_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "q_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 3, "name": "kv_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "kv_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 4, "name": "rope_kv_cache", "source": str(_ROOT_DIR / "kernels" / "aiv" / "rope_kv_cache.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN]},
	{"func_id": 5, "name": "qk_pv_skew_probe_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_skew_probe_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT]},
	{"func_id": 6, "name": "qk_pv_skew_probe_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_skew_probe_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT]},
	{"func_id": 7, "name": "qk_pv_online_phase_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_online_phase_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 8, "name": "qk_pv_online_phase_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_online_phase_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 9, "name": "attention_finalize_phase", "source": str(_ROOT_DIR / "kernels" / "aiv" / "attention_finalize_phase.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 10, "name": "qk_pv_online_phase_0_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_online_phase_0_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 11, "name": "qk_pv_online_phase_0_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_online_phase_0_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 12, "name": "attention_finalize_phase_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "attention_finalize_phase_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 13, "name": "out_proj_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "out_proj_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 14, "name": "out_proj_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "out_proj_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 15, "name": "post_rmsnorm", "source": str(_ROOT_DIR / "kernels" / "aiv" / "post_rmsnorm.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 16, "name": "mlp_out_seed", "source": str(_ROOT_DIR / "kernels" / "aiv" / "mlp_out_seed.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 17, "name": "gate_up_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_up_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN, _D.INOUT, _D.IN]},
	{"func_id": 18, "name": "silu", "source": str(_ROOT_DIR / "kernels" / "aiv" / "silu.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 19, "name": "down_proj", "source": str(_ROOT_DIR / "kernels" / "aic" / "down_proj.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 20, "name": "mlp_out_cast", "source": str(_ROOT_DIR / "kernels" / "aiv" / "mlp_out_cast.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 21, "name": "save_prefill_last_token_single", "source": str(_ROOT_DIR / "kernels" / "aiv" / "save_prefill_last_token_single.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 22, "name": "token_embed_group", "source": str(_ROOT_DIR / "kernels" / "aiv" / "token_embed_group.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.IN, _D.INOUT, _D.IN, _D.IN]},
	{"func_id": 23, "name": "rmsnorm_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "rmsnorm_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 24, "name": "q_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "q_proj_0.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 25, "name": "kv_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "kv_proj_0.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN]},
	{"func_id": 26, "name": "rope_kv_cache_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "rope_kv_cache_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN, _D.IN]},
	{"func_id": 27, "name": "qk_pv_skew_probe_0_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_skew_probe_0_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT]},
	{"func_id": 28, "name": "qk_pv_skew_probe_0_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_skew_probe_0_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT, _D.INOUT]},
	{"func_id": 29, "name": "qk_pv_online_phase_1_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_online_phase_1_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 30, "name": "qk_pv_online_phase_1_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_online_phase_1_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 31, "name": "attention_finalize_phase_1", "source": str(_ROOT_DIR / "kernels" / "aiv" / "attention_finalize_phase_1.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 32, "name": "qk_pv_online_phase_2_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "qk_pv_online_phase_2_aic.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 33, "name": "qk_pv_online_phase_2_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "qk_pv_online_phase_2_aiv.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.INOUT, _D.INOUT, _D.IN, _D.IN, _D.IN, _D.IN, _D.INOUT]},
	{"func_id": 34, "name": "attention_finalize_phase_2", "source": str(_ROOT_DIR / "kernels" / "aiv" / "attention_finalize_phase_2.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 35, "name": "out_proj_aic_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "out_proj_aic_0.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 36, "name": "out_proj_aiv_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "out_proj_aiv_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 37, "name": "post_rmsnorm_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "post_rmsnorm_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 38, "name": "mlp_out_seed_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "mlp_out_seed_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 39, "name": "gate_up_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "gate_up_proj_0.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN, _D.INOUT, _D.IN]},
	{"func_id": 40, "name": "silu_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "silu_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 41, "name": "down_proj_0", "source": str(_ROOT_DIR / "kernels" / "aic" / "down_proj_0.cpp"), "core_type": "aic", "signature": [_D.INOUT, _D.IN, _D.IN]},
	{"func_id": 42, "name": "mlp_out_cast_0", "source": str(_ROOT_DIR / "kernels" / "aiv" / "mlp_out_cast_0.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 43, "name": "save_prefill_last_token_group", "source": str(_ROOT_DIR / "kernels" / "aiv" / "save_prefill_last_token_group.cpp"), "core_type": "aiv", "signature": [_D.INOUT, _D.IN]},
	{"func_id": 44, "name": "final_rmsnorm", "source": str(_ROOT_DIR / "kernels" / "aiv" / "final_rmsnorm.cpp"), "core_type": "aiv", "signature": [_D.IN, _D.OUT, _D.IN]},
	{"func_id": 45, "name": "lm_head", "source": str(_ROOT_DIR / "kernels" / "aic" / "lm_head.cpp"), "core_type": "aic", "signature": [_D.OUT, _D.IN, _D.IN]},
]
