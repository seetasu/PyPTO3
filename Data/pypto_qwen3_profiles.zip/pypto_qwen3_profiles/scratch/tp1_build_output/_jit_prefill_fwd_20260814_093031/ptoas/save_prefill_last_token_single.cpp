#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void save_prefill_last_token_single(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, int64_t v3) {
  const int64_t v4 = 5120;
  const int64_t v5 = 256;
  const int64_t v6 = 20;
  const int64_t v7 = 1;
  const int64_t v8 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i9 = v8; i9 < v6; i9 += v7) {
    // pto: %0
    int64_t v10 = (int64_t) ((uint64_t) i9 * (uint64_t) v5);
    // pto: %final_hidden_chunk__tile
    Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v11 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v7, v5);
    // pto: %final_hidden_chunk__tile
    uint64_t v12 = (uint64_t) v8;
    TASSIGN(v11, v12);
    // pto: %2
    int64_t v13 = v10 < v8 ? v8 : v10;
    // pto: %window_hidden__rv_v8_pview
    pto::Shape<1, 1, 1, 1, 256> v14 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %window_hidden__rv_v8_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v15 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %1, %window_hidden__rv_v8_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v16 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v2 + ((v8 + (v3 < v8 ? v8 : v3) * v4) + v13), v14, v15);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v11, v16);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %final_hidden__iter_v3_pview
    pto::Shape<1, 1, 1, 1, 256> v17 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %final_hidden__iter_v3_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v18 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %final_hidden__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v19 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v1 + (v8 + v13), v17, v18);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v19, v11);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}