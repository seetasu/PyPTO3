#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void q_proj(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  unsigned v8 = 4864;
  const int64_t v9 = 5120;
  const int64_t v10 = 4864;
  const int64_t v11 = 2;
  const int64_t v12 = 19;
  const int64_t v13 = 128;
  const int64_t v14 = 256;
  const int64_t v15 = 16;
  const int64_t v16 = 20;
  const int64_t v17 = 1;
  const int64_t v18 = 64;
  const int64_t v19 = 8192;
  const int64_t v20 = 32768;
  const int64_t v21 = 24576;
  const int64_t v22 = 16384;
  const int64_t v23 = 0;
  const int64_t v24 = 196608;
  const int64_t v25 = 65536;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %q_acc_inline268__tile_l0_c_phi
  Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v26 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
  // pto: %q_acc_inline268__tile_l0_c_phi
  uint64_t v27 = (uint64_t) v23;
  TASSIGN(v26, v27);
  // pto: %q_core_inline317__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i28 = (int64_t) v6; i28 < v16; i28 += v15) {
    // pto: %25
    int64_t v29 = (int64_t) ((uint64_t) i28 * (uint64_t) v14);
    // pto: %tile_a_inline277__tile
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
    // pto: %tile_a_inline277__tile
    uint64_t v31 = (uint64_t) v25;
    TASSIGN(v30, v31);
    // pto: %normed_tile_inline284__rv_v2_pview
    pto::Shape<1, 1, 1, 64, 256> v32 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %normed_tile_inline284__rv_v2_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v33 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %normed_tile_inline284__rv_v2_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v34 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2, v32, v33);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v30, v34);
    // pto: %tile_w_inline342__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %tile_w_inline342__tile
    uint64_t v36 = (uint64_t) v24;
    TASSIGN(v35, v36);
    // pto: %27
    int64_t v37 = v29 < v23 ? v23 : v29;
    // pto: %wq__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v38 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %wq__ssa_v0_pview
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v39 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %26, %wq__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v40 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v4 < v23 ? v23 : v4) * v9) + v37), v38, v39);
    TLOAD(v35, v40);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %q_acc_inline268__tile_l0_init
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
    // pto: %q_acc_inline268__tile_l0_init
    uint64_t v42 = (uint64_t) v23;
    TASSIGN(v41, v42);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j43 = v23; j43 < v14; j43 += v13) {
      // pto: %q_acc_inline268__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
      // pto: %q_acc_inline268__tile_l0_a
      uint64_t v45 = (uint64_t) v22;
      TASSIGN(v44, v45);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v44, v30, v23, j43);
      // pto: %q_acc_inline268__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %q_acc_inline268__tile_l0_b
      uint64_t v47 = (uint64_t) v23;
      TASSIGN(v46, v47);
      TEXTRACT(v46, v35, j43, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
      // pto: %0
      uint64_t v49 = (uint64_t) v21;
      TASSIGN(v48, v49);
      // pto: %28
      int64_t v50 = (int64_t) ((uint64_t) j43 + (uint64_t) v18);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v48, v30, v23, v50);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %1
      uint64_t v52 = (uint64_t) v20;
      TASSIGN(v51, v52);
      TEXTRACT(v51, v35, v50, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %30
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j43 == v23) {
        // pto: %q_acc_inline268__tile_l0_c_first
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %q_acc_inline268__tile_l0_c_first
        uint64_t v54 = (uint64_t) v23;
        TASSIGN(v53, v54);
        pipe_barrier(PIPE_M);
        TMATMUL(v53, v44, v46);
      } else {
        // pto: %q_acc_inline268__tile_l0_c_acc
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %q_acc_inline268__tile_l0_c_acc
        uint64_t v56 = (uint64_t) v23;
        TASSIGN(v55, v56);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v55, v55, v44, v46);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %2
      uint64_t v58 = (uint64_t) v23;
      TASSIGN(v57, v58);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v57, v57, v48, v51);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j59 = v17; j59 < v12; j59 += v11) {
      // pto: %31
      int64_t v60 = (int64_t) ((uint64_t) j59 * (uint64_t) v14);
      // pto: %33
      int64_t v61 = (int64_t) ((uint64_t) v60 + (uint64_t) v14);
      // pto: %tile_a_i_inline280__tile
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %tile_a_i_inline280__tile
      uint64_t v63 = (uint64_t) v23;
      TASSIGN(v62, v63);
      // pto: %35
      pto::Shape<1, 1, 1, 64, 256> v64 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %35
      pto::Stride<327680, 327680, 327680, 5120, 1> v65 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %34, %35
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v60 < v23 ? v23 : v60)), v64, v65);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v62, v66);
      // pto: %tile_w_i_inline388__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %tile_w_i_inline388__tile
      uint64_t v68 = (uint64_t) v24;
      TASSIGN(v67, v68);
      // pto: %36
      int64_t v69 = (int64_t) ((uint64_t) v4 + (uint64_t) v60);
      // pto: %39
      pto::Shape<1, 1, 1, 256, 256> v70 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %39
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v71 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %37, %39
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v72 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v69 < v23 ? v23 : v69) * v9) + v37), v70, v71);
      TLOAD(v67, v72);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %3
      uint64_t v74 = (uint64_t) v20;
      TASSIGN(v73, v74);
      // pto: %41
      pto::Shape<1, 1, 1, 64, 256> v75 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %41
      pto::Stride<327680, 327680, 327680, 5120, 1> v76 = pto::Stride<327680, 327680, 327680, 5120, 1>();
      // pto: %40, %41
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v77 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + (v23 + (v61 < v23 ? v23 : v61)), v75, v76);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v73, v77);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %4
      uint64_t v79 = (uint64_t) v25;
      TASSIGN(v78, v79);
      // pto: %42
      int64_t v80 = (int64_t) ((uint64_t) v4 + (uint64_t) v61);
      // pto: %45
      pto::Shape<1, 1, 1, 256, 256> v81 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %45
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v82 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %43, %45
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v83 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v80 < v23 ? v23 : v80) * v9) + v37), v81, v82);
      TLOAD(v78, v83);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k84 = v23; k84 < v14; k84 += v13) {
        // pto: %5
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
        // pto: %5
        uint64_t v86 = (uint64_t) v22;
        TASSIGN(v85, v86);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v85, v62, v23, k84);
        // pto: %6
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %6
        uint64_t v88 = (uint64_t) v23;
        TASSIGN(v87, v88);
        TEXTRACT(v87, v67, k84, v23);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %7
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
        // pto: %7
        uint64_t v90 = (uint64_t) v21;
        TASSIGN(v89, v90);
        // pto: %47
        int64_t v91 = (int64_t) ((uint64_t) k84 + (uint64_t) v18);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v89, v62, v23, v91);
        // pto: %8
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %8
        uint64_t v93 = (uint64_t) v20;
        TASSIGN(v92, v93);
        TEXTRACT(v92, v67, v91, v23);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %9
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %9
        uint64_t v95 = (uint64_t) v23;
        TASSIGN(v94, v95);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v94, v94, v85, v87);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %10
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %10
        uint64_t v97 = (uint64_t) v23;
        TASSIGN(v96, v97);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v96, v96, v89, v92);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k98 = v23; k98 < v14; k98 += v13) {
        // pto: %11
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
        // pto: %11
        uint64_t v100 = (uint64_t) v23;
        TASSIGN(v99, v100);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v99, v73, v23, k98);
        // pto: %12
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %12
        uint64_t v102 = (uint64_t) v23;
        TASSIGN(v101, v102);
        TEXTRACT(v101, v78, k98, v23);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %13
        Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
        // pto: %13
        uint64_t v104 = (uint64_t) v19;
        TASSIGN(v103, v104);
        // pto: %50
        int64_t v105 = (int64_t) ((uint64_t) k98 + (uint64_t) v18);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v103, v73, v23, v105);
        // pto: %14
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %14
        uint64_t v107 = (uint64_t) v20;
        TASSIGN(v106, v107);
        TEXTRACT(v106, v78, v105, v23);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %15
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %15
        uint64_t v109 = (uint64_t) v23;
        TASSIGN(v108, v109);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v108, v108, v99, v101);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %16
        Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
        // pto: %16
        uint64_t v111 = (uint64_t) v23;
        TASSIGN(v110, v111);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v110, v110, v103, v106);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %17
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
    // pto: %17
    uint64_t v113 = (uint64_t) v25;
    TASSIGN(v112, v113);
    // pto: %53
    pto::Shape<1, 1, 1, 64, 256> v114 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %53
    pto::Stride<327680, 327680, 327680, 5120, 1> v115 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %53
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v2 + v8, v114, v115);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v112, v116);
    // pto: %18
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %18
    uint64_t v118 = (uint64_t) v24;
    TASSIGN(v117, v118);
    // pto: %54
    int64_t v119 = (int64_t) ((uint64_t) v4 + (uint64_t) v10);
    // pto: %57
    pto::Shape<1, 1, 1, 256, 256> v120 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %57
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v121 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %55, %57
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v122 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v119 < v23 ? v23 : v119) * v9) + v37), v120, v121);
    TLOAD(v117, v122);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j123 = v23; j123 < v14; j123 += v13) {
      // pto: %19
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
      // pto: %19
      uint64_t v125 = (uint64_t) v22;
      TASSIGN(v124, v125);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v124, v112, v23, j123);
      // pto: %20
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %20
      uint64_t v127 = (uint64_t) v23;
      TASSIGN(v126, v127);
      TEXTRACT(v126, v117, j123, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %21
      Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Left, bfloat16_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v18);
      // pto: %21
      uint64_t v129 = (uint64_t) v21;
      TASSIGN(v128, v129);
      // pto: %59
      int64_t v130 = (int64_t) ((uint64_t) j123 + (uint64_t) v18);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v128, v112, v23, v130);
      // pto: %22
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %22
      uint64_t v132 = (uint64_t) v20;
      TASSIGN(v131, v132);
      TEXTRACT(v131, v117, v130, v23);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %23
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %23
      uint64_t v134 = (uint64_t) v23;
      TASSIGN(v133, v134);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v133, v133, v124, v126);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %24
      Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
      // pto: %24
      uint64_t v136 = (uint64_t) v23;
      TASSIGN(v135, v136);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v135, v135, v128, v131);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %q_acc_inline268__rv_v2
    Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Acc, float, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v14);
    // pto: %q_acc_inline268__rv_v2
    uint64_t v138 = (uint64_t) v23;
    TASSIGN(v137, v138);
    // pto: %q_proj_tile_inline316__iter_v1_pview
    pto::Shape<1, 1, 1, 64, 256> v139 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %q_proj_tile_inline316__iter_v1_pview
    pto::Stride<327680, 327680, 327680, 5120, 1> v140 = pto::Stride<327680, 327680, 327680, 5120, 1>();
    // pto: %q_proj_tile_inline316__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND> v141 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<327680, 327680, 327680, 5120, 1>, pto::Layout::ND>(v1 + (v23 + v37), v139, v140);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v141, v137);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}