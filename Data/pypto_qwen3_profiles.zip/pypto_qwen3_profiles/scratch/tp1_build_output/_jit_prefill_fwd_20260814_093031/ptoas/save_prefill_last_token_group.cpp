#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void save_prefill_last_token_group(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4) {
  const int64_t v5 = 5120;
  const int64_t v6 = 256;
  const int64_t v7 = 20;
  const int64_t v8 = 1;
  const int64_t v9 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i10 = v9; i10 < v7; i10 += v8) {
    // pto: %0
    int64_t v11 = (int64_t) ((uint64_t) i10 * (uint64_t) v6);
    // pto: %final_hidden_chunk__tile
    Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v12 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v8, v6);
    // pto: %final_hidden_chunk__tile
    uint64_t v13 = (uint64_t) v9;
    TASSIGN(v12, v13);
    // pto: %2
    int64_t v14 = v11 < v9 ? v9 : v11;
    // pto: %group_hidden__rv_v9_pview
    pto::Shape<1, 1, 1, 1, 256> v15 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %group_hidden__rv_v9_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v16 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %1, %group_hidden__rv_v9_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v17 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v2 + ((v9 + (v3 < v9 ? v9 : v3) * v5) + v14), v15, v16);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v12, v17);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %final_hidden__iter_v10_pview
    pto::Shape<1, 1, 1, 1, 256> v18 = pto::Shape<1, 1, 1, 1, 256>();
    // pto: %final_hidden__iter_v10_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v19 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %3, %final_hidden__iter_v10_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v20 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v1 + ((v9 + (v4 < v9 ? v9 : v4) * v5) + v14), v18, v19);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v20, v12);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}