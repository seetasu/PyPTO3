#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void final_rmsnorm(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4) {
  SaturationMode v5 = SaturationMode::OFF;
  RoundMode v6 = RoundMode::CAST_ROUND;
  const int64_t v7 = 5120;
  const float v8 = 9.99999997E-7f;
  const float v9 = 1.95312503E-4f;
  const int64_t v10 = 128;
  const int64_t v11 = 40;
  const float v12 = 0.0f;
  const int64_t v13 = 1;
  const int64_t v14 = 16;
  const int64_t v15 = 16448;
  const int64_t v16 = 64;
  const int64_t v17 = 8256;
  const int64_t v18 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %sq_sum_inline655__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %sq_sum_inline655__tile
  uint64_t v20 = (uint64_t) v18;
  TASSIGN(v19, v20);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v19, v12);
  for (int64_t i21 = v18; i21 < v11; i21 += v13) {
    // pto: %10
    int64_t v22 = (int64_t) ((uint64_t) i21 * (uint64_t) v10);
    // pto: %t__tile
    Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile
    uint64_t v24 = (uint64_t) v17;
    TASSIGN(v23, v24);
    // pto: %final_hidden__rv_v2_pview
    pto::Shape<1, 1, 1, 16, 128> v25 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %final_hidden__rv_v2_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v26 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %11, %final_hidden__rv_v2_pview, %12
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v27 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + ((v18 + (v4 < v18 ? v18 : v4) * v7) + (v22 < v18 ? v18 : v22)), v25, v26);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v23, v27);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %final_sq_chunk_inline663__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v28 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_sq_chunk_inline663__tile
    uint64_t v29 = (uint64_t) v16;
    TASSIGN(v28, v29);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCVT(v28, v23, v6, v5);
    // pto: %0
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %0
    uint64_t v31 = (uint64_t) v16;
    TASSIGN(v30, v31);
    pipe_barrier(PIPE_V);
    TMUL(v30, v28, v28);
    // pto: %tmp_tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %tmp_tile
    uint64_t v33 = (uint64_t) v17;
    TASSIGN(v32, v33);
    // pto: %1
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
    // pto: %1
    uint64_t v35 = (uint64_t) v15;
    TASSIGN(v34, v35);
    pipe_barrier(PIPE_V);
    TROWSUM(v34, v30, v32);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %2
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %2
    uint64_t v37 = (uint64_t) v15;
    TASSIGN(v36, v37);
    // pto: %3
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
    // pto: %3
    uint64_t v39 = (uint64_t) v18;
    TASSIGN(v38, v39);
    pipe_barrier(PIPE_V);
    TADD(v38, v19, v36);
  }
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  // pto: %4
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %4
  uint64_t v41 = (uint64_t) v16;
  TASSIGN(v40, v41);
  pipe_barrier(PIPE_V);
  TMULS(v40, v19, v9);
  // pto: %5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %5
  uint64_t v43 = (uint64_t) v16;
  TASSIGN(v42, v43);
  pipe_barrier(PIPE_V);
  TADDS(v42, v40, v8);
  // pto: %6
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %6
  uint64_t v45 = (uint64_t) v18;
  TASSIGN(v44, v45);
  pipe_barrier(PIPE_V);
  TRSQRT(v44, v42);
  // pto: %inv_rms_final_inline666__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %inv_rms_final_inline666__tile
  uint64_t v47 = (uint64_t) v18;
  TASSIGN(v46, v47);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  for (int64_t i48 = v18; i48 < v11; i48 += v13) {
    // pto: %13
    int64_t v49 = (int64_t) ((uint64_t) i48 * (uint64_t) v10);
    // pto: %7
    Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %7
    uint64_t v51 = (uint64_t) v17;
    TASSIGN(v50, v51);
    // pto: %14
    int64_t v52 = v4 < v18 ? v18 : v4;
    // pto: %15
    int64_t v53 = v49 < v18 ? v18 : v49;
    // pto: %16
    pto::Shape<1, 1, 1, 16, 128> v54 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %16
    pto::Stride<81920, 81920, 81920, 5120, 1> v55 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %16
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v1 + ((v18 + v52 * v7) + v53), v54, v55);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v50, v56);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %final_hidden_chunk_inline665__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_hidden_chunk_inline665__tile
    uint64_t v58 = (uint64_t) v16;
    TASSIGN(v57, v58);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TCVT(v57, v50, v6, v5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %final_gamma_inline667__tile
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v10);
    // pto: %final_gamma_inline667__tile
    uint64_t v60 = (uint64_t) v17;
    TASSIGN(v59, v60);
    // pto: %final_norm_weight__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 128> v61 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %final_norm_weight__ssa_v0_pview
    pto::Stride<5120, 5120, 5120, 5120, 1> v62 = pto::Stride<5120, 5120, 5120, 5120, 1>();
    // pto: %final_norm_weight__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v63 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + (v18 + v53), v61, v62);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v59, v63);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %8
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %8
    uint64_t v65 = (uint64_t) v16;
    TASSIGN(v64, v65);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v64, v57, v46);
    // pto: %final_normed_chunk_inline668__tile
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %final_normed_chunk_inline668__tile
    uint64_t v67 = (uint64_t) v16;
    TASSIGN(v66, v67);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPANDMUL(v66, v64, v59);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    // pto: %9
    Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %9
    uint64_t v69 = (uint64_t) v16;
    TASSIGN(v68, v69);
    pipe_barrier(PIPE_V);
    TCVT(v68, v66, v6, v5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %final_normed_inline657__iter_v3_pview
    pto::Shape<1, 1, 1, 16, 128> v70 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %final_normed_inline657__iter_v3_pview
    pto::Stride<81920, 81920, 81920, 5120, 1> v71 = pto::Stride<81920, 81920, 81920, 5120, 1>();
    // pto: %final_normed_inline657__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND> v72 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<81920, 81920, 81920, 5120, 1>, pto::Layout::ND>(v2 + ((v18 + v52 * v7) + v53), v70, v71);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v72, v68);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}