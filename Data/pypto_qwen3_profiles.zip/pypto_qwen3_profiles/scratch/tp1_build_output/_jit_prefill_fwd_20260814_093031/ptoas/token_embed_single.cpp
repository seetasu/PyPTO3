#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void token_embed_single(__gm__ bfloat16_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, int32_t v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  const int64_t v10 = 256;
  const int64_t v11 = 64;
  const int64_t v12 = 1;
  const int64_t v13 = 5120;
  const int64_t v14 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %tile_rem__ssa_v0, %0
  int64_t v15 = (int64_t) ((uint64_t) ((int64_t) v8) * (uint64_t) v11);
  // pto: %1, %2, %3
  int64_t v16 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) v4) - (uint64_t) v5)) - (uint64_t) v15);
  // pto: %4
  int64_t v17 = v16 < v14 ? v14 : v16;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i18 = v14; i18 < v11; i18 += v12) {
    // pto: %5, %6
    if (i18 < (v17 < v11 ? v17 : v11)) {
      // pto: %10
      int64_t v19 = (int64_t) ((uint64_t) v15 + (uint64_t) i18);
      // pto: %7, %8, %9, %token_id__tile
      int32_t v20 = (v2)[(int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v6 + (uint64_t) v5)) + (uint64_t) v15)) + (uint64_t) i18)];
      // pto: %11
      int64_t v21 = (int64_t) v20;
      for (int64_t j22 = v14; j22 < v13; j22 += v10) {
        // pto: %hidden_chunk__tile
        Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
        // pto: %hidden_chunk__tile
        uint64_t v24 = (uint64_t) v14;
        TASSIGN(v23, v24);
        // pto: %13
        int64_t v25 = j22 < v14 ? v14 : j22;
        // pto: %embed_weight__ssa_v0_pview
        pto::Shape<1, 1, 1, 1, 256> v26 = pto::Shape<1, 1, 1, 1, 256>();
        // pto: %embed_weight__ssa_v0_pview
        pto::Stride<5120, 5120, 5120, 5120, 1> v27 = pto::Stride<5120, 5120, 5120, 5120, 1>();
        // pto: %12, %embed_weight__ssa_v0_pview
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v28 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + ((v14 + (v21 < v14 ? v14 : v21) * v13) + v25), v26, v27);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v23, v28);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        // pto: %window_hidden__iter_v3_pview
        pto::Shape<1, 1, 1, 1, 256> v29 = pto::Shape<1, 1, 1, 1, 256>();
        // pto: %window_hidden__iter_v3_pview
        pto::Stride<5120, 5120, 5120, 5120, 1> v30 = pto::Stride<5120, 5120, 5120, 5120, 1>();
        // pto: %14, %window_hidden__iter_v3_pview
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v31 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v1 + ((v14 + (v19 < v14 ? v14 : v19) * v13) + v25), v29, v30);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        TSTORE(v31, v23);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      }
    }
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}