#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void attention_finalize_phase_2(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, int32_t v4, int32_t v5, int32_t v6, int32_t v7) {
  const int64_t v8 = 5120;
  SaturationMode v9 = SaturationMode::OFF;
  RoundMode v10 = RoundMode::CAST_ROUND;
  const int64_t v11 = 640;
  const int64_t v12 = 16;
  const int64_t v13 = 1024;
  const int64_t v14 = 5;
  const int64_t v15 = 8;
  const int64_t v16 = 48;
  const int64_t v17 = 512;
  const int64_t v18 = 128;
  const int64_t v19 = 1;
  const int64_t v20 = 64;
  const int64_t v21 = 8192;
  const int64_t v22 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %final_core_inline1082__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i23 = (int64_t) v6; i23 < v17; i23 += v16) {
    // pto: %0
    int64_t v24 = i23 / v20;
    // pto: %2, %1
    int64_t v25 = (int64_t) ((uint64_t) i23 - (uint64_t) ((int64_t) ((uint64_t) v24 * (uint64_t) v20)));
    // pto: %3
    int64_t v26 = v25 / v15;
    // pto: %5, %4
    int64_t v27 = (int64_t) ((uint64_t) v25 - (uint64_t) ((int64_t) ((uint64_t) v26 * (uint64_t) v15)));
    // pto: %6, %7
    int64_t v28 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v24 * (uint64_t) v15)) + (uint64_t) v26);
    // pto: %8, %9
    if (v28 < (int64_t) v4) {
      // pto: %10, %11
      int64_t v29 = (int64_t) ((uint64_t) ((int64_t) v5) + (uint64_t) v28);
      // pto: %15, %17, %16, %19, %18
      int64_t v30 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v24 * (uint64_t) v13)) + (uint64_t) ((int64_t) ((uint64_t) v27 * (uint64_t) v18)))) + (uint64_t) ((int64_t) ((uint64_t) v26 * (uint64_t) v12)));
      // pto: %oi_inline1019__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v18);
      // pto: %oi_inline1019__tile
      uint64_t v32 = (uint64_t) v22;
      TASSIGN(v31, v32);
      // pto: %25
      int64_t v33 = v30 < v22 ? v22 : v30;
      // pto: %oi_tmp_phase_inline482__rv_v32_pview
      pto::Shape<1, 1, 1, 16, 128> v34 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %oi_tmp_phase_inline482__rv_v32_pview
      pto::Stride<2048, 2048, 2048, 128, 1> v35 = pto::Stride<2048, 2048, 2048, 128, 1>();
      // pto: %oi_tmp_phase_inline482__rv_v32_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v36 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v2 + (v22 + v33 * v18), v34, v35);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v31, v36);
      // pto: %li_inline1039__tile
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v37 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v19);
      // pto: %li_inline1039__tile
      uint64_t v38 = (uint64_t) v21;
      TASSIGN(v37, v38);
      // pto: %cur_li_phase_inline542__rv_v32_pview
      pto::Shape<1, 1, 1, 16, 1> v39 = pto::Shape<1, 1, 1, 16, 1>();
      // pto: %cur_li_phase_inline542__rv_v32_pview
      pto::Stride<16, 16, 16, 1, 8192> v40 = pto::Stride<16, 16, 16, 1, 8192>();
      // pto: %cur_li_phase_inline542__rv_v32_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 8192>, pto::Layout::DN> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 8192>, pto::Layout::DN>(v3 + (v22 + v33), v39, v40);
      TLOAD(v37, v41);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %ctx_inline1037__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v18);
      // pto: %ctx_inline1037__tile
      uint64_t v43 = (uint64_t) v22;
      TASSIGN(v42, v43);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDDIV(v42, v31, v37);
      // pto: %ctx_bf16_inline1018__tile
      Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v18);
      // pto: %ctx_bf16_inline1018__tile
      uint64_t v45 = (uint64_t) v22;
      TASSIGN(v44, v45);
      pipe_barrier(PIPE_V);
      TCVT(v44, v42, v10, v9);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %t__tile
      Tile<TileType::Vec, bfloat16_t, 5, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Vec, bfloat16_t, 5, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v18);
      // pto: %t__tile
      uint64_t v47 = (uint64_t) v22;
      TASSIGN(v46, v47);
      // pto: %ctx_row_inline1017__tile
      Tile<TileType::Vec, bfloat16_t, 1, 640, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, bfloat16_t, 1, 640, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v11);
      // pto: %ctx_row_inline1017__tile
      uint64_t v49 = (uint64_t) v22;
      TASSIGN(v48, v49);
      int64_t v50 = (int64_t) ((uint64_t) v27 * (uint64_t) v11);
      // pto: %attn_tile_inline519__iter_v14_pview
      pto::Shape<1, 1, 1, 1, 640> v51 = pto::Shape<1, 1, 1, 1, 640>();
      // pto: %attn_tile_inline519__iter_v14_pview
      pto::Stride<5120, 5120, 5120, 5120, 1> v52 = pto::Stride<5120, 5120, 5120, 5120, 1>();
      // pto: %27, %attn_tile_inline519__iter_v14_pview, %29
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 640>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 640>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v1 + ((v22 + (v29 < v22 ? v22 : v29) * v8) + (v50 < v22 ? v22 : v50)), v51, v52);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v53, v48);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    }
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}