#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void gate_up_proj(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, __gm__ bfloat16_t* v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  const int64_t v13 = 17408;
  const int64_t v14 = 5120;
  const int64_t v15 = 14;
  const int64_t v16 = 4864;
  const int64_t v17 = 2;
  const int64_t v18 = 19;
  const int64_t v19 = 64;
  const int64_t v20 = 256;
  const int64_t v21 = 20;
  const int64_t v22 = 34;
  const int64_t v23 = 1;
  const int64_t v24 = 128;
  const int64_t v25 = 16384;
  const int64_t v26 = 65536;
  const int64_t v27 = 32768;
  const int64_t v28 = 49152;
  const int64_t v29 = 0;
  const int64_t v30 = 262144;
  const int64_t v31 = 131072;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %gate_acc_inline347__tile_l0_c_phi
  Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
  // pto: %gate_acc_inline347__tile_l0_c_phi
  uint64_t v33 = (uint64_t) v29;
  TASSIGN(v32, v33);
  // pto: %up_acc_inline226__tile_l0_c_phi
  Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
  // pto: %up_acc_inline226__tile_l0_c_phi
  uint64_t v35 = (uint64_t) v29;
  TASSIGN(v34, v35);
  // pto: %gu_core_inline230__ssa_v0
  int64_t v36 = (int64_t) v11;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i37 = v36; i37 < v22; i37 += v21) {
    // pto: %52, %53
    int64_t v38 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v6 + (uint64_t) i37)) * (uint64_t) v20);
    // pto: %pc0_inline229__tile
    Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %pc0_inline229__tile
    uint64_t v40 = (uint64_t) v31;
    TASSIGN(v39, v40);
    // pto: %54
    int64_t v41 = v7 < v29 ? v29 : v7;
    // pto: %post_norm_all_inline273__ssa_v0_pview
    pto::Shape<1, 1, 1, 128, 256> v42 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %post_norm_all_inline273__ssa_v0_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v43 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %post_norm_all_inline273__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v44 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v29 + v41 * v14), v42, v43);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v39, v44);
    // pto: %wg0_inline361__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
    // pto: %wg0_inline361__tile
    uint64_t v46 = (uint64_t) v30;
    TASSIGN(v45, v46);
    // pto: %56
    int64_t v47 = v38 < v29 ? v29 : v38;
    // pto: %w_gate__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v48 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %w_gate__ssa_v0_pview
    pto::Stride<4456448, 4456448, 4456448, 17408, 1> v49 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
    // pto: %55, %w_gate__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v50 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v3 + ((v29 + (v8 < v29 ? v29 : v8) * v13) + v47), v48, v49);
    TLOAD(v45, v50);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %gate_acc_inline347__tile_l0_init
    Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %gate_acc_inline347__tile_l0_init
    uint64_t v52 = (uint64_t) v29;
    TASSIGN(v51, v52);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j53 = v29; j53 < v20; j53 += v24) {
      // pto: %gate_acc_inline347__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %gate_acc_inline347__tile_l0_a
      uint64_t v55 = (uint64_t) v28;
      TASSIGN(v54, v55);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v54, v39, v29, j53);
      // pto: %gate_acc_inline347__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %gate_acc_inline347__tile_l0_b
      uint64_t v57 = (uint64_t) v27;
      TASSIGN(v56, v57);
      TEXTRACT(v56, v45, j53, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %0
      uint64_t v59 = (uint64_t) v29;
      TASSIGN(v58, v59);
      // pto: %57
      int64_t v60 = (int64_t) ((uint64_t) j53 + (uint64_t) v19);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v58, v39, v29, v60);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %1
      uint64_t v62 = (uint64_t) v29;
      TASSIGN(v61, v62);
      TEXTRACT(v61, v45, v60, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %59
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j53 == v29) {
        // pto: %gate_acc_inline347__tile_l0_c_first
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %gate_acc_inline347__tile_l0_c_first
        uint64_t v64 = (uint64_t) v29;
        TASSIGN(v63, v64);
        pipe_barrier(PIPE_M);
        TMATMUL(v63, v54, v56);
      } else {
        // pto: %gate_acc_inline347__tile_l0_c_acc
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %gate_acc_inline347__tile_l0_c_acc
        uint64_t v66 = (uint64_t) v29;
        TASSIGN(v65, v66);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v65, v65, v54, v56);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %2
      uint64_t v68 = (uint64_t) v29;
      TASSIGN(v67, v68);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v67, v67, v58, v61);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    for (int64_t j69 = v23; j69 < v18; j69 += v17) {
      // pto: %60
      int64_t v70 = (int64_t) ((uint64_t) j69 * (uint64_t) v20);
      // pto: %62
      int64_t v71 = (int64_t) ((uint64_t) v70 + (uint64_t) v20);
      // pto: %pci_inline233__tile
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %pci_inline233__tile
      uint64_t v73 = (uint64_t) v29;
      TASSIGN(v72, v73);
      // pto: %65
      pto::Shape<1, 1, 1, 128, 256> v74 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %65
      pto::Stride<655360, 655360, 655360, 5120, 1> v75 = pto::Stride<655360, 655360, 655360, 5120, 1>();
      // pto: %65, %64
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v76 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + ((v29 + v41 * v14) + (v70 < v29 ? v29 : v70)), v74, v75);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v72, v76);
      // pto: %wgi_inline228__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %wgi_inline228__tile
      uint64_t v78 = (uint64_t) v30;
      TASSIGN(v77, v78);
      // pto: %66
      int64_t v79 = (int64_t) ((uint64_t) v8 + (uint64_t) v70);
      // pto: %69
      pto::Shape<1, 1, 1, 256, 256> v80 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %69
      pto::Stride<4456448, 4456448, 4456448, 17408, 1> v81 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
      // pto: %67, %69
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v3 + ((v29 + (v79 < v29 ? v29 : v79) * v13) + v47), v80, v81);
      TLOAD(v77, v82);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %3
      uint64_t v84 = (uint64_t) v26;
      TASSIGN(v83, v84);
      // pto: %72
      pto::Shape<1, 1, 1, 128, 256> v85 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %72
      pto::Stride<655360, 655360, 655360, 5120, 1> v86 = pto::Stride<655360, 655360, 655360, 5120, 1>();
      // pto: %72, %71
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v87 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + ((v29 + v41 * v14) + (v71 < v29 ? v29 : v71)), v85, v86);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v83, v87);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %4
      uint64_t v89 = (uint64_t) v31;
      TASSIGN(v88, v89);
      // pto: %73
      int64_t v90 = (int64_t) ((uint64_t) v8 + (uint64_t) v71);
      // pto: %76
      pto::Shape<1, 1, 1, 256, 256> v91 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %76
      pto::Stride<4456448, 4456448, 4456448, 17408, 1> v92 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
      // pto: %74, %76
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v3 + ((v29 + (v90 < v29 ? v29 : v90) * v13) + v47), v91, v92);
      TLOAD(v88, v93);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k94 = v29; k94 < v20; k94 += v24) {
        // pto: %5
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %5
        uint64_t v96 = (uint64_t) v28;
        TASSIGN(v95, v96);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v95, v72, v29, k94);
        // pto: %6
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %6
        uint64_t v98 = (uint64_t) v27;
        TASSIGN(v97, v98);
        TEXTRACT(v97, v77, k94, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %7
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %7
        uint64_t v100 = (uint64_t) v29;
        TASSIGN(v99, v100);
        // pto: %78
        int64_t v101 = (int64_t) ((uint64_t) k94 + (uint64_t) v19);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v99, v72, v29, v101);
        // pto: %8
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %8
        uint64_t v103 = (uint64_t) v29;
        TASSIGN(v102, v103);
        TEXTRACT(v102, v77, v101, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %9
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %9
        uint64_t v105 = (uint64_t) v29;
        TASSIGN(v104, v105);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v104, v104, v95, v97);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %10
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %10
        uint64_t v107 = (uint64_t) v29;
        TASSIGN(v106, v107);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v106, v106, v99, v102);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k108 = v29; k108 < v20; k108 += v24) {
        // pto: %11
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %11
        uint64_t v110 = (uint64_t) v25;
        TASSIGN(v109, v110);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v109, v83, v29, k108);
        // pto: %12
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %12
        uint64_t v112 = (uint64_t) v27;
        TASSIGN(v111, v112);
        TEXTRACT(v111, v88, k108, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %13
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %13
        uint64_t v114 = (uint64_t) v27;
        TASSIGN(v113, v114);
        // pto: %81
        int64_t v115 = (int64_t) ((uint64_t) k108 + (uint64_t) v19);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v113, v83, v29, v115);
        // pto: %14
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %14
        uint64_t v117 = (uint64_t) v29;
        TASSIGN(v116, v117);
        TEXTRACT(v116, v88, v115, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %15
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %15
        uint64_t v119 = (uint64_t) v29;
        TASSIGN(v118, v119);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v118, v118, v109, v111);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %16
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %16
        uint64_t v121 = (uint64_t) v29;
        TASSIGN(v120, v121);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v120, v120, v113, v116);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %17
    Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %17
    uint64_t v123 = (uint64_t) v31;
    TASSIGN(v122, v123);
    // pto: %85
    pto::Shape<1, 1, 1, 128, 256> v124 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %85
    pto::Stride<655360, 655360, 655360, 5120, 1> v125 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %85
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v126 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v41 * v14), v124, v125);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    TLOAD(v122, v126);
    // pto: %18
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
    // pto: %18
    uint64_t v128 = (uint64_t) v30;
    TASSIGN(v127, v128);
    // pto: %86
    int64_t v129 = (int64_t) ((uint64_t) v8 + (uint64_t) v16);
    // pto: %89
    pto::Shape<1, 1, 1, 256, 256> v130 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %89
    pto::Stride<4456448, 4456448, 4456448, 17408, 1> v131 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
    // pto: %87, %89
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v3 + ((v29 + (v129 < v29 ? v29 : v129) * v13) + v47), v130, v131);
    TLOAD(v127, v132);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j133 = v29; j133 < v20; j133 += v24) {
      // pto: %19
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %19
      uint64_t v135 = (uint64_t) v28;
      TASSIGN(v134, v135);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v134, v122, v29, j133);
      // pto: %20
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %20
      uint64_t v137 = (uint64_t) v27;
      TASSIGN(v136, v137);
      TEXTRACT(v136, v127, j133, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %21
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %21
      uint64_t v139 = (uint64_t) v29;
      TASSIGN(v138, v139);
      // pto: %91
      int64_t v140 = (int64_t) ((uint64_t) j133 + (uint64_t) v19);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v138, v122, v29, v140);
      // pto: %22
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %22
      uint64_t v142 = (uint64_t) v29;
      TASSIGN(v141, v142);
      TEXTRACT(v141, v127, v140, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      // pto: %23
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %23
      uint64_t v144 = (uint64_t) v29;
      TASSIGN(v143, v144);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v143, v143, v134, v136);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %24
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %24
      uint64_t v146 = (uint64_t) v29;
      TASSIGN(v145, v146);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
      TMATMUL_ACC(v145, v145, v138, v141);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %gate_acc_inline347__rv_v2
    Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %gate_acc_inline347__rv_v2
    uint64_t v148 = (uint64_t) v29;
    TASSIGN(v147, v148);
    // pto: %93
    int64_t v149 = (int64_t) ((uint64_t) i37 * (uint64_t) v20);
    // pto: %gate_acc_b_inline235__iter_v1_pview
    pto::Shape<1, 1, 1, 128, 256> v150 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %gate_acc_b_inline235__iter_v1_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v151 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %94, %gate_acc_b_inline235__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v152 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v1 + (v29 + (v149 < v29 ? v29 : v149)), v150, v151);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v152, v147);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %95, %96
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  for (int64_t i153 = (int64_t) ((uint64_t) v36 + (uint64_t) v15) % v21; i153 < v22; i153 += v21) {
    // pto: %97, %98
    int64_t v154 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v6 + (uint64_t) i153)) * (uint64_t) v20);
    // pto: %25
    Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %25
    uint64_t v156 = (uint64_t) v31;
    TASSIGN(v155, v156);
    // pto: %99
    int64_t v157 = v7 < v29 ? v29 : v7;
    // pto: %100
    pto::Shape<1, 1, 1, 128, 256> v158 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %100
    pto::Stride<655360, 655360, 655360, 5120, 1> v159 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %100
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v160 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v29 + v157 * v14), v158, v159);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    TLOAD(v155, v160);
    // pto: %wu0_inline287__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
    // pto: %wu0_inline287__tile
    uint64_t v162 = (uint64_t) v30;
    TASSIGN(v161, v162);
    // pto: %102
    int64_t v163 = v154 < v29 ? v29 : v154;
    // pto: %w_up__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v164 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %w_up__ssa_v0_pview
    pto::Stride<4456448, 4456448, 4456448, 17408, 1> v165 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
    // pto: %101, %w_up__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v166 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v5 + ((v29 + (v8 < v29 ? v29 : v8) * v13) + v163), v164, v165);
    TLOAD(v161, v166);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    // pto: %up_acc_inline226__tile_l0_init
    Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %up_acc_inline226__tile_l0_init
    uint64_t v168 = (uint64_t) v29;
    TASSIGN(v167, v168);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j169 = v29; j169 < v20; j169 += v24) {
      // pto: %up_acc_inline226__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %up_acc_inline226__tile_l0_a
      uint64_t v171 = (uint64_t) v28;
      TASSIGN(v170, v171);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v170, v155, v29, j169);
      // pto: %up_acc_inline226__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %up_acc_inline226__tile_l0_b
      uint64_t v173 = (uint64_t) v27;
      TASSIGN(v172, v173);
      TEXTRACT(v172, v161, j169, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %26
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %26
      uint64_t v175 = (uint64_t) v29;
      TASSIGN(v174, v175);
      // pto: %103
      int64_t v176 = (int64_t) ((uint64_t) j169 + (uint64_t) v19);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v174, v155, v29, v176);
      // pto: %27
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %27
      uint64_t v178 = (uint64_t) v29;
      TASSIGN(v177, v178);
      TEXTRACT(v177, v161, v176, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %105
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j169 == v29) {
        // pto: %up_acc_inline226__tile_l0_c_first
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %up_acc_inline226__tile_l0_c_first
        uint64_t v180 = (uint64_t) v29;
        TASSIGN(v179, v180);
        pipe_barrier(PIPE_M);
        TMATMUL(v179, v170, v172);
      } else {
        // pto: %up_acc_inline226__tile_l0_c_acc
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %up_acc_inline226__tile_l0_c_acc
        uint64_t v182 = (uint64_t) v29;
        TASSIGN(v181, v182);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v181, v181, v170, v172);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %28
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %28
      uint64_t v184 = (uint64_t) v29;
      TASSIGN(v183, v184);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v183, v183, v174, v177);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    for (int64_t j185 = v23; j185 < v18; j185 += v17) {
      // pto: %106
      int64_t v186 = (int64_t) ((uint64_t) j185 * (uint64_t) v20);
      // pto: %108
      int64_t v187 = (int64_t) ((uint64_t) v186 + (uint64_t) v20);
      // pto: %29
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %29
      uint64_t v189 = (uint64_t) v29;
      TASSIGN(v188, v189);
      // pto: %111
      pto::Shape<1, 1, 1, 128, 256> v190 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %111
      pto::Stride<655360, 655360, 655360, 5120, 1> v191 = pto::Stride<655360, 655360, 655360, 5120, 1>();
      // pto: %111, %110
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v192 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + ((v29 + v157 * v14) + (v186 < v29 ? v29 : v186)), v190, v191);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v188, v192);
      // pto: %wui_inline225__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %wui_inline225__tile
      uint64_t v194 = (uint64_t) v30;
      TASSIGN(v193, v194);
      // pto: %112
      int64_t v195 = (int64_t) ((uint64_t) v8 + (uint64_t) v186);
      // pto: %115
      pto::Shape<1, 1, 1, 256, 256> v196 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %115
      pto::Stride<4456448, 4456448, 4456448, 17408, 1> v197 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
      // pto: %113, %115
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v198 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v5 + ((v29 + (v195 < v29 ? v29 : v195) * v13) + v163), v196, v197);
      TLOAD(v193, v198);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %30
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %30
      uint64_t v200 = (uint64_t) v26;
      TASSIGN(v199, v200);
      // pto: %118
      pto::Shape<1, 1, 1, 128, 256> v201 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %118
      pto::Stride<655360, 655360, 655360, 5120, 1> v202 = pto::Stride<655360, 655360, 655360, 5120, 1>();
      // pto: %118, %117
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v203 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + ((v29 + v157 * v14) + (v187 < v29 ? v29 : v187)), v201, v202);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v199, v203);
      // pto: %31
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
      // pto: %31
      uint64_t v205 = (uint64_t) v31;
      TASSIGN(v204, v205);
      // pto: %119
      int64_t v206 = (int64_t) ((uint64_t) v8 + (uint64_t) v187);
      // pto: %122
      pto::Shape<1, 1, 1, 256, 256> v207 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %122
      pto::Stride<4456448, 4456448, 4456448, 17408, 1> v208 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
      // pto: %120, %122
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v209 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v5 + ((v29 + (v206 < v29 ? v29 : v206) * v13) + v163), v207, v208);
      TLOAD(v204, v209);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t k210 = v29; k210 < v20; k210 += v24) {
        // pto: %32
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %32
        uint64_t v212 = (uint64_t) v28;
        TASSIGN(v211, v212);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v211, v188, v29, k210);
        // pto: %33
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %33
        uint64_t v214 = (uint64_t) v27;
        TASSIGN(v213, v214);
        TEXTRACT(v213, v193, k210, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %34
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %34
        uint64_t v216 = (uint64_t) v29;
        TASSIGN(v215, v216);
        // pto: %124
        int64_t v217 = (int64_t) ((uint64_t) k210 + (uint64_t) v19);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        TEXTRACT(v215, v188, v29, v217);
        // pto: %35
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %35
        uint64_t v219 = (uint64_t) v29;
        TASSIGN(v218, v219);
        TEXTRACT(v218, v193, v217, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %36
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %36
        uint64_t v221 = (uint64_t) v29;
        TASSIGN(v220, v221);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v220, v220, v211, v213);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        // pto: %37
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %37
        uint64_t v223 = (uint64_t) v29;
        TASSIGN(v222, v223);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v222, v222, v215, v218);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t k224 = v29; k224 < v20; k224 += v24) {
        // pto: %38
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %38
        uint64_t v226 = (uint64_t) v25;
        TASSIGN(v225, v226);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v225, v199, v29, k224);
        // pto: %39
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %39
        uint64_t v228 = (uint64_t) v27;
        TASSIGN(v227, v228);
        TEXTRACT(v227, v204, k224, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %40
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
        // pto: %40
        uint64_t v230 = (uint64_t) v27;
        TASSIGN(v229, v230);
        // pto: %127
        int64_t v231 = (int64_t) ((uint64_t) k224 + (uint64_t) v19);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        TEXTRACT(v229, v199, v29, v231);
        // pto: %41
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
        // pto: %41
        uint64_t v233 = (uint64_t) v29;
        TASSIGN(v232, v233);
        TEXTRACT(v232, v204, v231, v29);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %42
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %42
        uint64_t v235 = (uint64_t) v29;
        TASSIGN(v234, v235);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v234, v234, v225, v227);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        // pto: %43
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
        // pto: %43
        uint64_t v237 = (uint64_t) v29;
        TASSIGN(v236, v237);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v236, v236, v229, v232);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %44
    Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %44
    uint64_t v239 = (uint64_t) v31;
    TASSIGN(v238, v239);
    // pto: %131
    pto::Shape<1, 1, 1, 128, 256> v240 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %131
    pto::Stride<655360, 655360, 655360, 5120, 1> v241 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %131
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v242 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v16 + v157 * v14), v240, v241);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v238, v242);
    // pto: %45
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v20);
    // pto: %45
    uint64_t v244 = (uint64_t) v30;
    TASSIGN(v243, v244);
    // pto: %132
    int64_t v245 = (int64_t) ((uint64_t) v8 + (uint64_t) v16);
    // pto: %135
    pto::Shape<1, 1, 1, 256, 256> v246 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %135
    pto::Stride<4456448, 4456448, 4456448, 17408, 1> v247 = pto::Stride<4456448, 4456448, 4456448, 17408, 1>();
    // pto: %133, %135
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND> v248 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<4456448, 4456448, 4456448, 17408, 1>, pto::Layout::ND>(v5 + ((v29 + (v245 < v29 ? v29 : v245) * v13) + v163), v246, v247);
    TLOAD(v243, v248);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j249 = v29; j249 < v20; j249 += v24) {
      // pto: %46
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %46
      uint64_t v251 = (uint64_t) v28;
      TASSIGN(v250, v251);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TEXTRACT(v250, v238, v29, j249);
      // pto: %47
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %47
      uint64_t v253 = (uint64_t) v27;
      TASSIGN(v252, v253);
      TEXTRACT(v252, v243, j249, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %48
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %48
      uint64_t v255 = (uint64_t) v29;
      TASSIGN(v254, v255);
      // pto: %137
      int64_t v256 = (int64_t) ((uint64_t) j249 + (uint64_t) v19);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v254, v238, v29, v256);
      // pto: %49
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v20);
      // pto: %49
      uint64_t v258 = (uint64_t) v29;
      TASSIGN(v257, v258);
      TEXTRACT(v257, v243, v256, v29);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %50
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %50
      uint64_t v260 = (uint64_t) v29;
      TASSIGN(v259, v260);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v259, v259, v250, v252);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %51
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
      // pto: %51
      uint64_t v262 = (uint64_t) v29;
      TASSIGN(v261, v262);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v261, v261, v254, v257);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %up_acc_inline226__rv_v2
    Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v24, v20);
    // pto: %up_acc_inline226__rv_v2
    uint64_t v264 = (uint64_t) v29;
    TASSIGN(v263, v264);
    // pto: %139
    int64_t v265 = (int64_t) ((uint64_t) i153 * (uint64_t) v20);
    // pto: %up_acc_b_inline234__iter_v1_pview
    pto::Shape<1, 1, 1, 128, 256> v266 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %up_acc_b_inline234__iter_v1_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v267 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %140, %up_acc_b_inline234__iter_v1_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v268 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v4 + (v29 + (v265 < v29 ? v29 : v265)), v266, v267);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v268, v263);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}