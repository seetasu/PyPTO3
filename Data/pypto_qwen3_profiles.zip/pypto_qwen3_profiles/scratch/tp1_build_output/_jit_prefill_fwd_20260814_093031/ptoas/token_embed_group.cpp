#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void token_embed_group(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  const int64_t v12 = 256;
  const int64_t v13 = 128;
  const int64_t v14 = 64;
  const int64_t v15 = 2;
  const int64_t v16 = 5120;
  const int64_t v17 = 1;
  const int64_t v18 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %tile_id__ssa_v0
  int64_t v19 = (int64_t) v10;
  // pto: %0
  int64_t v20 = v19 / v15;
  // pto: %2, %1, %3
  int64_t v21 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v19 - (uint64_t) ((int64_t) ((uint64_t) v20 * (uint64_t) v15)))) * (uint64_t) v14);
  // pto: %6
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  if (v20 < v8) {
    // pto: %t__tile
    int32_t v22 = (v1)[v20];
    // pto: %chunk_len_b__tile
    int32_t v23 = (v2)[v20];
    // pto: %8, %9, %10
    int64_t v24 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) v23) - (uint64_t) v7)) - (uint64_t) v21);
    // pto: %11
    int64_t v25 = v24 < v18 ? v18 : v24;
    for (int64_t i26 = v18; i26 < v14; i26 += v17) {
      // pto: %12, %13
      if (i26 < (v25 < v14 ? v25 : v14)) {
        // pto: %4, %5, %17
        int64_t v27 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v20 * (uint64_t) v13)) + (uint64_t) v21)) + (uint64_t) i26);
        // pto: %7, %14, %15, %16, %token_id__tile
        int32_t v28 = (v4)[(int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) v22) + (uint64_t) v7)) + (uint64_t) v21)) + (uint64_t) i26)];
        // pto: %18
        int64_t v29 = (int64_t) v28;
        for (int64_t j30 = v18; j30 < v16; j30 += v12) {
          // pto: %hidden_chunk__tile
          Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v12);
          // pto: %hidden_chunk__tile
          uint64_t v32 = (uint64_t) v18;
          TASSIGN(v31, v32);
          // pto: %20
          int64_t v33 = j30 < v18 ? v18 : j30;
          // pto: %embed_weight__ssa_v0_pview
          pto::Shape<1, 1, 1, 1, 256> v34 = pto::Shape<1, 1, 1, 1, 256>();
          // pto: %embed_weight__ssa_v0_pview
          pto::Stride<5120, 5120, 5120, 5120, 1> v35 = pto::Stride<5120, 5120, 5120, 5120, 1>();
          // pto: %19, %embed_weight__ssa_v0_pview
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v36 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v5 + ((v18 + (v29 < v18 ? v18 : v29) * v16) + v33), v34, v35);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
          TLOAD(v31, v36);
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          // pto: %group_hidden__iter_v3_pview
          pto::Shape<1, 1, 1, 1, 256> v37 = pto::Shape<1, 1, 1, 1, 256>();
          // pto: %group_hidden__iter_v3_pview
          pto::Stride<5120, 5120, 5120, 5120, 1> v38 = pto::Stride<5120, 5120, 5120, 5120, 1>();
          // pto: %21, %group_hidden__iter_v3_pview
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v39 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + ((v18 + (v27 < v18 ? v18 : v27) * v16) + v33), v37, v38);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          TSTORE(v39, v31);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        }
      }
    }
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}