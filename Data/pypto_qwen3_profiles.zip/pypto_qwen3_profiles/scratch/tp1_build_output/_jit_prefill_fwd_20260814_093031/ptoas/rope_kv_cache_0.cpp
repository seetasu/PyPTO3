#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rope_kv_cache_0(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, __gm__ float* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, int64_t v12, int64_t v13, int32_t v14, int64_t v15, int32_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int32_t v23, int32_t v24) {
  const int64_t v25 = 5120;
  SaturationMode v26 = SaturationMode::OFF;
  RoundMode v27 = RoundMode::CAST_ROUND;
  const int64_t v28 = 11;
  const int64_t v29 = 640;
  const int64_t v30 = 5;
  const float v31 = 9.99999997E-7f;
  const float v32 = 0.0078125f;
  const float v33 = 0.0f;
  const int64_t v34 = 16;
  const int64_t v35 = 8;
  const int64_t v36 = 32;
  const int64_t v37 = 64;
  const int64_t v38 = 1;
  const int64_t v39 = 128;
  const int64_t v40 = 25920;
  const int64_t v41 = 25664;
  const int64_t v42 = 1280;
  const int64_t v43 = 25600;
  const int64_t v44 = 17408;
  const int64_t v45 = 1024;
  const int64_t v46 = 9216;
  const int64_t v47 = 768;
  const int64_t v48 = 256;
  const int64_t v49 = 512;
  const int64_t v50 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %rope_core_inline544__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t i51 = (int64_t) v23; i51 < v12; i51 += v36) {
    // pto: %40
    int64_t v52 = (int64_t) ((uint64_t) v13 + (uint64_t) i51);
    // pto: %44, %45, %41, %42, %43
    int64_t v53 = (int64_t) ((uint64_t) ((int64_t) v16) + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) v14) + (uint64_t) v15)) + (uint64_t) v52)));
    // pto: %cos_row_inline631__tile
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
    // pto: %cos_row_inline631__tile
    uint64_t v55 = (uint64_t) v50;
    TASSIGN(v54, v55);
    // pto: %46
    int64_t v56 = v53 < v50 ? v50 : v53;
    // pto: %rope_cos__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 128> v57 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %rope_cos__ssa_v0_pview
    pto::Stride<128, 128, 128, 128, 1> v58 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %rope_cos__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v4 + (v50 + v56 * v39), v57, v58);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v54, v59);
    // pto: %sin_row_inline518__tile
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
    // pto: %sin_row_inline518__tile
    uint64_t v61 = (uint64_t) v49;
    TASSIGN(v60, v61);
    // pto: %rope_sin__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 128> v62 = pto::Shape<1, 1, 1, 1, 128>();
    // pto: %rope_sin__ssa_v0_pview
    pto::Stride<128, 128, 128, 128, 1> v63 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %rope_sin__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v5 + (v50 + v56 * v39), v62, v63);
    TLOAD(v60, v64);
    // pto: %cos_lo_inline513__tile
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
    // pto: %cos_lo_inline513__tile
    uint64_t v66 = (uint64_t) v50;
    TASSIGN(v65, v66);
    // pto: %cos_hi_inline610__tile
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
    // pto: %cos_hi_inline610__tile
    uint64_t v68 = (uint64_t) v48;
    TASSIGN(v67, v68);
    // pto: %sin_lo_inline611__tile
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
    // pto: %sin_lo_inline611__tile
    uint64_t v70 = (uint64_t) v49;
    TASSIGN(v69, v70);
    // pto: %sin_hi_inline551__tile
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
    // pto: %sin_hi_inline551__tile
    uint64_t v72 = (uint64_t) v47;
    TASSIGN(v71, v72);
    // pto: %52, %51
    int32_t v73 = (v6)[(int64_t) ((uint64_t) v17 + (uint64_t) v52)];
    // pto: %53
    int64_t v74 = (int64_t) v73;
    // pto: %54, %55
    int64_t v75 = (int64_t) ((uint64_t) (v74 / v39) * (uint64_t) v39);
    for (int64_t j76 = v50; j76 < v35; j76 += v38) {
      // pto: %58
      int64_t v77 = (int64_t) ((uint64_t) j76 * (uint64_t) v39);
      // pto: %k_head_raw_inline620__tile
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %k_head_raw_inline620__tile
      uint64_t v79 = (uint64_t) v46;
      TASSIGN(v78, v79);
      // pto: %59
      int64_t v80 = v52 < v50 ? v50 : v52;
      // pto: %60
      int64_t v81 = v77 < v50 ? v50 : v77;
      // pto: %k_proj_tile_inline507__rv_v2_pview
      pto::Shape<1, 1, 1, 1, 128> v82 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %k_proj_tile_inline507__rv_v2_pview
      pto::Stride<1024, 1024, 1024, 1024, 1> v83 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %k_proj_tile_inline507__rv_v2_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v7 + ((v50 + v80 * v45) + v81), v82, v83);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v78, v84);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %k_head_inline600__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %k_head_inline600__tile
      uint64_t v86 = (uint64_t) v45;
      TASSIGN(v85, v86);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v85, v33);
      // pto: %assemble_view
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87;
      // pto: %assemble_view
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = v87;
      // pto: %assemble_view
      uint64_t v89 = (uint64_t) v45;
      TASSIGN(v88, v89);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TMOV(v88, v78);
      // pto: %t__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %t__tile
      uint64_t v91 = (uint64_t) v46;
      TASSIGN(v90, v91);
      pipe_barrier(PIPE_V);
      TMUL(v90, v85, v85);
      // pto: %tmp_tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %tmp_tile
      uint64_t v93 = (uint64_t) v44;
      TASSIGN(v92, v93);
      // pto: %0
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %0
      uint64_t v95 = (uint64_t) v43;
      TASSIGN(v94, v95);
      pipe_barrier(PIPE_V);
      TROWSUM(v94, v90, v92);
      // pto: %k_sq_inline563__tile
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %k_sq_inline563__tile
      uint64_t v97 = (uint64_t) v43;
      TASSIGN(v96, v97);
      // pto: %t__rm_a0_tmp_v0
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v0
      uint64_t v99 = (uint64_t) v43;
      TASSIGN(v98, v99);
      // pto: %t__row_major_tmp_v1
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v1
      uint64_t v101 = (uint64_t) v46;
      TASSIGN(v100, v101);
      pipe_barrier(PIPE_V);
      TMULS(v100, v98, v32);
      // pto: %1
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %1
      uint64_t v103 = (uint64_t) v46;
      TASSIGN(v102, v103);
      // pto: %t__rm_a0_tmp_v2
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v2
      uint64_t v105 = (uint64_t) v46;
      TASSIGN(v104, v105);
      // pto: %t__row_major_tmp_v3
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v3
      uint64_t v107 = (uint64_t) v46;
      TASSIGN(v106, v107);
      pipe_barrier(PIPE_V);
      TADDS(v106, v104, v31);
      // pto: %2
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %2
      uint64_t v109 = (uint64_t) v46;
      TASSIGN(v108, v109);
      // pto: %t__rm_a0_tmp_v4
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v4
      uint64_t v111 = (uint64_t) v46;
      TASSIGN(v110, v111);
      // pto: %t__row_major_tmp_v5
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v5
      uint64_t v113 = (uint64_t) v46;
      TASSIGN(v112, v113);
      pipe_barrier(PIPE_V);
      TSQRT(v112, v110);
      // pto: %3
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %3
      uint64_t v115 = (uint64_t) v46;
      TASSIGN(v114, v115);
      // pto: %k_inv_rms_inline621__rm_a0_tmp_v6
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %k_inv_rms_inline621__rm_a0_tmp_v6
      uint64_t v117 = (uint64_t) v46;
      TASSIGN(v116, v117);
      // pto: %k_inv_rms_inline621__row_major_tmp_v7
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %k_inv_rms_inline621__row_major_tmp_v7
      uint64_t v119 = (uint64_t) v44;
      TASSIGN(v118, v119);
      pipe_barrier(PIPE_V);
      TRECIP(v118, v116);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %k_inv_rms_inline621__tile
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %k_inv_rms_inline621__tile
      uint64_t v121 = (uint64_t) v44;
      TASSIGN(v120, v121);
      // pto: %4
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %4
      uint64_t v123 = (uint64_t) v45;
      TASSIGN(v122, v123);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v122, v85, v120);
      // pto: %5
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %5
      uint64_t v125 = (uint64_t) v46;
      TASSIGN(v124, v125);
      // pto: %61
      int64_t v126 = v18 < v50 ? v50 : v18;
      // pto: %k_norm_weight__ssa_v0_pview
      pto::Shape<1, 1, 1, 1, 128> v127 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %k_norm_weight__ssa_v0_pview
      pto::Stride<128, 128, 128, 128, 1> v128 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %k_norm_weight__ssa_v0_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v129 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v8 + (v50 + v126 * v39), v127, v128);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v124, v129);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %k_normed_inline622__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %k_normed_inline622__tile
      uint64_t v131 = (uint64_t) v45;
      TASSIGN(v130, v131);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v130, v122, v124);
      // pto: %6
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %6
      uint64_t v133 = (uint64_t) v45;
      TASSIGN(v132, v133);
      // pto: %k_lo_inline623__tile
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %k_lo_inline623__tile
      uint64_t v135 = (uint64_t) v45;
      TASSIGN(v134, v135);
      // pto: %7
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %7
      uint64_t v137 = (uint64_t) v42;
      TASSIGN(v136, v137);
      // pto: %k_hi_inline609__tile
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %k_hi_inline609__tile
      uint64_t v139 = (uint64_t) v42;
      TASSIGN(v138, v139);
      // pto: %8
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %8
      uint64_t v141 = (uint64_t) v46;
      TASSIGN(v140, v141);
      TEXTRACT(v65, v54, v50, v50);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v140, v134, v65);
      // pto: %9
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %9
      uint64_t v143 = (uint64_t) v44;
      TASSIGN(v142, v143);
      TEXTRACT(v69, v60, v50, v50);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v142, v138, v69);
      // pto: %rot_lo_inline625__tile
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %rot_lo_inline625__tile
      uint64_t v145 = (uint64_t) v46;
      TASSIGN(v144, v145);
      pipe_barrier(PIPE_V);
      TSUB(v144, v140, v142);
      // pto: %10
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %10
      uint64_t v147 = (uint64_t) v44;
      TASSIGN(v146, v147);
      TEXTRACT(v67, v54, v50, v37);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v146, v138, v67);
      // pto: %11
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %11
      uint64_t v149 = (uint64_t) v45;
      TASSIGN(v148, v149);
      TEXTRACT(v71, v60, v50, v37);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v148, v134, v71);
      // pto: %rot_hi_inline627__tile
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %rot_hi_inline627__tile
      uint64_t v151 = (uint64_t) v45;
      TASSIGN(v150, v151);
      pipe_barrier(PIPE_V);
      TADD(v150, v146, v148);
      // pto: %65, %66, %56
      int64_t v152 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v19 + (uint64_t) v75)) + (uint64_t) ((int64_t) ((uint64_t) v74 - (uint64_t) v75)));
      // pto: %12
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %12
      uint64_t v154 = (uint64_t) v46;
      TASSIGN(v153, v154);
      TCVT(v153, v144, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %68
      int64_t v155 = v152 < v50 ? v50 : v152;
      // pto: %k_cache_bsnd_inline522__iter_v9_pview
      pto::Shape<1, 1, 1, 1, 64> v156 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %k_cache_bsnd_inline522__iter_v9_pview
      pto::Stride<1024, 1024, 1024, 1024, 1> v157 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %k_cache_bsnd_inline522__iter_v9_pview
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v158 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v2 + ((v50 + v155 * v45) + v81), v156, v157);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v158, v153);
      // pto: %13
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
      // pto: %13
      uint64_t v160 = (uint64_t) v45;
      TASSIGN(v159, v160);
      pipe_barrier(PIPE_V);
      TCVT(v159, v150, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %72
      int64_t v161 = (int64_t) ((uint64_t) v77 + (uint64_t) v37);
      // pto: %k_cache_bsnd_inline522__tile_pview
      pto::Shape<1, 1, 1, 1, 64> v162 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %k_cache_bsnd_inline522__tile_pview
      pto::Stride<1024, 1024, 1024, 1024, 1> v163 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %k_cache_bsnd_inline522__tile_pview, %73
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v164 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v2 + ((v50 + v155 * v45) + (v161 < v50 ? v50 : v161)), v162, v163);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v164, v159);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %14
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %14
      uint64_t v166 = (uint64_t) v45;
      TASSIGN(v165, v166);
      // pto: %v_proj_tile_inline642__rv_v2_pview
      pto::Shape<1, 1, 1, 1, 128> v167 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %v_proj_tile_inline642__rv_v2_pview
      pto::Stride<1024, 1024, 1024, 1024, 1> v168 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %v_proj_tile_inline642__rv_v2_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v169 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v9 + ((v50 + v80 * v45) + v81), v167, v168);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v165, v169);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %15
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %15
      uint64_t v171 = (uint64_t) v45;
      TASSIGN(v170, v171);
      // pto: %16
      Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %16
      uint64_t v173 = (uint64_t) v45;
      TASSIGN(v172, v173);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TCVT(v172, v170, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %v_cache_bsnd_inline521__iter_v9_pview
      pto::Shape<1, 1, 1, 1, 128> v174 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %v_cache_bsnd_inline521__iter_v9_pview
      pto::Stride<1024, 1024, 1024, 1024, 1> v175 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %v_cache_bsnd_inline521__iter_v9_pview
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v176 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v3 + ((v50 + v155 * v45) + v81), v174, v175);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v176, v172);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %17
      Tile<TileType::Vec, float, 1, 640, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 640, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v29);
      // pto: %17
      uint64_t v178 = (uint64_t) v46;
      TASSIGN(v177, v178);
      int64_t v179 = (int64_t) ((uint64_t) j76 * (uint64_t) v29);
      // pto: %q_proj_tile_inline534__rv_v2_pview
      pto::Shape<1, 1, 1, 1, 640> v180 = pto::Shape<1, 1, 1, 1, 640>();
      // pto: %q_proj_tile_inline534__rv_v2_pview
      pto::Stride<5120, 5120, 5120, 5120, 1> v181 = pto::Stride<5120, 5120, 5120, 5120, 1>();
      // pto: %q_proj_tile_inline534__rv_v2_pview, %82
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 640>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 640>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v10 + ((v50 + v80 * v25) + (v179 < v50 ? v50 : v179)), v180, v181);
      TLOAD(v177, v182);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %q_block_raw_inline629__tile
      Tile<TileType::Vec, float, 5, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 5, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v39);
      // pto: %q_block_raw_inline629__tile
      uint64_t v184 = (uint64_t) v46;
      TASSIGN(v183, v184);
      // pto: %q_block_pad_inline564__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %q_block_pad_inline564__tile
      uint64_t v186 = (uint64_t) v45;
      TASSIGN(v185, v186);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      TEXPANDS(v185, v33);
      // pto: %83
      Tile<TileType::Vec, float, 5, 128, BLayout::RowMajor, 5, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187;
      // pto: %83
      Tile<TileType::Vec, float, 5, 128, BLayout::RowMajor, 5, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = v187;
      // pto: %83
      uint64_t v189 = (uint64_t) v45;
      TASSIGN(v188, v189);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TMOV(v188, v183);
      // pto: %18
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %18
      uint64_t v191 = (uint64_t) v46;
      TASSIGN(v190, v191);
      pipe_barrier(PIPE_V);
      TMUL(v190, v185, v185);
      // pto: %19
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %19
      uint64_t v193 = (uint64_t) v44;
      TASSIGN(v192, v193);
      // pto: %20
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %20
      uint64_t v195 = (uint64_t) v43;
      TASSIGN(v194, v195);
      pipe_barrier(PIPE_V);
      TROWSUM(v194, v190, v192);
      // pto: %q_sq_inline555__tile
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %q_sq_inline555__tile
      uint64_t v197 = (uint64_t) v43;
      TASSIGN(v196, v197);
      // pto: %t__rm_a0_tmp_v8
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v8
      uint64_t v199 = (uint64_t) v43;
      TASSIGN(v198, v199);
      // pto: %t__row_major_tmp_v9
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v9
      uint64_t v201 = (uint64_t) v46;
      TASSIGN(v200, v201);
      pipe_barrier(PIPE_V);
      TMULS(v200, v198, v32);
      // pto: %21
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %21
      uint64_t v203 = (uint64_t) v46;
      TASSIGN(v202, v203);
      // pto: %t__rm_a0_tmp_v10
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v10
      uint64_t v205 = (uint64_t) v46;
      TASSIGN(v204, v205);
      // pto: %t__row_major_tmp_v11
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v11
      uint64_t v207 = (uint64_t) v46;
      TASSIGN(v206, v207);
      pipe_barrier(PIPE_V);
      TADDS(v206, v204, v31);
      // pto: %22
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %22
      uint64_t v209 = (uint64_t) v46;
      TASSIGN(v208, v209);
      // pto: %t__rm_a0_tmp_v12
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__rm_a0_tmp_v12
      uint64_t v211 = (uint64_t) v46;
      TASSIGN(v210, v211);
      // pto: %t__row_major_tmp_v13
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %t__row_major_tmp_v13
      uint64_t v213 = (uint64_t) v46;
      TASSIGN(v212, v213);
      pipe_barrier(PIPE_V);
      TSQRT(v212, v210);
      // pto: %23
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %23
      uint64_t v215 = (uint64_t) v46;
      TASSIGN(v214, v215);
      // pto: %q_inv_rms_inline618__rm_a0_tmp_v14
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %q_inv_rms_inline618__rm_a0_tmp_v14
      uint64_t v217 = (uint64_t) v46;
      TASSIGN(v216, v217);
      // pto: %q_inv_rms_inline618__row_major_tmp_v15
      Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v34);
      // pto: %q_inv_rms_inline618__row_major_tmp_v15
      uint64_t v219 = (uint64_t) v44;
      TASSIGN(v218, v219);
      pipe_barrier(PIPE_V);
      TRECIP(v218, v216);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      // pto: %q_inv_rms_inline618__tile
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v38);
      // pto: %q_inv_rms_inline618__tile
      uint64_t v221 = (uint64_t) v44;
      TASSIGN(v220, v221);
      // pto: %24
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %24
      uint64_t v223 = (uint64_t) v45;
      TASSIGN(v222, v223);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v222, v185, v220);
      // pto: %25
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v39);
      // pto: %25
      uint64_t v225 = (uint64_t) v46;
      TASSIGN(v224, v225);
      // pto: %q_norm_weight__ssa_v0_pview
      pto::Shape<1, 1, 1, 1, 128> v226 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %q_norm_weight__ssa_v0_pview
      pto::Stride<128, 128, 128, 128, 1> v227 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %q_norm_weight__ssa_v0_pview
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v228 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v11 + (v50 + v126 * v39), v226, v227);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      TLOAD(v224, v228);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %q_block_inline634__tile
      Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
      // pto: %q_block_inline634__tile
      uint64_t v230 = (uint64_t) v45;
      TASSIGN(v229, v230);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v229, v222, v224);
      // pto: %q_rot_lo_inline566__tile
      Tile<TileType::Vec, float, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v37);
      // pto: %q_rot_lo_inline566__tile
      uint64_t v232 = (uint64_t) v46;
      TASSIGN(v231, v232);
      // pto: %q_rot_hi_inline636__tile
      Tile<TileType::Vec, float, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v37);
      // pto: %q_rot_hi_inline636__tile
      uint64_t v234 = (uint64_t) v44;
      TASSIGN(v233, v234);
      for (int64_t k235 = v50; k235 < v30; k235 += v38) {
        // pto: %q_lo_inline608__tile_textract
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %q_lo_inline608__tile_textract
        uint64_t v237 = (uint64_t) v41;
        TASSIGN(v236, v237);
        pipe_barrier(PIPE_V);
        TEXTRACT(v236, v229, k235, v50);
        // pto: %26
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %26
        uint64_t v239 = (uint64_t) v41;
        TASSIGN(v238, v239);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v238, v236, v65);
        // pto: %q_hi_inline640__tile_textract
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %q_hi_inline640__tile_textract
        uint64_t v241 = (uint64_t) v40;
        TASSIGN(v240, v241);
        TEXTRACT(v240, v229, k235, v37);
        // pto: %27
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %27
        uint64_t v243 = (uint64_t) v40;
        TASSIGN(v242, v243);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v242, v240, v69);
        // pto: %28
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %28
        uint64_t v245 = (uint64_t) v41;
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TSUB(v244, v238, v242);
        // pto: %85
        int64_t v246 = (int64_t) ((uint64_t) k235 * (uint64_t) v48);
        // pto: %85
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247;
        // pto: %85
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = v247;
        // pto: %85
        uint64_t v249 = (uint64_t) ((int64_t) ((uint64_t) v246 + (uint64_t) v46));
        TASSIGN(v248, v249);
        pipe_barrier(PIPE_V);
        TMOV(v248, v244);
        // pto: %30
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %30
        uint64_t v251 = (uint64_t) v41;
        TASSIGN(v250, v251);
        pipe_barrier(PIPE_V);
        TEXTRACT(v250, v229, k235, v37);
        // pto: %31
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %31
        uint64_t v253 = (uint64_t) v41;
        TASSIGN(v252, v253);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v252, v250, v67);
        // pto: %32
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %32
        uint64_t v255 = (uint64_t) v40;
        TASSIGN(v254, v255);
        TEXTRACT(v254, v229, k235, v50);
        // pto: %33
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %33
        uint64_t v257 = (uint64_t) v40;
        TASSIGN(v256, v257);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v256, v254, v71);
        // pto: %34
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v37);
        // pto: %34
        uint64_t v259 = (uint64_t) v41;
        TASSIGN(v258, v259);
        pipe_barrier(PIPE_V);
        TADD(v258, v252, v256);
        // pto: %86
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260;
        // pto: %86
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = v260;
        // pto: %86
        uint64_t v262 = (uint64_t) ((int64_t) ((uint64_t) v246 + (uint64_t) v44));
        TASSIGN(v261, v262);
        pipe_barrier(PIPE_V);
        TMOV(v261, v258);
      }
      // pto: %57, %88, %87
      int64_t v263 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v52 * (uint64_t) v39)) + (uint64_t) ((int64_t) ((uint64_t) j76 * (uint64_t) v34)));
      // pto: %36
      Tile<TileType::Vec, bfloat16_t, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, bfloat16_t, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v37);
      // pto: %36
      uint64_t v265 = (uint64_t) v45;
      TASSIGN(v264, v265);
      pipe_barrier(PIPE_V);
      TCVT(v264, v231, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %89
      int64_t v266 = v263 < v50 ? v50 : v263;
      // pto: %all_q_padded_tile_inline547__iter_v5_pview
      pto::Shape<1, 1, 1, 5, 64> v267 = pto::Shape<1, 1, 1, 5, 64>();
      // pto: %all_q_padded_tile_inline547__iter_v5_pview
      pto::Stride<640, 640, 640, 128, 1> v268 = pto::Stride<640, 640, 640, 128, 1>();
      // pto: %all_q_padded_tile_inline547__iter_v5_pview
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 5, 64>, pto::Stride<640, 640, 640, 128, 1>, pto::Layout::ND> v269 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 5, 64>, pto::Stride<640, 640, 640, 128, 1>, pto::Layout::ND>(v1 + (v50 + v266 * v39), v267, v268);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v269, v264);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %37
      Tile<TileType::Vec, bfloat16_t, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, bfloat16_t, 5, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v37);
      // pto: %37
      uint64_t v271 = (uint64_t) v45;
      TASSIGN(v270, v271);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      TCVT(v270, v233, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      // pto: %all_q_padded_tile_inline547__tile_pview
      pto::Shape<1, 1, 1, 5, 64> v272 = pto::Shape<1, 1, 1, 5, 64>();
      // pto: %all_q_padded_tile_inline547__tile_pview
      pto::Stride<640, 640, 640, 128, 1> v273 = pto::Stride<640, 640, 640, 128, 1>();
      // pto: %all_q_padded_tile_inline547__tile_pview
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 5, 64>, pto::Stride<640, 640, 640, 128, 1>, pto::Layout::ND> v274 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 5, 64>, pto::Stride<640, 640, 640, 128, 1>, pto::Layout::ND>(v1 + (v37 + v266 * v39), v272, v273);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v274, v270);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %38
      Tile<TileType::Vec, float, 11, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 11, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v28, v39);
      // pto: %38
      uint64_t v276 = (uint64_t) v45;
      TASSIGN(v275, v276);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      TEXPANDS(v275, v33);
      // pto: %39
      Tile<TileType::Vec, bfloat16_t, 11, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, bfloat16_t, 11, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v28, v39);
      // pto: %39
      uint64_t v278 = (uint64_t) v45;
      TASSIGN(v277, v278);
      pipe_barrier(PIPE_V);
      TCVT(v277, v275, v27, v26);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      // pto: %93
      int64_t v279 = (int64_t) ((uint64_t) v263 + (uint64_t) v30);
      // pto: %95
      pto::Shape<1, 1, 1, 11, 128> v280 = pto::Shape<1, 1, 1, 11, 128>();
      // pto: %95
      pto::Stride<1408, 1408, 1408, 128, 1> v281 = pto::Stride<1408, 1408, 1408, 128, 1>();
      // pto: %94, %95
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 11, 128>, pto::Stride<1408, 1408, 1408, 128, 1>, pto::Layout::ND> v282 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 11, 128>, pto::Stride<1408, 1408, 1408, 128, 1>, pto::Layout::ND>(v1 + (v50 + (v279 < v50 ? v50 : v279) * v39), v280, v281);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      TSTORE(v282, v277);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    }
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}