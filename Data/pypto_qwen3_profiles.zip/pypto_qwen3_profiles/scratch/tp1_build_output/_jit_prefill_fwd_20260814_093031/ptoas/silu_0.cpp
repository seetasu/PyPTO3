#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void silu_0(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, int64_t v4, int32_t v5, int32_t v6) {
  SaturationMode v7 = SaturationMode::OFF;
  RoundMode v8 = RoundMode::CAST_ROUND;
  const float v9 = 1.0f;
  const int64_t v10 = 64;
  const int64_t v11 = 20;
  const int64_t v12 = 128;
  const int64_t v13 = 98304;
  const int64_t v14 = 65536;
  const int64_t v15 = 32768;
  const int64_t v16 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %silu_core_inline442__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i17 = (int64_t) v5; i17 < v4; i17 += v11) {
    // pto: %4
    int64_t v18 = (int64_t) ((uint64_t) i17 * (uint64_t) v10);
    // pto: %silu_gate_inline441__tile
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %silu_gate_inline441__tile
    uint64_t v20 = (uint64_t) v16;
    TASSIGN(v19, v20);
    // pto: %5
    int64_t v21 = v18 < v16 ? v16 : v18;
    // pto: %gate_acc_b_inline453__rv_v2_pview
    pto::Shape<1, 1, 1, 128, 64> v22 = pto::Shape<1, 1, 1, 128, 64>();
    // pto: %gate_acc_b_inline453__rv_v2_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v23 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %gate_acc_b_inline453__rv_v2_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v24 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v2 + (v16 + v21), v22, v23);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v19, v24);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %silu_up_inline576__tile
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %silu_up_inline576__tile
    uint64_t v26 = (uint64_t) v15;
    TASSIGN(v25, v26);
    // pto: %up_acc_b_inline452__rv_v2_pview
    pto::Shape<1, 1, 1, 128, 64> v27 = pto::Shape<1, 1, 1, 128, 64>();
    // pto: %up_acc_b_inline452__rv_v2_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v28 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %up_acc_b_inline452__rv_v2_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v29 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v3 + (v16 + v21), v27, v28);
    TLOAD(v25, v29);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tile
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v30 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %t__tile
    uint64_t v31 = (uint64_t) v14;
    TASSIGN(v30, v31);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TNEG(v30, v19);
    // pto: %0
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %0
    uint64_t v33 = (uint64_t) v14;
    TASSIGN(v32, v33);
    pipe_barrier(PIPE_V);
    TEXP(v32, v30);
    // pto: %1
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %1
    uint64_t v35 = (uint64_t) v14;
    TASSIGN(v34, v35);
    pipe_barrier(PIPE_V);
    TADDS(v34, v32, v9);
    // pto: %sigmoid_inline440__tile
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %sigmoid_inline440__tile
    uint64_t v37 = (uint64_t) v13;
    TASSIGN(v36, v37);
    pipe_barrier(PIPE_V);
    TRECIP(v36, v34);
    // pto: %2
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %2
    uint64_t v39 = (uint64_t) v16;
    TASSIGN(v38, v39);
    pipe_barrier(PIPE_V);
    TMUL(v38, v19, v36);
    // pto: %mlp_chunk_inline439__tile
    Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Vec, float, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %mlp_chunk_inline439__tile
    uint64_t v41 = (uint64_t) v16;
    TASSIGN(v40, v41);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TMUL(v40, v38, v25);
    // pto: %3
    Tile<TileType::Vec, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v10);
    // pto: %3
    uint64_t v43 = (uint64_t) v16;
    TASSIGN(v42, v43);
    pipe_barrier(PIPE_V);
    TCVT(v42, v40, v8, v7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %mlp_silu_b_inline450__iter_v1_pview
    pto::Shape<1, 1, 1, 128, 64> v44 = pto::Shape<1, 1, 1, 128, 64>();
    // pto: %mlp_silu_b_inline450__iter_v1_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v45 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %mlp_silu_b_inline450__iter_v1_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v46 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 64>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v1 + (v16 + v21), v44, v45);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v46, v42);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}