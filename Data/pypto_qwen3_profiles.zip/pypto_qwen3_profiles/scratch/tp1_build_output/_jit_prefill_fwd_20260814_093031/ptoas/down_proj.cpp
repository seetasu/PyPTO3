#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void down_proj(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  const int64_t v11 = 5120;
  const int64_t v12 = 2;
  const int64_t v13 = 64;
  const int64_t v14 = 256;
  const int64_t v15 = 20;
  const int64_t v16 = 1;
  const int64_t v17 = 128;
  const int64_t v18 = 16384;
  const int64_t v19 = 65536;
  const int64_t v20 = 49152;
  const int64_t v21 = 32768;
  const int64_t v22 = 0;
  const int64_t v23 = 262144;
  const int64_t v24 = 131072;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %down_acc_inline217__tile_l0_c_phi
  Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v25 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %down_acc_inline217__tile_l0_c_phi
  uint64_t v26 = (uint64_t) v22;
  TASSIGN(v25, v26);
  // pto: %down_acc_inline217__rv_v2
  Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v27 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
  // pto: %down_acc_inline217__rv_v2
  uint64_t v28 = (uint64_t) v22;
  TASSIGN(v27, v28);
  // pto: %down_core_inline241__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t i29 = (int64_t) v9; i29 < v4; i29 += v15) {
    // pto: %25
    int64_t v30 = (int64_t) ((uint64_t) i29 * (uint64_t) v14);
    // pto: %ms0_inline219__tile
    Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %ms0_inline219__tile
    uint64_t v32 = (uint64_t) v24;
    TASSIGN(v31, v32);
    // pto: %mlp_silu_b_inline232__rv_v2_pview
    pto::Shape<1, 1, 1, 128, 256> v33 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %mlp_silu_b_inline232__rv_v2_pview
    pto::Stride<1114112, 1114112, 1114112, 8704, 1> v34 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
    // pto: %mlp_silu_b_inline232__rv_v2_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v35 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v2, v33, v34);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v31, v35);
    // pto: %wd0_inline218__tile
    Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %wd0_inline218__tile
    uint64_t v37 = (uint64_t) v23;
    TASSIGN(v36, v37);
    // pto: %26
    int64_t v38 = (int64_t) ((uint64_t) v5 + (uint64_t) v6);
    // pto: %28
    int64_t v39 = v30 < v22 ? v22 : v30;
    // pto: %w_down__ssa_v0_pview
    pto::Shape<1, 1, 1, 256, 256> v40 = pto::Shape<1, 1, 1, 256, 256>();
    // pto: %w_down__ssa_v0_pview
    pto::Stride<1310720, 1310720, 1310720, 5120, 1> v41 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
    // pto: %27, %w_down__ssa_v0_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v42 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v38 < v22 ? v22 : v38) * v11) + v39), v40, v41);
    TLOAD(v36, v42);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %down_acc_inline217__tile_l0_init
    Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
    // pto: %down_acc_inline217__tile_l0_init
    uint64_t v44 = (uint64_t) v22;
    TASSIGN(v43, v44);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    for (int64_t j45 = v22; j45 < v14; j45 += v17) {
      // pto: %down_acc_inline217__tile_l0_a
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
      // pto: %down_acc_inline217__tile_l0_a
      uint64_t v47 = (uint64_t) v21;
      TASSIGN(v46, v47);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      TEXTRACT(v46, v31, v22, j45);
      // pto: %down_acc_inline217__tile_l0_b
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
      // pto: %down_acc_inline217__tile_l0_b
      uint64_t v49 = (uint64_t) v22;
      TASSIGN(v48, v49);
      TEXTRACT(v48, v36, j45, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
      // pto: %0
      uint64_t v51 = (uint64_t) v20;
      TASSIGN(v50, v51);
      // pto: %29
      int64_t v52 = (int64_t) ((uint64_t) j45 + (uint64_t) v13);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TEXTRACT(v50, v31, v22, v52);
      // pto: %1
      Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
      // pto: %1
      uint64_t v54 = (uint64_t) v21;
      TASSIGN(v53, v54);
      TEXTRACT(v53, v36, v52, v22);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %31
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (j45 == v22) {
        // pto: %down_acc_inline217__tile_l0_c_first
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %down_acc_inline217__tile_l0_c_first
        uint64_t v56 = (uint64_t) v22;
        TASSIGN(v55, v56);
        pipe_barrier(PIPE_M);
        TMATMUL(v55, v46, v48);
      } else {
        // pto: %down_acc_inline217__tile_l0_c_acc
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %down_acc_inline217__tile_l0_c_acc
        uint64_t v58 = (uint64_t) v22;
        TASSIGN(v57, v58);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v57, v57, v46, v48);
      }
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %2
      uint64_t v60 = (uint64_t) v22;
      TASSIGN(v59, v60);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v59, v59, v50, v53);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %32, %33, %34, %35
    int64_t v61 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v7 - (uint64_t) v16) / v12) * (uint64_t) v12)) + (uint64_t) v16);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    for (int64_t j62 = v16; j62 < v61; j62 += v12) {
      // pto: %36
      int64_t v63 = (int64_t) ((uint64_t) j62 * (uint64_t) v14);
      // pto: %38
      int64_t v64 = (int64_t) ((uint64_t) v63 + (uint64_t) v14);
      // pto: %msi_inline214__tile
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %msi_inline214__tile
      uint64_t v66 = (uint64_t) v22;
      TASSIGN(v65, v66);
      // pto: %40
      pto::Shape<1, 1, 1, 128, 256> v67 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %40
      pto::Stride<1114112, 1114112, 1114112, 8704, 1> v68 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
      // pto: %39, %40
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v2 + (v22 + (v63 < v22 ? v22 : v63)), v67, v68);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v65, v69);
      // pto: %wdi_inline213__tile
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %wdi_inline213__tile
      uint64_t v71 = (uint64_t) v23;
      TASSIGN(v70, v71);
      // pto: %42
      int64_t v72 = (int64_t) ((uint64_t) v38 + (uint64_t) v63);
      // pto: %45
      pto::Shape<1, 1, 1, 256, 256> v73 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %45
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v74 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %43, %45
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v75 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v72 < v22 ? v22 : v72) * v11) + v39), v73, v74);
      TLOAD(v70, v75);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %3
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %3
      uint64_t v77 = (uint64_t) v19;
      TASSIGN(v76, v77);
      // pto: %47
      pto::Shape<1, 1, 1, 128, 256> v78 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %47
      pto::Stride<1114112, 1114112, 1114112, 8704, 1> v79 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
      // pto: %46, %47
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v80 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v2 + (v22 + (v64 < v22 ? v22 : v64)), v78, v79);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v76, v80);
      // pto: %4
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %4
      uint64_t v82 = (uint64_t) v24;
      TASSIGN(v81, v82);
      // pto: %49
      int64_t v83 = (int64_t) ((uint64_t) v38 + (uint64_t) v64);
      // pto: %52
      pto::Shape<1, 1, 1, 256, 256> v84 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %52
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v85 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %50, %52
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v86 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v83 < v22 ? v22 : v83) * v11) + v39), v84, v85);
      TLOAD(v81, v86);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      for (int64_t k87 = v22; k87 < v14; k87 += v17) {
        // pto: %5
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %5
        uint64_t v89 = (uint64_t) v21;
        TASSIGN(v88, v89);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        TEXTRACT(v88, v65, v22, k87);
        // pto: %6
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %6
        uint64_t v91 = (uint64_t) v22;
        TASSIGN(v90, v91);
        TEXTRACT(v90, v70, k87, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %7
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %7
        uint64_t v93 = (uint64_t) v20;
        TASSIGN(v92, v93);
        // pto: %54
        int64_t v94 = (int64_t) ((uint64_t) k87 + (uint64_t) v13);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TEXTRACT(v92, v65, v22, v94);
        // pto: %8
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %8
        uint64_t v96 = (uint64_t) v21;
        TASSIGN(v95, v96);
        TEXTRACT(v95, v70, v94, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %9
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %9
        uint64_t v98 = (uint64_t) v22;
        TASSIGN(v97, v98);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v97, v97, v88, v90);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %10
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %10
        uint64_t v100 = (uint64_t) v22;
        TASSIGN(v99, v100);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v99, v99, v92, v95);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t k101 = v22; k101 < v14; k101 += v17) {
        // pto: %11
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %11
        uint64_t v103 = (uint64_t) v22;
        TASSIGN(v102, v103);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v102, v76, v22, k101);
        // pto: %12
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %12
        uint64_t v105 = (uint64_t) v22;
        TASSIGN(v104, v105);
        TEXTRACT(v104, v81, k101, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %13
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %13
        uint64_t v107 = (uint64_t) v18;
        TASSIGN(v106, v107);
        // pto: %57
        int64_t v108 = (int64_t) ((uint64_t) k101 + (uint64_t) v13);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v106, v76, v22, v108);
        // pto: %14
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %14
        uint64_t v110 = (uint64_t) v21;
        TASSIGN(v109, v110);
        TEXTRACT(v109, v81, v108, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %15
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %15
        uint64_t v112 = (uint64_t) v22;
        TASSIGN(v111, v112);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v111, v111, v102, v104);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %16
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %16
        uint64_t v114 = (uint64_t) v22;
        TASSIGN(v113, v114);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v113, v113, v106, v109);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    }
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    // pto: %59, %60
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    if ((int64_t) ((uint64_t) v7 - (uint64_t) v61) == v16) {
      // pto: %61
      int64_t v115 = (int64_t) ((uint64_t) v61 * (uint64_t) v14);
      // pto: %17
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v14);
      // pto: %17
      uint64_t v117 = (uint64_t) v24;
      TASSIGN(v116, v117);
      // pto: %63
      pto::Shape<1, 1, 1, 128, 256> v118 = pto::Shape<1, 1, 1, 128, 256>();
      // pto: %63
      pto::Stride<1114112, 1114112, 1114112, 8704, 1> v119 = pto::Stride<1114112, 1114112, 1114112, 8704, 1>();
      // pto: %62, %63
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<1114112, 1114112, 1114112, 8704, 1>, pto::Layout::ND>(v2 + (v22 + (v115 < v22 ? v22 : v115)), v118, v119);
      TLOAD(v116, v120);
      // pto: %18
      Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 256, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v14);
      // pto: %18
      uint64_t v122 = (uint64_t) v23;
      TASSIGN(v121, v122);
      // pto: %65
      int64_t v123 = (int64_t) ((uint64_t) v38 + (uint64_t) v115);
      // pto: %68
      pto::Shape<1, 1, 1, 256, 256> v124 = pto::Shape<1, 1, 1, 256, 256>();
      // pto: %68
      pto::Stride<1310720, 1310720, 1310720, 5120, 1> v125 = pto::Stride<1310720, 1310720, 1310720, 5120, 1>();
      // pto: %66, %68
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND> v126 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 256, 256>, pto::Stride<1310720, 1310720, 1310720, 5120, 1>, pto::Layout::ND>(v3 + ((v22 + (v123 < v22 ? v22 : v123) * v11) + v39), v124, v125);
      TLOAD(v121, v126);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t j127 = v22; j127 < v14; j127 += v17) {
        // pto: %19
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %19
        uint64_t v129 = (uint64_t) v21;
        TASSIGN(v128, v129);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TEXTRACT(v128, v116, v22, j127);
        // pto: %20
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %20
        uint64_t v131 = (uint64_t) v22;
        TASSIGN(v130, v131);
        TEXTRACT(v130, v121, j127, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %21
        Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Left, bfloat16_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %21
        uint64_t v133 = (uint64_t) v20;
        TASSIGN(v132, v133);
        // pto: %70
        int64_t v134 = (int64_t) ((uint64_t) j127 + (uint64_t) v13);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TEXTRACT(v132, v116, v22, v134);
        // pto: %22
        Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Right, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v13, v14);
        // pto: %22
        uint64_t v136 = (uint64_t) v21;
        TASSIGN(v135, v136);
        TEXTRACT(v135, v121, v134, v22);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %23
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %23
        uint64_t v138 = (uint64_t) v22;
        TASSIGN(v137, v138);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v137, v137, v128, v130);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %24
        Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %24
        uint64_t v140 = (uint64_t) v22;
        TASSIGN(v139, v140);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        TMATMUL_ACC(v139, v139, v132, v135);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      }
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    }
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %mlp_out_acc_tile_inline305__iter_v6_pview
    pto::Shape<1, 1, 1, 128, 256> v141 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %mlp_out_acc_tile_inline305__iter_v6_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v142 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %mlp_out_acc_tile_inline305__iter_v6_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v1 + (v22 + v39), v141, v142);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE<Tile<TileType::Acc, float, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>, AtomicType::AtomicAdd>(v143, v27);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}