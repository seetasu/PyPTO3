#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mlp_out_cast(__gm__ bfloat16_t* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  SaturationMode v8 = SaturationMode::OFF;
  RoundMode v9 = RoundMode::CAST_ROUND;
  const int64_t v10 = 256;
  const int64_t v11 = 20;
  const int64_t v12 = 1;
  const int64_t v13 = 5120;
  const int64_t v14 = 128;
  const int64_t v15 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %window_next__ssa_v0_view
  int64_t v16 = v14 * v13;
  // pto: %window_next__ssa_v0_view
  int64_t v17 = v12 * v16;
  // pto: %window_next__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v18 = pto::Shape<1, 1, 1, -1, -1>(v12, v12, v12, v14, v13);
  // pto: %window_next__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v19 = pto::Stride<-1, -1, -1, -1, -1>(v12 * v17, v17, v16, v13, v12);
  // pto: %window_next__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v20 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v18, v19);
  // pto: %cast_core_inline261__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t i21 = (int64_t) v6; i21 < v3; i21 += v11) {
    // pto: %0
    int64_t v22 = (int64_t) ((uint64_t) i21 * (uint64_t) v10);
    // pto: %acc_chunk_inline210__tile
    Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v23 = Tile<TileType::Vec, float, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %acc_chunk_inline210__tile
    uint64_t v24 = (uint64_t) v15;
    TASSIGN(v23, v24);
    // pto: %1
    int64_t v25 = v22 < v15 ? v15 : v22;
    // pto: %mlp_out_acc_tile_inline305__rv_v5_pview
    pto::Shape<1, 1, 1, 128, 256> v26 = pto::Shape<1, 1, 1, 128, 256>();
    // pto: %mlp_out_acc_tile_inline305__rv_v5_pview
    pto::Stride<655360, 655360, 655360, 5120, 1> v27 = pto::Stride<655360, 655360, 655360, 5120, 1>();
    // pto: %mlp_out_acc_tile_inline305__rv_v5_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND> v28 = GlobalTensor<float, pto::Shape<1, 1, 1, 128, 256>, pto::Stride<655360, 655360, 655360, 5120, 1>, pto::Layout::ND>(v2 + (v15 + v25), v26, v27);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v23, v28);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %out_bf_inline376__tile
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v29 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %out_bf_inline376__tile
    uint64_t v30 = (uint64_t) v15;
    TASSIGN(v29, v30);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCVT(v29, v23, v9, v8);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %out_valid_inline209__tile
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v31 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v4, v10);
    // pto: %out_valid_inline209__tile
    uint64_t v32 = (uint64_t) v15;
    TASSIGN(v31, v32);
    // pto: %slice_view
    Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Vec, bfloat16_t, 128, 256, BLayout::RowMajor, -1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v4);
    // pto: %slice_view
    uint64_t v34 = (uint64_t) v15;
    TASSIGN(v33, v34);
    // pto: %window_next__iter_v3_pview
    __gm__ bfloat16_t* v35 = PTOAS__GLOBAL_TENSOR_DATA(v20);
    // pto: %window_next__iter_v3_pview
    int64_t v36 = v4 * v13;
    // pto: %window_next__iter_v3_pview
    int64_t v37 = v12 * v36;
    // pto: %window_next__iter_v3_pview
    pto::Shape<1, 1, 1, -1, 256> v38 = pto::Shape<1, 1, 1, -1, 256>(v12, v12, v12, v4, v10);
    // pto: %window_next__iter_v3_pview
    pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v12 * v37, v37, v36, v13, v12);
    // pto: %2, %window_next__iter_v3_pview
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v35 + ((v15 + (v5 < v15 ? v15 : v5) * v13) + v25 * v12), v38, v39);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v40, v33);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}