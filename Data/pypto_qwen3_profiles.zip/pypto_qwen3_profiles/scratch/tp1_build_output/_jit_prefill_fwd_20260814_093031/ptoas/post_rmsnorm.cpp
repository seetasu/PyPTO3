#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void post_rmsnorm(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  SaturationMode v9 = SaturationMode::OFF;
  RoundMode v10 = RoundMode::CAST_ROUND;
  const float v11 = 9.99999997E-7f;
  const float v12 = 1.95312503E-4f;
  const int64_t v13 = 256;
  const int64_t v14 = 20;
  const float v15 = 0.0f;
  const int64_t v16 = 8;
  const int64_t v17 = 1;
  const int64_t v18 = 5120;
  const int64_t v19 = 64;
  const int64_t v20 = 16416;
  const int64_t v21 = 8224;
  const int64_t v22 = 32;
  const int64_t v23 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %post_norm_tile_inline247__ssa_v0_view
  int64_t v24 = v19 * v18;
  // pto: %post_norm_tile_inline247__ssa_v0_view
  int64_t v25 = v17 * v24;
  // pto: %post_norm_tile_inline247__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v26 = pto::Shape<1, 1, 1, -1, -1>(v17, v17, v17, v19, v18);
  // pto: %post_norm_tile_inline247__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v27 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v25, v25, v24, v18, v17);
  // pto: %post_norm_tile_inline247__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v28 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v26, v27);
  // pto: %resid1_tile_inline257__rv_v2_view
  int64_t v29 = v19 * v18;
  // pto: %resid1_tile_inline257__rv_v2_view
  int64_t v30 = v17 * v29;
  // pto: %resid1_tile_inline257__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v17, v17, v17, v19, v18);
  // pto: %resid1_tile_inline257__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v30, v30, v29, v18, v17);
  // pto: %resid1_tile_inline257__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v31, v32);
  // pto: %post_core_inline255__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t i34 = (int64_t) v7; i34 < v16; i34 += v16) {
    // pto: %8
    int64_t v35 = (int64_t) ((uint64_t) i34 * (uint64_t) v16);
    // pto: %9
    if (v35 < v4) {
      // pto: %10
      int64_t v36 = (int64_t) ((uint64_t) v4 - (uint64_t) v35);
      // pto: %11
      int64_t v37 = v36 < v16 ? v36 : v16;
      // pto: %post_sq_sum_inline315__tile
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %post_sq_sum_inline315__tile
      uint64_t v39 = (uint64_t) v23;
      TASSIGN(v38, v39);
      pipe_barrier(PIPE_V);
      TEXPANDS(v38, v15);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      for (int64_t j40 = v23; j40 < v14; j40 += v17) {
        // pto: %12
        int64_t v41 = (int64_t) ((uint64_t) j40 * (uint64_t) v13);
        // pto: %post_x_chunk_sq_inline244__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v42 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %post_x_chunk_sq_inline244__tile
        uint64_t v43 = (uint64_t) v22;
        TASSIGN(v42, v43);
        // pto: %resid1_tile_inline257__rv_v2_pview
        __gm__ float* v44 = PTOAS__GLOBAL_TENSOR_DATA(v33);
        // pto: %resid1_tile_inline257__rv_v2_pview
        int64_t v45 = v37 * v18;
        // pto: %resid1_tile_inline257__rv_v2_pview
        int64_t v46 = v17 * v45;
        // pto: %resid1_tile_inline257__rv_v2_pview
        pto::Shape<1, 1, 1, -1, 256> v47 = pto::Shape<1, 1, 1, -1, 256>(v17, v17, v17, v37, v13);
        // pto: %resid1_tile_inline257__rv_v2_pview
        pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v46, v46, v45, v18, v17);
        // pto: %13, %resid1_tile_inline257__rv_v2_pview, %14
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v44 + ((v23 + (v35 < v23 ? v23 : v35) * v18) + (v41 < v23 ? v23 : v41) * v17), v47, v48);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        TLOAD(v42, v49);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %t__tile
        uint64_t v51 = (uint64_t) v22;
        TASSIGN(v50, v51);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TMUL(v50, v42, v42);
        // pto: %tmp_tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v13);
        // pto: %tmp_tile
        uint64_t v53 = (uint64_t) v21;
        TASSIGN(v52, v53);
        // pto: %0
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v17);
        // pto: %0
        uint64_t v55 = (uint64_t) v20;
        TASSIGN(v54, v55);
        pipe_barrier(PIPE_V);
        TROWSUM(v54, v50, v52);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        // pto: %post_sq_part_inline312__tile
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v37);
        // pto: %post_sq_part_inline312__tile
        uint64_t v57 = (uint64_t) v20;
        TASSIGN(v56, v57);
        // pto: %1
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
        // pto: %1
        uint64_t v59 = (uint64_t) v23;
        TASSIGN(v58, v59);
        pipe_barrier(PIPE_V);
        TADD(v58, v38, v56);
      }
      // pto: %2
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %2
      uint64_t v61 = (uint64_t) v22;
      TASSIGN(v60, v61);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TMULS(v60, v38, v12);
      // pto: %3
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %3
      uint64_t v63 = (uint64_t) v22;
      TASSIGN(v62, v63);
      pipe_barrier(PIPE_V);
      TADDS(v62, v60, v11);
      // pto: %4
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %4
      uint64_t v65 = (uint64_t) v22;
      TASSIGN(v64, v65);
      pipe_barrier(PIPE_V);
      TSQRT(v64, v62);
      // pto: %5
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
      // pto: %5
      uint64_t v67 = (uint64_t) v23;
      TASSIGN(v66, v67);
      pipe_barrier(PIPE_V);
      TRECIP(v66, v64);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %post_inv_rms_inline387__tile
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v17);
      // pto: %post_inv_rms_inline387__tile
      uint64_t v69 = (uint64_t) v23;
      TASSIGN(v68, v69);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      for (int64_t j70 = v23; j70 < v14; j70 += v17) {
        // pto: %15
        int64_t v71 = (int64_t) ((uint64_t) j70 * (uint64_t) v13);
        // pto: %post_x_chunk_norm_inline242__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %post_x_chunk_norm_inline242__tile
        uint64_t v73 = (uint64_t) v22;
        TASSIGN(v72, v73);
        // pto: %16
        int64_t v74 = v35 < v23 ? v23 : v35;
        // pto: %17
        int64_t v75 = v71 < v23 ? v23 : v71;
        // pto: %18
        __gm__ float* v76 = PTOAS__GLOBAL_TENSOR_DATA(v33);
        // pto: %18
        int64_t v77 = v37 * v18;
        // pto: %18
        int64_t v78 = v17 * v77;
        // pto: %18
        pto::Shape<1, 1, 1, -1, 256> v79 = pto::Shape<1, 1, 1, -1, 256>(v17, v17, v17, v37, v13);
        // pto: %18
        pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v78, v78, v77, v18, v17);
        // pto: %18
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v76 + ((v23 + v74 * v18) + v75 * v17), v79, v80);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        TLOAD(v72, v81);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %gamma_inline276__tile
        Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v13);
        // pto: %gamma_inline276__tile
        uint64_t v83 = (uint64_t) v21;
        TASSIGN(v82, v83);
        // pto: %post_rms_weight__ssa_v0_pview
        pto::Shape<1, 1, 1, 1, 256> v84 = pto::Shape<1, 1, 1, 1, 256>();
        // pto: %post_rms_weight__ssa_v0_pview
        pto::Stride<5120, 5120, 5120, 5120, 1> v85 = pto::Stride<5120, 5120, 5120, 5120, 1>();
        // pto: %19, %post_rms_weight__ssa_v0_pview
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + ((v23 + (v5 < v23 ? v23 : v5) * v18) + v75), v84, v85);
        TLOAD(v82, v86);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %6
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %6
        uint64_t v88 = (uint64_t) v22;
        TASSIGN(v87, v88);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TROWEXPANDMUL(v87, v72, v68);
        // pto: %normed_inline274__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %normed_inline274__tile
        uint64_t v90 = (uint64_t) v22;
        TASSIGN(v89, v90);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDMUL(v89, v87, v82);
        // pto: %7
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
        // pto: %7
        uint64_t v92 = (uint64_t) v22;
        TASSIGN(v91, v92);
        pipe_barrier(PIPE_V);
        TCVT(v91, v89, v10, v9);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %post_norm_tile_inline247__iter_v3_pview
        __gm__ bfloat16_t* v93 = PTOAS__GLOBAL_TENSOR_DATA(v28);
        // pto: %post_norm_tile_inline247__iter_v3_pview
        int64_t v94 = v37 * v18;
        // pto: %post_norm_tile_inline247__iter_v3_pview
        int64_t v95 = v17 * v94;
        // pto: %post_norm_tile_inline247__iter_v3_pview
        pto::Shape<1, 1, 1, -1, 256> v96 = pto::Shape<1, 1, 1, -1, 256>(v17, v17, v17, v37, v13);
        // pto: %post_norm_tile_inline247__iter_v3_pview
        pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v95, v95, v94, v18, v17);
        // pto: %post_norm_tile_inline247__iter_v3_pview
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v93 + ((v23 + v74 * v18) + v75 * v17), v96, v97);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v98, v91);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      }
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    }
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}