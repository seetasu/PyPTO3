#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_0(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  SaturationMode v10 = SaturationMode::OFF;
  RoundMode v11 = RoundMode::CAST_ROUND;
  const float v12 = 9.99999997E-7f;
  const float v13 = 1.95312503E-4f;
  const int64_t v14 = 256;
  const int64_t v15 = 20;
  const float v16 = 0.0f;
  const int64_t v17 = 8;
  const int64_t v18 = 2048;
  const int64_t v19 = 1;
  const int64_t v20 = 5120;
  const int64_t v21 = 64;
  const int64_t v22 = 16416;
  const int64_t v23 = 32;
  const int64_t v24 = 8224;
  const int64_t v25 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %normed_tile_inline502__ssa_v0_view
  int64_t v26 = v21 * v20;
  // pto: %normed_tile_inline502__ssa_v0_view
  int64_t v27 = v19 * v26;
  // pto: %normed_tile_inline502__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v19, v19, v19, v21, v20);
  // pto: %normed_tile_inline502__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v27, v27, v26, v20, v19);
  // pto: %normed_tile_inline502__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %group_hidden__iter_v8_view
  int64_t v31 = v18 * v20;
  // pto: %group_hidden__iter_v8_view
  int64_t v32 = v19 * v31;
  // pto: %group_hidden__iter_v8_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v19, v19, v19, v18, v20);
  // pto: %group_hidden__iter_v8_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v32, v32, v31, v20, v19);
  // pto: %group_hidden__iter_v8_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v33, v34);
  // pto: %rms_core_inline501__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t i36 = (int64_t) v8; i36 < v17; i36 += v17) {
    // pto: %11
    int64_t v37 = (int64_t) ((uint64_t) i36 * (uint64_t) v17);
    // pto: %12
    if (v37 < v4) {
      // pto: %13
      int64_t v38 = (int64_t) ((uint64_t) v4 - (uint64_t) v37);
      // pto: %14
      int64_t v39 = v38 < v17 ? v38 : v17;
      // pto: %sq_sum_inline499__tile
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v40 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
      // pto: %sq_sum_inline499__tile
      uint64_t v41 = (uint64_t) v25;
      TASSIGN(v40, v41);
      pipe_barrier(PIPE_V);
      TEXPANDS(v40, v16);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      for (int64_t j42 = v25; j42 < v15; j42 += v19) {
        // pto: %15
        int64_t v43 = (int64_t) ((uint64_t) j42 * (uint64_t) v14);
        // pto: %t__tile
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %t__tile
        uint64_t v45 = (uint64_t) v24;
        TASSIGN(v44, v45);
        // pto: %16
        int64_t v46 = (int64_t) ((uint64_t) v5 + (uint64_t) v37);
        // pto: %group_hidden__iter_v8_pview
        __gm__ bfloat16_t* v47 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %group_hidden__iter_v8_pview
        int64_t v48 = v39 * v20;
        // pto: %group_hidden__iter_v8_pview
        int64_t v49 = v19 * v48;
        // pto: %group_hidden__iter_v8_pview
        pto::Shape<1, 1, 1, -1, 256> v50 = pto::Shape<1, 1, 1, -1, 256>(v19, v19, v19, v39, v14);
        // pto: %group_hidden__iter_v8_pview
        pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v49, v49, v48, v20, v19);
        // pto: %17, %group_hidden__iter_v8_pview, %18
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v47 + ((v25 + (v46 < v25 ? v25 : v46) * v20) + (v43 < v25 ? v25 : v43) * v19), v50, v51);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v44, v52);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %x_chunk_inline635__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %x_chunk_inline635__tile
        uint64_t v54 = (uint64_t) v23;
        TASSIGN(v53, v54);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TCVT(v53, v44, v11, v10);
        // pto: %0
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %0
        uint64_t v56 = (uint64_t) v23;
        TASSIGN(v55, v56);
        pipe_barrier(PIPE_V);
        TMUL(v55, v53, v53);
        // pto: %tmp_tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v14);
        // pto: %tmp_tile
        uint64_t v58 = (uint64_t) v24;
        TASSIGN(v57, v58);
        // pto: %1
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v19);
        // pto: %1
        uint64_t v60 = (uint64_t) v22;
        TASSIGN(v59, v60);
        pipe_barrier(PIPE_V);
        TROWSUM(v59, v55, v57);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %sq_part_inline546__tile
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v39);
        // pto: %sq_part_inline546__tile
        uint64_t v62 = (uint64_t) v22;
        TASSIGN(v61, v62);
        // pto: %2
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
        // pto: %2
        uint64_t v64 = (uint64_t) v25;
        TASSIGN(v63, v64);
        pipe_barrier(PIPE_V);
        TADD(v63, v40, v61);
      }
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %3
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
      // pto: %3
      uint64_t v66 = (uint64_t) v23;
      TASSIGN(v65, v66);
      pipe_barrier(PIPE_V);
      TMULS(v65, v40, v13);
      // pto: %4
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
      // pto: %4
      uint64_t v68 = (uint64_t) v23;
      TASSIGN(v67, v68);
      pipe_barrier(PIPE_V);
      TADDS(v67, v65, v12);
      // pto: %5
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
      // pto: %5
      uint64_t v70 = (uint64_t) v23;
      TASSIGN(v69, v70);
      pipe_barrier(PIPE_V);
      TSQRT(v69, v67);
      // pto: %6
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v17);
      // pto: %6
      uint64_t v72 = (uint64_t) v25;
      TASSIGN(v71, v72);
      pipe_barrier(PIPE_V);
      TRECIP(v71, v69);
      // pto: %inv_rms_inline487__tile
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %inv_rms_inline487__tile
      uint64_t v74 = (uint64_t) v25;
      TASSIGN(v73, v74);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      for (int64_t j75 = v25; j75 < v15; j75 += v19) {
        // pto: %19
        int64_t v76 = (int64_t) ((uint64_t) j75 * (uint64_t) v14);
        // pto: %7
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %7
        uint64_t v78 = (uint64_t) v24;
        TASSIGN(v77, v78);
        // pto: %20
        int64_t v79 = (int64_t) ((uint64_t) v5 + (uint64_t) v37);
        // pto: %22
        int64_t v80 = v76 < v25 ? v25 : v76;
        // pto: %23
        __gm__ bfloat16_t* v81 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %23
        int64_t v82 = v39 * v20;
        // pto: %23
        int64_t v83 = v19 * v82;
        // pto: %23
        pto::Shape<1, 1, 1, -1, 256> v84 = pto::Shape<1, 1, 1, -1, 256>(v19, v19, v19, v39, v14);
        // pto: %23
        pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v83, v83, v82, v20, v19);
        // pto: %21, %23
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v86 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v81 + ((v25 + (v79 < v25 ? v25 : v79) * v20) + v80 * v19), v84, v85);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        TLOAD(v77, v86);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %8
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %8
        uint64_t v88 = (uint64_t) v23;
        TASSIGN(v87, v88);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TCVT(v87, v77, v11, v10);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
        // pto: %gamma_inline494__tile
        Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v14);
        // pto: %gamma_inline494__tile
        uint64_t v90 = (uint64_t) v24;
        TASSIGN(v89, v90);
        // pto: %input_rms_weight__ssa_v0_pview
        pto::Shape<1, 1, 1, 1, 256> v91 = pto::Shape<1, 1, 1, 1, 256>();
        // pto: %input_rms_weight__ssa_v0_pview
        pto::Stride<5120, 5120, 5120, 5120, 1> v92 = pto::Stride<5120, 5120, 5120, 5120, 1>();
        // pto: %24, %input_rms_weight__ssa_v0_pview
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<5120, 5120, 5120, 5120, 1>, pto::Layout::ND>(v3 + ((v25 + (v6 < v25 ? v25 : v6) * v20) + v80), v91, v92);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
        TLOAD(v89, v93);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %9
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %9
        uint64_t v95 = (uint64_t) v23;
        TASSIGN(v94, v95);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v94, v87, v73);
        // pto: %normed_inline492__tile
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %normed_inline492__tile
        uint64_t v97 = (uint64_t) v23;
        TASSIGN(v96, v97);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDMUL(v96, v94, v89);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        // pto: %10
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v14);
        // pto: %10
        uint64_t v99 = (uint64_t) v23;
        TASSIGN(v98, v99);
        pipe_barrier(PIPE_V);
        TCVT(v98, v96, v11, v10);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %normed_tile_inline502__iter_v3_pview
        __gm__ bfloat16_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v30);
        // pto: %normed_tile_inline502__iter_v3_pview
        int64_t v101 = v39 * v20;
        // pto: %normed_tile_inline502__iter_v3_pview
        int64_t v102 = v19 * v101;
        // pto: %normed_tile_inline502__iter_v3_pview
        pto::Shape<1, 1, 1, -1, 256> v103 = pto::Shape<1, 1, 1, -1, 256>(v19, v19, v19, v39, v14);
        // pto: %normed_tile_inline502__iter_v3_pview
        pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v102, v102, v101, v20, v19);
        // pto: %26, %normed_tile_inline502__iter_v3_pview
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v100 + ((v25 + (v37 < v25 ? v25 : v37) * v20) + v80 * v19), v103, v104);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v105, v98);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      }
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    }
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}